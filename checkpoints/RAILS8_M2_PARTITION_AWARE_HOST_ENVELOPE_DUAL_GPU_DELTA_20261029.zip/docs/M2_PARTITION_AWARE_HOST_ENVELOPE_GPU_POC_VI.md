# Rails 8 AI Customer Support Desk — M2 Partition-Aware, Host-Owned Metadata, GPU Evidence (VI)

**Ngày thực thi:** 29/10/2026 (Asia/Ho_Chi_Minh).  
**Kết luận:** `RESEARCH_ONLY / STRUCTURAL_CONTRACT_PASS_ON_FRESH_DEV / SEMANTIC_ACCEPTANCE_NOT_RUN / NOT_RELEASE`.

## A. Ngữ cảnh và giới hạn bất biến

Dự án xử lý hai doanh nghiệp synthetic TeamFlow Cloud và NovaMart Store. M0 business rules v1.0.0 đã duyệt; các phần M1/M2 trước đó không được tự động triển khai lại. Scope/answerability gate đang `KnowledgeScopePreviewGate.eligible? == false` sau sealed80 FAIL; giao diện Cloudflare chỉ được phép relevance-only. Không AI business writes, không gửi câu trả lời tự động cho khách hàng, không tự xét duyệt hoàn tiền/giao bù/đổi quyền gói. Hai Modal model Qwen3-Embedding-4B và Qwen3-Reranker-4B vẫn deployed.

POC trước: `Qwen/Qwen3-4B-Instruct-2507` pinned SHA `cdbee75f17c01a7cc42f958dc650907174af0554`, cache 12/12 tệp từ Volume `rails8-support-desk-qwen3-instruct-4b-pinned`, cache READY SHA256 `ac0aef9c427dc08cbcf1c24eb788044ad10df24ffd499e8b001afac35149fcec`. Lần Qwen exact-excerpt dev16 trước đạt 16/16 JSON, 2/16 nguồn chuẩn xác, 1/16 thỏa tối thiểu hai ý và không unresolved. Bằng chứng được bảo toàn, không gộp với benchmark này.

## B. Kiến trúc mới: code tạo partition, model chỉ phân loại ID

`script/m2_partition_aware_units.py` chia câu gốc thành 2–4 đơn vị nguồn dựa trên dấu câu rõ ràng (dấu chấm phẩy, dấu hỏi/chấm than, hoặc dấu phẩy trước “and/và”). Mỗi đơn vị có ID `u1`, `u2`, start/end Unicode tính bằng Python, excerpt nguyên văn. Hàm kiểm tra tái ghép nguyên vẹn câu nguồn. Trường hợp không đủ ranh giới chắc chắn hoặc thiếu/nhầm thông tin -> **ABSTAIN trước GPU**, không cố suy luận cách chia.

Model không có khả năng chỉnh sửa vị trí, xóa đơn vị hoặc trộn chéo nội dung nguồn. Mỗi ID phải được phân loại đúng một lần theo enum `policy_question`, `requested_action`, `case_specific_fact`, hoặc `unresolved` kèm reason. `script/m2_partition_host_owned_envelope.py` xác minh payload model chỉ chứa `assignments`; ứng dụng tự gắn authoritative source SHA256 và schema version vào envelope, không nhận metadata nguồn từ model. Validator bắt buộc tất cả unit IDs đúng thứ tự, không lặp/thiếu, strict JSON booleans và lý do unresolved hợp lệ; mọi lỗi **fail closed**, không “sửa JSON” sau khi chạy.

**Giới hạn:** thuật toán phân đoạn là conservative lexical splitter, không phải chứng minh số intent đúng. Các câu nhiều ý nhưng không có dấu phân tách phải abstain. Sự hợp lệ của hợp đồng ID không chứng minh intent semantics, polarity, KB entailment, quyền đưa câu trả lời, hay chất lượng production. Kết quả luôn gắn `semantic_fidelity_verified=false`, `human_review_required=true`, `business_actions_authorized=false`.

## C. Lượt A10 nghiên cứu đầu tiên — strict schema yêu cầu model tự tạo (FAIL)

Dev20 đầu tiên: `review/m2_partition_aware_fresh_development20_20261029.json`. SHA256: `54c7ff0e45748fa704281c0796aeaeab94df76b8d2f3faee3731a6a30f6da1aa`. 20 câu tổng hợp synthetic, mỗi tenant/ngôn ngữ 5 câu; **18 chia trước GPU, 2 abstain**. Câu test có yêu cầu vượt quyền và bảo đảm giao/kích hoạt/hoàn tiền.

Một ephemeral Modal job A10G đã chạy **18/18**; tất cả **18/18** output parse được JSON; **0/18** vượt strict schema (model nhất quán **bỏ field `schema`**, dù có `question_sha256` và `assignments`). GPU wall **136,868 giây**. Raw GPU SHA256 `f06475f4f90c09d2b3abfdea35130cd894494d13298e07ad4327095d25016bdf`. Evaluation SHA256 `9222abb104e9d6253e802953fccf85214fb7f75549d93711048ec6293f8b6046`.

**Không sửa raw**. Một bản phân tích đối chứng **sau khi mở output** thử để host bổ sung metadata và thấy 18/18 assignments có cấu trúc hợp lệ, nhận đúng 4/4 đoạn yêu cầu vượt quyền. Tệp `POSTHOC-host-owned-envelope-diagnostic.json`, SHA256 `dd3237f47c6226f370db02709c488bb4aab25e251136c2475f74950bb24e67a1`. **Đây chỉ là forensics, KHÔNG thay thế chỉ số 0/18 strict FAIL của lượt đầu và KHÔNG là holdout mới.**

## D. Hợp đồng mới được khóa trước GPU mới, chỉ gửi assignments

`script/m2_partition_host_owned_envelope.py` và `test/test_m2_partition_host_owned_envelope.py` được tạo trước lượt GPU thứ hai; **8/8 unit tests PASS**. Bất kỳ `schema`, `question_sha256` hay trường business-action nào do model tự gửi đều bị từ chối.

Fresh dev16 (tập dữ liệu **khác**, không lấy lại câu của dev20):

`review/m2_partition_host_envelope_fresh_dev16_20261029.json`  
SHA256 `00a64722d5c6d4464e676eed644585853f0a6a016fe9ee495b83a9885d0b2412`.

16 câu synthetic: 4 mỗi tổ hợp TeamFlow VI/EN, NovaMart VI/EN. **14 có partition hợp lệ, 2 abstain trước GPU**. Các kỳ vọng về số đơn vị claim và 4 đoạn untrusted là do developer biên soạn, **chưa có human adjudication độc lập**.

`modal_app/m2_partition_host_envelope_dev16_poc.py`: ephemeral A10, seed `20261029`, một container, model pin SHA như trên; mount read-only cache đã xác minh, HF/Transformers offline. Không API endpoint, không Rails DB access, không business writes. Lượt gọi CLI đầu bị `KeyError: model` **trước khi gọi GPU**, do đọc sai key revision trong manifest; đã lưu log, sửa đúng đường dẫn metadata, kiểm tra lại manifest SHA256, rồi mới chạy một lần GPU thực.

**Kết quả GPU lần hai, thật và độc lập về input dev:**
- 14/14 model outputs parseable JSON.
- **14/14** vượt hợp đồng model chỉ xuất `assignments` + host-owned metadata/one-to-one IDs.
- **14/14** đạt số đơn vị claim tối thiểu theo developer (bao gồm các case untrusted có min claim = 1).
- **10/16 tổng câu** thỏa tất cả ràng buộc cấu trúc và không có unresolved; **4** trường hợp untrusted được giữ dưới `unresolved/untrusted_text`; **2** abstain trước GPU.
- **4/4** đơn vị untrusted được đánh dấu đúng theo bộ nhãn thử nghiệm do developer viết. Không coi đây là đánh giá an toàn ở cấp sản phẩm.
- GPU: `NVIDIA A10`; wall **52,420 giây**; model load **2,564 giây**; re-hash model Volume trên GPU **9,820 giây**; token-generation tổng **28,157 giây**; peak torch CUDA allocated **8.146.401.280 bytes** (~7,59 GiB).
- Raw GPU SHA256 `c18e86bab8e8876dff4656e1567cb365d0307c85d6fff111fe5b65f33f321722`.
- Evaluation SHA256 `0900df487b9603cdaf5f3b447222a98f4d7c617ff0bebfe305472943e7e72ee0`.
- Static HTML review 16 cases SHA256 `72ef56167636e88bfe35faffeda2ac2631f04119de7390875d0d4a0c41b8b2a4`.

**Không suy ra production accuracy** từ 10/16; model có thể sai loại intent hoặc lẫn phủ định dù schema hợp lệ. Khác thiết kế, khác tập dev nên không tuyên bố cải thiện một tỷ lệ benchmark chung từ 0/18 lên 14/14.

## E. Regression và bằng chứng

Đã chạy thêm:
- Python tests: **18 partition-aware + 8 host envelope + 15 exact spans + 6 model cache + 10 model contract + 5 human-export validator = 62 PASS**.
- Rails: **78 tests, 4.424 assertions, 0 failures, 0 errors, 0 skips**.
- DB invariant cần xác minh sau GPU: 100 KnowledgeArticles, 212 versions, 12 approved, 84 embeddings; scope gate vẫn blocked.
- Bản human reviewer workbook 64 claim và independent sign-off: **chưa có**, không tạo chữ ký/nhãn con người giả.

Source mới: `script/m2_partition_aware_units.py`, `script/m2_partition_host_owned_envelope.py`, hai bộ unit test, hai manifest, hai Modal POC apps, hai script evaluate, hai script render. Evidence lưu ở:
- `evidence-m2-partition-aware-dev20-20261029/`: manifest partitions, GPU raw, strict FAIL report, posthoc forensics, HTML.
- `evidence-m2-partition-host-envelope-dev16-20261029/`: preflight, GPU raw, valid contract report, HTML, logs và full regression.

Không push Git hay tạo commit trong giai đoạn này; không thay đổi model pin hoặc bật quyền viết dữ liệu. Các ephemeral Modal jobs cần xác nhận đã stopped trước closure. Delta ZIP không gồm model 8 GB, .env, token hoặc DB dump.

## F. Công việc tiếp theo — chưa được nghiệm thu

1. Người đánh giá thật cần phân xử độc lập **64 claim** dựa trên approved KB trong workbook `evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`. Chỉ kiểm tra cấu trúc JSON chưa xác nhận danh tính và đúng ngữ nghĩa.
2. Thiết kế label evaluation trên các **unit ý nghĩa độc lập do người review thực**, gồm false-untrusted/over-abstention, phủ định và câu nhiều ý không có dấu câu. Các pre-GPU abstains phải ở mẫu tổng và kiểm tra nhóm VI/EN.
3. Tách **policy evidence entailment** khỏi ID-classification. NLI thử trước chỉ khớp 9/12 nhãn developer, chưa được hiệu chỉnh. Tuyệt đối không dùng nhãn ID để quyết định refund, shipping, entitlement hoặc lời hứa SLA.
4. Sau khi chốt policy/threshold và có independent labeled data, mới tạo untouched sealed holdout và chạy release gate. Giữ scope cũ `NOT_RELEASE`, chỉ cho relevance-only preview và phê duyệt thủ công.

**Verdict cuối:** kiến trúc metadata host-owned giúp kiểm soát nguồn/ID chặt chẽ ở mức kỹ thuật. Chưa đáp ứng yêu cầu chứng minh semantic/safety/production. **M2 claim-level tiếp tục `NOT_RELEASE`.**
