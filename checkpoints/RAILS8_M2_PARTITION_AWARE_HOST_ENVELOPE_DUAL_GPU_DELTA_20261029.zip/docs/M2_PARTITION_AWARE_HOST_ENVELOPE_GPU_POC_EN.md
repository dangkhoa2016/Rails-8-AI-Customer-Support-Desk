# Rails 8 AI Customer Support Desk — M2 Partition-Aware Host-Owned Metadata GPU POC (EN)

**Executed:** October 29, 2026 (Asia/Ho_Chi_Minh).  
**Result:** `RESEARCH_ONLY / FRESH_DEV_STRUCTURAL_CONTRACT_PASS / SEMANTIC_ACCEPTANCE_NOT_RUN / NOT_RELEASE`.

## 1. Baseline and immutability constraints

The synthetic project has two tenants, TeamFlow Cloud and NovaMart Store. The M0 v1.0.0 business policies remain approved. Rails provides a private Cloudflare **relevance-only** preview; `KnowledgeScopePreviewGate.eligible? == false` remains fail-closed after the earlier sealed80 failure. The pinned Qwen3-Embedding-4B and Qwen3-Reranker-4B Modal applications remain deployed. No business writes, automatic customer answers, refund approval, replacement shipment, or entitlement modification are permitted from AI output.

The prior Qwen3-4B-Instruct-2507 isolated POC used pinned revision `cdbee75f17c01a7cc42f958dc650907174af0554`. The separate dedicated Volume `rails8-support-desk-qwen3-instruct-4b-pinned` contains 12/12 source-verified files; `cache-ready.json` SHA256 is `ac0aef9c427dc08cbcf1c24eb788044ad10df24ffd499e8b001afac35149fcec`. The previous exact-excerpt dev16 result remained only 2/16 valid exact source spans and 1/16 fully mapped minimum intents. Its raw evidence is not modified or re-labelled here.

## 2. Source partition design

`script/m2_partition_aware_units.py` creates **lossless, immutable** source units by conservatively splitting at explicit semicolons, followed question/exclamation marks, or a comma preceding “and/và”. It accepts only 2–4 nondegenerate units. Each segment receives an ID and exact Python Unicode source offsets; the concatenation must equal the full original question. Ambiguous single-span, excessive-span, malformed or privacy-like input is **abstained before GPU**, not guessed.

Model output classifies each immutable ID exactly once as one of `policy_question`, `requested_action`, `case_specific_fact` or `unresolved` with strict reason fields. It cannot edit source text, produce offsets, skip IDs, duplicate units, or choose overlapping spans. `script/m2_partition_host_owned_envelope.py` implements the later **predeclared host-owned metadata protocol**: the model supplies ONLY `assignments`; the trusted application injects schema and source SHA256 based on precomputed units and validates the full envelope.

**Limits:** A lossless lexical partition is not an independent proof of correctly separated intents, negation, entailment or answerability. Multi-intent sentences without clear separators may abstain. Source integrity cannot authorize customer answers or business actions. All results have `semantic_fidelity_verified=false`, `human_review_required=true`, `business_actions_authorized=false`.

## 3. First distinct POC (dev20) — strict metadata-from-model FAILED

Input: `review/m2_partition_aware_fresh_development20_20261029.json`, SHA256:

`54c7ff0e45748fa704281c0796aeaeab94df76b8d2f3faee3731a6a30f6da1aa`

Twenty new developer-authored synthetic cases, five per tenant×VI/EN stratum. **18 passed pre-GPU partitioning, 2 abstained**. On a one-shot NVIDIA A10G Modal job, **18/18 raw responses were JSON objects but 0/18 passed the original exact strict schema**: every model response omitted the required top-level `schema` field while providing `question_sha256` and `assignments`. Measured remote invocation wall time: **136.868 s**.

Original unmodified GPU output SHA256:
`f06475f4f90c09d2b3abfdea35130cd894494d13298e07ad4327095d25016bdf`

Original strict evaluation SHA256:
`9222abb104e9d6253e802953fccf85214fb7f75549d93711048ec6293f8b6046`

An explicitly labelled **POST-HOC, NOT AN ACCEPTANCE** counterfactual looked at host-supplied metadata and found 18/18 assignment structures would validate, including 4/4 developer-marked untrusted instructions. This did not change the original 0/18 FAIL or turn it into an independent held-out evaluation.

Forensic file SHA256:
`dd3237f47c6226f370db02709c488bb4aab25e251136c2475f74950bb24e67a1`.

## 4. Predeclared host-owned envelope with FRESH dev16

The new host-owned contract was implemented **before the second GPU run**; `test/test_m2_partition_host_owned_envelope.py` passed **8/8** tests, rejecting model-provided source SHA, schema, extra business writes, duplicated/reordered/missing IDs. The model was newly instructed to return exactly `{"assignments":[...]}`. Host-supplied trusted metadata is part of the architecture, not a post-inference repair.

Frozen new development manifest (not reused dev20):

`review/m2_partition_host_envelope_fresh_dev16_20261029.json`

SHA256: `00a64722d5c6d4464e676eed644585853f0a6a016fe9ee495b83a9885d0b2412`.

This contains **16 synthetic questions** (four per tenant×locale), with developer-authored minimum claim-unit counts and four known untrusted source-unit labels. **14 passed the conservative partition preflight; 2 abstained before GPU.** These are NOT independently adjudicated human-gold cases.

A local CLI preflight initially failed with `KeyError: model` due to a wrong manifest metadata access path; **the first attempt did not launch GPU**. Its log was preserved. Correcting the key was followed by source SHA check and a single actual GPU invocation.

The new ephemeral `modal_app/m2_partition_host_envelope_dev16_poc.py` ran pinned Qwen3-4B-Instruct-2507 on **NVIDIA A10**, seed `20261029`, one container, verified **read-only model Volume**, Hugging Face offline, no HTTP endpoint. Results:

| Metric | Observed |
|---|---:|
| Total fresh development cases | 16 |
| Pre-GPU conservative abstains | 2 |
| Real GPU cases | 14 |
| Parseable JSON objects | 14/14 |
| Exact assignments-only + host-owned metadata contract | **14/14** |
| Satisfy developer-expected minimum claim units | **14/14** |
| Full minimum counts and zero unresolved, across all 16 | **10/16** |
| Developer-labelled untrusted units correctly marked unresolved | **4/4** |
| Remote GPU invocation wall time | 52.420 s |
| Model load time | 2.564 s |
| Full model-volume SHA256 check inside GPU | 9.820 s |
| Sum of model generation times | 28.157 s |
| Peak torch CUDA allocation | 8,146,401,280 bytes (~7.59 GiB) |

Four untrusted prompts were **properly left unresolved**; they are not accepted as safe-to-answer cases. Two other cases abstained before GPU. Even for the remaining ten, **no independent semantic or KB-entailed acceptance is asserted**.

Raw dev16 GPU SHA256:
`c18e86bab8e8876dff4656e1567cb365d0307c85d6fff111fe5b65f33f321722`

Fresh dev16 evaluation SHA256:
`0900df487b9603cdaf5f3b447222a98f4d7c617ff0bebfe305472943e7e72ee0`

Standalone offline HTML, displaying all sixteen inputs, original raw responses, rejected cases and source-unit IDs:
`evidence-m2-partition-host-envelope-dev16-20261029/host-envelope-dev16-review.html`, SHA256
`72ef56167636e88bfe35faffeda2ac2631f04119de7390875d0d4a0c41b8b2a4`.

**Do not merge 0/18 and 14/14 into a single claimed benchmark improvement**: protocol and test sets differ. Dev16 is a new development sample but is not independently human-labelled or untouched sealed holdout data.

## 5. Tests, invariants and evidence

- Python tests: 18 partition-aware + 8 host-owned envelope + 15 exact-span + 6 cache hashing + 10 model-contract + 5 external human-export validator = **62 PASS**.
- Full Rails suite: **78 tests, 4,424 assertions, zero failures/errors/skips**.
- PostgreSQL invariant: **100 KnowledgeArticles / 212 versions / 12 approved / 84 embeddings**. Keep scope gate disabled.
- Two established Modal inference services deployed; research ephemeral apps must be stopped at closure.
- No customer data or business writes, no releases, no Git commit/push; no new public endpoint or changes to existing Rails private preview.
- Independent 64-claim review remains **PENDING** and a review JSON structural validator cannot impersonate a human reviewer.

New implementation files:
`script/m2_partition_aware_units.py`,
`script/m2_partition_host_owned_envelope.py`,
`test/test_m2_partition_aware_units.py`,
`test/test_m2_partition_host_owned_envelope.py`,
`modal_app/m2_partition_aware_dev20_poc.py`,
`modal_app/m2_partition_host_envelope_dev16_poc.py`,
`script/evaluate_m2_partition_dev20.py`,
`script/evaluate_m2_host_envelope_dev16.py`,
`script/render_m2_partition_dev20.py`,
`script/render_m2_host_envelope_dev16.py`, and two frozen input manifests.

Evidence directories:
`evidence-m2-partition-aware-dev20-20261029/` and
`evidence-m2-partition-host-envelope-dev16-20261029/`.

The additive evidence checkpoint does not contain 8 GB model weights, credentials, environment secrets, real business data or DB dumps.

## 6. Exact continuation point

1. Obtain genuine independent human adjudication of the existing **64 frozen claim** workbook, with exact approved KB version citations, human signoff, VI/EN policy-positive/negative/undocumented distinctions.
2. Annotate **semantic source-unit gold** independently, including false-untrusted and unnecessarily abstained examples and multi-intent text without punctuation. Review explicit negative policy vs unsupported neutral.
3. Do not confuse assignment-only structural validity with KB entailment. The prior mDeBERTa NLI research run matched only 9/12 developer labels; no calibrated production gate exists.
4. Only after freezing a solution and evaluation methodology, create a **new untouched sealed holdout**, test each tenant×locale stratum and reject unsafe claims. Maintain `NOT_RELEASE`, relevance-only preview, and human approval.

**Final conclusion:** Model infrastructure, source provenance, and assignments-only contract were validated technically on this development sample. **Production semantic/safety acceptance remains unverified; M2 claim-level is NOT RELEASED.**
