# M5.0/M5.1 — Modal AI restoration and HTTPS reliability (2026-10-30)

## Scope and safeguards
- Synthetic TeamFlow Cloud and NovaMart Store tenants only; no real customer data.
- Rails 8/PostgreSQL/pgvector with deployed, revision-pinned Qwen3-Embedding-4B and Qwen3-Reranker-4B on Modal.
- AI is assist-only; human approval is mandatory for business writes. The **sealed80 gate remains BLOCKED**, and lockbox-calibrated thresholds are unchanged.
- Restored application bearer secrets through authenticated Modal RPC and generated a new client-specific Proxy Token. Both credential layers reside in a root-owned mode-0600 file outside the Git repository and all evidence archives.
- Password-gated Cloudflare Quick Tunnel remains read-only. Relevance-only preview does not imply answerability acceptance.

## Validated
- Both Modal service applications remained deployed; no model redeployment, re-embedding, or DB business writes.
- Four preselected synthetic live requests (M2-4B-01/-02/-07/-08) succeeded using the two real Modal models. Expected source article top-1 matched TF-KB-012 twice and NM-KB-020 twice. Observed latencies were 37,356.9 / 1,094.5 / 1,042.7 / 1,010.3 milliseconds. Each result included source citations and SHA256 metadata. These are pilot source hints, **not independently reviewed semantic gold**.
- M5.1 reviewer package: 120 randomized, hint-blinded VI/EN prompts and 12 approved synthetic KB reference snapshots, prepared with zero human-reviewed gold answers. Immutable SHA256 manifests.
- Rails regression **103 tests / 4,814 assertions / zero failures, errors or skips**.

## Unresolved HTTPS reliability issue
- The previous Cloudflare hostname expired. A new password-gated tunnel and read-only Rails server returned HTTP 200 after resuming a previously stopped Puma process.
- The first Cloudflare POST to /kb/ai-search returned **HTTP 524**. Rails subsequently logged HTTP 503 after approximately 150,176 ms. This is a failed HTTPS request, not a pass.
- Direct warm Qwen3-Embedding-4B recheck succeeded (2,560 dimensions, ~231 ms).
- Direct Qwen3-Reranker-4B recheck failed with HTTP 500 after ~40.4 s. Modal logs explicitly reported **container terminated due to preemption**. Do not misdiagnose this as a bad token, changed model or wrong tenant scope.
- Preserve failed evidence. Any retry must have a separate output filename and bounded GPU budget. Reliable production inference needs bounded retries/recovery, jobs with client polling to avoid CDN request timeouts, and monitoring.

## Acceptance boundaries
- Direct authenticated Modal evidence retrieval: PASS 4/4.
- HTTPS UI: FAIL incident, pending successful independent recheck.
- Independent review gold: NOT_PERFORMED (0/120).
- Sealed80 answerability acceptance: BLOCKED (historical 3 false positives and 70% recall).
- Git remains unchanged; no commits/push. Original 240 tickets, 440 messages, 84 embeddings and 12 approved KB snapshots are retained.

## Evidence locations
- evidence-m5-live-recovery-20261030/m5-pilot-four-readonly.jsonl: four real successful direct pilot cases.
- evidence-m5-live-recovery-20261030/m5-https-ui-four-readonly.jsonl: first failed HTTPS case; do not overwrite.
- /content/rails8-m5-evidence-20261030/: diagnostic and regression test logs.
- review/m5_independent_120_20261030/: blinded human annotation worksheet (NOT_GOLD) and approved KB reference snapshots.
- Scripts: script/m5_live_four_case_readonly_pilot.rb, script/m5_prepare_blinded_independent_review.py, script/m5_validate_pilot_and_review.py, test/smoke_m5_four_live_modal_https_ui.py.

Never put actual Modal credentials, preview passwords, customer PII or unredacted sensitive logs in public backups.

## Bounded post-preemption recovery evidence

- A single direct, synthetic reranker call succeeded after the preemption, returning 2 scores in 37,245ms. The original HTTP 500 error remains recorded.
- One separately tracked HTTPS TeamFlow Vietnamese test then **PASSed with HTTP 200, TF-KB-012 as top-1, 3 citations and 51,702.9ms end-to-end**. The other original four-case HTTPS test was not rerun.
- This recovery does NOT erase the initial HTTP 524 + Rails 503 incident and does NOT establish production reliability.
- Final boundaries: authenticated direct Modal 4/4 PASS; first HTTPS cold-start FAIL 524; HTTPS recovery 1/1 PASS; independent gold 0/120; sealed80 BLOCKED.
- Evidence: evidence-m5-live-recovery-20261030/m5-https-ui-one-after-preemption-recovery.jsonl and /content/rails8-m5-evidence-20261030/reranker-recheck-second-stdout.json, m5-https-after-preemption-stdout.jsonl.
