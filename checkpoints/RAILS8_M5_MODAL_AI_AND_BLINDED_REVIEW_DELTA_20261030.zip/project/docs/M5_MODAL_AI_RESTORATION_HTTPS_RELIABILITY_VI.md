# M5.0/M5.1 — Trạng thái Modal AI và kiểm chứng HTTPS (2026-10-30)

## Chính sách và phạm vi
- Hai tenant mẫu: TeamFlow Cloud và NovaMart Store; không xử lý dữ liệu khách hàng thật.
- Rails 8, PostgreSQL/pgvector, Qwen3-Embedding-4B (revision 5cf2132abc99cad020ac570b19d031efec650f2b) và Qwen3-Reranker-4B (revision 22e683669bc0f0bd69640a1354a6d0aebcfeede5) deployed trên Modal.
- AI assist-only, human approval, không AI business writes; giữ nguyên **sealed80 = BLOCKED**, không hiệu chỉnh ngưỡng dựa trên lockbox.
- Khoá Modal hai lớp: application bearer tokens và Modal Proxy Key/Secret ở /root/.config/rails8-support-desk-modal/rails-client.env (mode 0600), không nằm trong Git/ZIP/evidence.
- Preview HTTPS có mật khẩu và gate read-only; chỉ relevance-only pilot, không phải chứng nhận answerability.

## Những phần đã PASS
- Modal ứng dụng Embedding/Reranker deployed; khôi phục bearer token từ Modal Secret riêng và tạo Proxy Token cho client mới. Không redeploy model.
- Pilot trực tiếp 4/4 trường hợp synthetic VI/EN: M2-4B-01, -02, -07, -08; Top-1 đúng bài nguồn kỳ vọng lần lượt TF-KB-012/TF-KB-012/NM-KB-020/NM-KB-020; thời gian 37.3569s/1.0945s/1.0427s/1.0103s; có citation và SHA256, không ghi nghiệp vụ. Đây là pilot được chọn trước, **không phải semantic ground truth độc lập**.
- M5.1: chuẩn bị 120 câu hỏi được xáo thứ tự/ẩn intent hint và nguồn KB approved 12 bản trong review/m5_independent_120_20261030/. 0 nhãn được reviewer độc lập xác nhận. Manifest bảo toàn SHA256 của nguồn.
- Rails regression: 103 tests, 4.814 assertions, 0 failures/errors/skips.

## Phát hiện HTTPS không đạt
- Tunnel cũ hết hạn; tunnel hiện tại đã từng trả GET /__private_preview/sign_in HTTP 200 sau khi gửi SIGCONT cho Puma bị tạm dừng.
- Lượt POST đầu tiên tới /kb/ai-search trên Cloudflare: HTTP 524; Rails xử lý tiếp và trả 503 sau ~150,176ms (chưa trả kết quả cho client). Đây là thất bại, không báo PASS.
- Test riêng Modal Embedding-4B trả 2.560 chiều PASS, khoảng 231ms khi warm.
- Test riêng Modal Reranker-4B trả HTTP 500 sau ~40.4 giây. Modal app logs chỉ rõ: **Container terminated due to preemption**. Không sửa lặng lẽ output hoặc ngưỡng.
- Mọi lần thử lại phải có evidence path mới và giới hạn truy vấn; không overwrite stdout/evidence FAIL.
- Production cần phục hồi preemption, retries có giới hạn, background jobs/polling (để tránh Cloudflare request timeout), rate limiting và giám sát. Chưa tuyên bố hoạt động ổn định 24/7.

## Trạng thái chấp nhận
- M5.0 local authenticated direct Modal proof: PASS 4/4.
- M5.0 HTTPS interface: có một lần FAIL; chỉ đánh dấu PASS khi có evidence riêng trên HTTPS thành công.
- M5.1 independent gold: 0/120 (NOT_PERFORMED).
- Sealed 80: BLOCKED; trước đó 3 FP và recall 70%, không dùng kết quả pilot để mở gate.
- Không Git commit/push; không regenerate 84 embeddings, không thay đổi 240 tickets/440 messages.

## Vị trí
- Model pilot: evidence-m5-live-recovery-20261030/m5-pilot-four-readonly.jsonl
- HTTPS cold-fail: evidence-m5-live-recovery-20261030/m5-https-ui-four-readonly.jsonl và /content/rails8-m5-evidence-20261030/m5-https-live-stdout.jsonl.
- M5 review: review/m5_independent_120_20261030/
- Scripts: script/m5_live_four_case_readonly_pilot.rb, script/m5_prepare_blinded_independent_review.py, script/m5_validate_pilot_and_review.py, test/smoke_m5_four_live_modal_https_ui.py.
- Không đưa file credentials, mật khẩu preview hoặc log nguyên văn chứa tokens vào backup public.

## Kiểm thử phục hồi sau preemption

- Sau khi reranker bị preemption, thử lại trực tiếp một yêu cầu synthetic và nhận PASS, 2 scores, thời gian 37,245ms. Kết quả của lỗi HTTP 500 cũ vẫn được bảo toàn.
- Thử lại **một** yêu cầu TeamFlow VI qua HTTPS trong evidence path mới (không chạy lại 4 câu ban đầu): **HTTP 200, Top-1 TF-KB-012, 3 citations, khoảng 51,702.9ms**.
- Bản đầu tiên HTTP 524 và Rails 503 vẫn là FAIL. Thành công sau phục hồi KHÔNG xóa lỗi ban đầu hoặc biến ứng dụng thành production-ready.
- Trạng thái tổng hợp: authenticated direct Modal 4/4 PASS; HTTPS cold-start FAIL 524; HTTPS post-preemption recovery 1/1 PASS; independent gold 0/120; sealed80 BLOCKED.
- Evidence: evidence-m5-live-recovery-20261030/m5-https-ui-one-after-preemption-recovery.jsonl, /content/rails8-m5-evidence-20261030/reranker-recheck-second-stdout.json và m5-https-after-preemption-stdout.jsonl.
