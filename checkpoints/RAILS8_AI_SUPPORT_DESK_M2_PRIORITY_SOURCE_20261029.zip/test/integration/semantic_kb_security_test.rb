# frozen_string_literal: true
require 'test_helper'
require 'digest'

# Deterministic synthetic vectors ONLY. No Modal or GPU is called.
class SemanticKbSecurityTest < ActiveSupport::TestCase
  MODEL_ID = 'Qwen/Qwen3-Embedding-0.6B'
  REV = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
  def setup
    @tf = Organization.create!(slug: 'vector-tf', name: 'Vector TF', vertical: 'b2b_saas', currency: 'USD')
    @nm = Organization.create!(slug: 'vector-nm', name: 'Vector NM', vertical: 'ecommerce', currency: 'VND')
    u = User.create!(email: 'vector-owner@example.test')
    @member = Membership.create!(organization: @tf, user: u, role: 'owner')
    @nm_member = Membership.create!(organization: @nm, user: User.create!(email: 'vector-nm@example.test'), role: 'owner')
    @q = Array.new(1024, 0.0)
    @q[0] = 1.0
  end

  test 'correct tenant and citation only, and revision pinning' do
    create_chunk(@tf, 'TF-VEC', 'approved TF content')
    create_chunk(@nm, 'NM-VEC', 'approved NM content')
    hits = search(@tf, 'agent')
    assert_equal ['TF-VEC'], hits.map(&:article_key)
    assert_match(/TF-VEC@en:v1#chunk-0/, hits.first.citation)
    assert_equal Digest::SHA256.hexdigest('approved TF content'), hits.first.sha256
    assert_empty search(@tf, 'agent', revision: 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb')
  end

  test 'draft and agent-only ACL are never bypassed by stored vectors' do
    create_chunk(@tf, 'TF-DRAFT-VEC', 'secret draft', approved: false)
    create_chunk(@tf, 'TF-AGENT-VEC', 'restricted', audience: 'agent')
    assert_empty search(@tf, 'viewer')
    assert_equal ['TF-AGENT-VEC'], search(@tf, 'agent').map(&:article_key)
    assert_equal 1, KnowledgeEmbeddingIngestion.eligible_chunks(organization: @tf).count
  end

  test 'temporal rules and superseded version invalidate stored vectors' do
    create_chunk(@tf, 'TF-EXPIRED', 'old', effective_to: Date.new(2026, 10, 28))
    create_chunk(@tf, 'TF-FUTURE', 'future', effective_from: Date.new(2099, 1, 1))
    v = create_chunk(@tf, 'TF-CURRENT', 'valid')
    assert_equal ['TF-CURRENT'], search(@tf, 'agent').map(&:article_key)
    v.update!(status: 'superseded')
    assert_empty search(@tf, 'agent')
  end

  test 'invalid vector, role and model identity fail closed' do
    assert_raises(ArgumentError) { KnowledgeSemanticRetrieval.search(
      organization: @tf, role: 'agent', embedding: [1.0], locale: 'en',
      model_id: MODEL_ID, model_revision: REV) }
    assert_raises(ArgumentError) { search(@tf, 'system') }
    assert_raises(ArgumentError) { search(@tf, 'agent', revision: '') }
  end

  test 'stale digest row cannot become a citation' do
    create_chunk(@tf, 'TF-TAMPERED', 'original approved text')
    KnowledgeChunkEmbedding.where(organization_id: @tf.id).update_all(content_sha256: 'f' * 64)
    assert_empty search(@tf, 'agent')
  end

  test 'ingestion never sends a draft to the embedding model' do
    approved_version = create_chunk(@tf, 'TF-INGEST-APPROVED', 'approved document')
    create_chunk(@tf, 'TF-INGEST-DRAFT', 'private draft', approved: false)
    KnowledgeChunkEmbedding.where(organization_id: @tf.id).delete_all
    fake = Struct.new(:model_id, :model_revision, :sent) do
      def embed_documents(texts)
        self.sent = texts
        texts.map { [1.0] + Array.new(1023, 0.0) }
      end
    end.new(MODEL_ID, REV, nil)
    outcome = KnowledgeEmbeddingIngestion.ingest!(organization: @tf, client: fake)
    assert_equal ['approved document'], fake.sent
    assert_equal 1, outcome.fetch(:embedded)
    assert_equal approved_version.id, KnowledgeChunkEmbedding.last.knowledge_chunk.knowledge_article_version_id
    assert_equal ['TF-INGEST-APPROVED'], search(@tf, 'agent').map(&:article_key)
  end

  private

  def search(org, role, revision: REV)
    KnowledgeSemanticRetrieval.search(organization: org, role: role, embedding: @q,
      locale: 'en', model_id: MODEL_ID, model_revision: revision)
  end

  def create_chunk(org, key, body, approved: true, audience: 'public',
                   effective_from: Date.new(2026, 10, 28), effective_to: nil)
    member = org == @tf ? @member : @nm_member
    article = KnowledgeArticle.create!(organization: org, article_key: key,
      category: 'test', audience: audience, policy_refs: [])
    version = KnowledgeArticleVersion.create!(organization: org, knowledge_article: article,
      locale: 'en', version_number: 1, title: key, body: body,
      sha256: Digest::SHA256.hexdigest(body), policy_version: org.policy_version,
      source_blueprint_sha256: 'test', effective_from: effective_from,
      effective_to: effective_to, status: approved ? 'approved' : 'draft',
      approved_by: approved ? member.user_id : nil,
      approved_at: approved ? Time.current : nil)
    chunk = KnowledgeChunk.create!(organization: org, knowledge_article_version: version,
      chunk_index: 0, body: body, sha256: Digest::SHA256.hexdigest(body))
    KnowledgeChunkEmbedding.create!(organization: org, knowledge_chunk: chunk,
      model_id: MODEL_ID, model_revision: REV, content_sha256: chunk.sha256,
      embedding: '[' + @q.join(',') + ']', generated_at: Time.current)
    version
  end
end
