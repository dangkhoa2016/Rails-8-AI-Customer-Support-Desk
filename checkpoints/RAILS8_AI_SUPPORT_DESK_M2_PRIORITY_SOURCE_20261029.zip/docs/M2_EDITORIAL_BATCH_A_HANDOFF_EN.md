# M2 — Editorial Batch A Handoff (EN)

**Date:** October 29, 2026. M0/M1 were not rebuilt. Canonical policy v1.0.0 and original M2 v1 source checksums are preserved.

## Deliverables

- Six article IDs: `TF-KB-012`, `TF-KB-015`, `NM-KB-014`, `NM-KB-020`, `NM-KB-029`, `NM-KB-030`.
- Twelve independently authored VI/EN v2 draft versions with evidence checklists, step-by-step safe handling and boundary examples: paid≠activated, refund day 7/8, shipping 499,999/500,000 VND, delivery ETA, return day 7/8, defect day 14/15.
- V2 is **draft and not human approved**. Passing tests does not publish content.
- Baseline v1: 200 versions/1,400 chunks. Added v2: 12 versions/84 chunks. Current synthetic DB: 100 articles, 212 versions, 1,484 chunks, 0 approved and 0 real embeddings.
- Original data: `data/m2/knowledge_drafts.json`; editorial v2 proposals: `review/m2_priority_editorial_proposals_20261029.json`.
- Idempotent importer: `M2_PRIORITY_IMPORT=YES bin/rails runner script/import_m2_priority_drafts.rb` (development synthetic database only). It rejects modified or already-reviewed v2 content.
- Rails UI: signed-in tenant owner/admin opens Knowledge Base, selects a priority article and chooses `Review VI / EN`. The page displays canonical M0 policy text, bilingual versions, hashes and separate owner approval forms requiring notes and attestation. Agents/viewers and other tenants cannot open unpublished comparative content.
- Offline review-only preview: `preview/m2_priority_editorial/index.html`. This HTML does not approve or mutate data.
- Human review decision queue: `review/M2_PRIORITY_V2_HUMAN_REVIEW_QUEUE_12.csv`. Decisions and notes remain blank.
- Rails security tests use a **test database and synthetic vectors**, never Modal GPU embeddings.

## Backup and limitations

- A source ZIP, evidence ZIP and synthetic development `pg_dump` are prepared under `checkpoints/`.
- Exclude all `.env.notebook`, credentials, vendor/bundled dependencies, and secret-bearing logs from archives.
- A copy located inside Colab is **not yet durable cloud backup**. Hugging Face and GitHub CLI are not authenticated, and there is no mounted Google Drive. No external uploads have been performed.
- Download artifacts to the user's own trusted durable storage. Never overwrite the working database when restoring the dump. pgvector must be provisioned by a PostgreSQL administrator on the destination database first.
- Do not expose passwordless development sign-in through a public tunnel.

## Next gates

1. Human owner/admin reviews both VI and EN versions and approves only those passing editorial checks.
2. Run actual authenticated Modal embedding inference against approved active KB chunks, with pinned revision and measured GPU cost.
3. Benchmark independent bilingual lexical vs semantic retrieval before calling M2 complete.
