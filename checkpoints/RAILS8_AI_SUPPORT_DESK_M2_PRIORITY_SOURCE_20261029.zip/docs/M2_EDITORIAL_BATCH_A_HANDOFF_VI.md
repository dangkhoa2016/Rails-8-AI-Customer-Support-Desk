# M2 — Bàn giao Editorial Batch A (VI)

**Ngày:** 2026-10-29. Không tạo lại M0/M1; chính sách M0 v1.0.0 và nguồn M2 v1 giữ nguyên SHA256.

## Kết quả

- 6 article IDs: `TF-KB-012`, `TF-KB-015`, `NM-KB-014`, `NM-KB-020`, `NM-KB-029`, `NM-KB-030`.
- Biên tập 12 bản riêng biệt VI/EN, thêm hướng dẫn xác minh và ví dụ biên: paid≠activated, refund ngày 7/8, ship 499.999/500.000, ETA, return ngày 7/8, defect ngày 14/15.
- V2 là **draft**, chưa được duyệt về mặt nội dung bởi owner/admin. KHÔNG tự coi bài được publish sau khi test PASS.
- V1 gốc: 200 versions/1.400 chunks. Bổ sung V2: 12 versions/84 chunks. Trạng thái DB: 100 articles, 212 versions, 1.484 chunks; approved=0, embedding vectors thật=0.
- Nguyên bản: `data/m2/knowledge_drafts.json`; đề xuất: `review/m2_priority_editorial_proposals_20261029.json`.
- Importer idempotent: `M2_PRIORITY_IMPORT=YES bin/rails runner script/import_m2_priority_drafts.rb` (synthetic development only). Không chạy lại importer khi v2 đã chỉnh sửa hoặc được duyệt; script sẽ chặn drift.
- UI: vào Knowledge Base bằng tài khoản demo **owner/admin của đúng tenant**, thấy nhóm 6 bài ưu tiên, chọn `Rà soát VI / EN`, xem canonical policy và cả hai bản song song. Duyệt từng locale bằng ghi chú + attestation. Agent/viewer và tenant khác không xem được trang so sánh draft.
- Xem offline: `preview/m2_priority_editorial/index.html`. Đây là preview chỉ đọc, không có chức năng approve.
- Queue ghi chú của con người: `review/M2_PRIORITY_V2_HUMAN_REVIEW_QUEUE_12.csv`, hiện bỏ trống decision/notes.
- Regression M1/M2/semantic security được chạy trên **test DB**; test semantic sử dụng vector tổng hợp, không dùng Modal GPU.

## Backup và giới hạn

- Full source, evidence và `pg_dump` của synthetic development DB được đóng gói trong `checkpoints/`.
- Archive không có `.env.notebook`, vendor, log chứa secrets hoặc credential files.
- **Lưu tại Colab chưa phải cloud backup bền vững.** Hiện `hf auth whoami` chưa login, `gh auth status` chưa login và Drive không mount; không tự upload ra bên ngoài.
- Sau khi xem ZIP: tải về ổ local/cloud storage riêng. Không restore dump đè lên database hiện có. `pgvector` phải được quản trị viên cài trong database đích trước khi restore.
- Không mở public Cloudflare Tunnel vì demo sign-in hiện chưa có production authentication.

## Tiếp tục

1. Human review đủ 12 v2 drafts trên Rails, kiểm tra 6 vấn đề chính sách, quyết định từng locale; chỉ owner/admin mới approve.
2. Sau khi có approved KB, thử nghiệm Modal embeddings với quyền truy cập xác thực, model revision pinned và chi phí GPU được kiểm soát.
3. Chạy independent retrieval VI/EN benchmark. M2 semantic chưa được coi là hoàn tất.
