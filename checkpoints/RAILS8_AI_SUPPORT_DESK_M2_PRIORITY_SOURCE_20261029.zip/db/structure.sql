SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    actor_user_id bigint NOT NULL,
    ticket_id bigint,
    action character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_events_id_seq OWNED BY public.audit_events.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    external_key character varying NOT NULL,
    locale character varying DEFAULT 'vi'::character varying NOT NULL,
    synthetic_email character varying NOT NULL,
    display_name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT customer_known_locale CHECK (((locale)::text = ANY ((ARRAY['vi'::character varying, 'en'::character varying])::text[])))
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: knowledge_article_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_article_versions (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    knowledge_article_id bigint NOT NULL,
    locale character varying NOT NULL,
    version_number integer NOT NULL,
    title character varying NOT NULL,
    body text NOT NULL,
    status character varying DEFAULT 'draft'::character varying NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    sha256 character varying NOT NULL,
    policy_version character varying NOT NULL,
    source_blueprint_sha256 character varying NOT NULL,
    approved_by bigint,
    approved_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT kb_approved_requires_actor_time CHECK (((((status)::text = 'approved'::text) AND (approved_by IS NOT NULL) AND (approved_at IS NOT NULL)) OR ((status)::text <> 'approved'::text))),
    CONSTRAINT kb_version_known_locale CHECK (((locale)::text = ANY ((ARRAY['vi'::character varying, 'en'::character varying])::text[]))),
    CONSTRAINT kb_version_known_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'approved'::character varying, 'superseded'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT kb_version_positive CHECK ((version_number >= 1)),
    CONSTRAINT kb_version_valid_effective_window CHECK (((effective_to IS NULL) OR (effective_to >= effective_from)))
);


--
-- Name: knowledge_article_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knowledge_article_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knowledge_article_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knowledge_article_versions_id_seq OWNED BY public.knowledge_article_versions.id;


--
-- Name: knowledge_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_articles (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    article_key character varying NOT NULL,
    category character varying NOT NULL,
    audience character varying DEFAULT 'public'::character varying NOT NULL,
    policy_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT kb_article_audience_known CHECK (((audience)::text = ANY ((ARRAY['public'::character varying, 'agent'::character varying])::text[])))
);


--
-- Name: knowledge_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knowledge_articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knowledge_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knowledge_articles_id_seq OWNED BY public.knowledge_articles.id;


--
-- Name: knowledge_chunk_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_chunk_embeddings (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    knowledge_chunk_id bigint NOT NULL,
    model_id character varying NOT NULL,
    model_revision character varying NOT NULL,
    content_sha256 character varying NOT NULL,
    embedding public.vector(1024) NOT NULL,
    generated_at timestamp(6) without time zone NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT kb_embedding_sha256_length CHECK ((length((content_sha256)::text) = 64))
);


--
-- Name: knowledge_chunk_embeddings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knowledge_chunk_embeddings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knowledge_chunk_embeddings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knowledge_chunk_embeddings_id_seq OWNED BY public.knowledge_chunk_embeddings.id;


--
-- Name: knowledge_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_chunks (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    knowledge_article_version_id bigint NOT NULL,
    chunk_index integer NOT NULL,
    body text NOT NULL,
    sha256 character varying NOT NULL,
    embedding_status character varying DEFAULT 'not_generated'::character varying NOT NULL,
    embedding_model_revision character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT kb_chunk_embedding_status_known CHECK (((embedding_status)::text = ANY ((ARRAY['not_generated'::character varying, 'pending'::character varying, 'ready'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT kb_chunk_index_nonnegative CHECK ((chunk_index >= 0))
);


--
-- Name: knowledge_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knowledge_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knowledge_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knowledge_chunks_id_seq OWNED BY public.knowledge_chunks.id;


--
-- Name: memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memberships (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT membership_known_role CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'agent'::character varying, 'viewer'::character varying])::text[])))
);


--
-- Name: memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.memberships_id_seq OWNED BY public.memberships.id;


--
-- Name: nm_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_order_items (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_id bigint NOT NULL,
    sku_snapshot character varying NOT NULL,
    unit_price_snapshot_vnd bigint NOT NULL,
    quantity integer NOT NULL,
    discount_snapshot_vnd bigint DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_item_nonnegative_money CHECK (((unit_price_snapshot_vnd >= 0) AND (quantity > 0) AND (discount_snapshot_vnd >= 0) AND (discount_snapshot_vnd <= (unit_price_snapshot_vnd * quantity))))
);


--
-- Name: nm_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_order_items_id_seq OWNED BY public.nm_order_items.id;


--
-- Name: nm_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_orders (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    order_number character varying NOT NULL,
    status character varying DEFAULT 'pending_payment'::character varying NOT NULL,
    subtotal_vnd bigint DEFAULT 0 NOT NULL,
    discount_vnd bigint DEFAULT 0 NOT NULL,
    shipping_vnd bigint DEFAULT 0 NOT NULL,
    grand_total_vnd bigint DEFAULT 0 NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_order_known_status CHECK (((status)::text = ANY ((ARRAY['pending_payment'::character varying, 'confirmed'::character varying, 'packing'::character varying, 'shipped'::character varying, 'delivered'::character varying, 'canceled'::character varying])::text[]))),
    CONSTRAINT nm_order_totals_consistent CHECK (((subtotal_vnd >= 0) AND (discount_vnd >= 0) AND (discount_vnd <= subtotal_vnd) AND (shipping_vnd >= 0) AND (grand_total_vnd = ((subtotal_vnd - discount_vnd) + shipping_vnd)))),
    CONSTRAINT nm_standard_shipping_rule CHECK ((shipping_vnd =
CASE
    WHEN ((subtotal_vnd - discount_vnd) >= 500000) THEN 0
    ELSE 30000
END))
);


--
-- Name: nm_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_orders_id_seq OWNED BY public.nm_orders.id;


--
-- Name: nm_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_payments (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_id bigint NOT NULL,
    payment_key character varying NOT NULL,
    status character varying NOT NULL,
    amount_vnd bigint NOT NULL,
    confirmed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_payment_known_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'failed'::character varying, 'partially_refunded'::character varying, 'refunded'::character varying])::text[]))),
    CONSTRAINT nm_payment_nonnegative CHECK ((amount_vnd >= 0)),
    CONSTRAINT nm_payment_paid_at CHECK ((((status)::text <> 'paid'::text) OR (confirmed_at IS NOT NULL)))
);


--
-- Name: nm_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_payments_id_seq OWNED BY public.nm_payments.id;


--
-- Name: nm_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_products (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    sku character varying NOT NULL,
    name character varying NOT NULL,
    current_price_vnd bigint NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    warranty_months integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_product_nonnegative CHECK (((current_price_vnd >= 0) AND (stock >= 0) AND (warranty_months >= 0)))
);


--
-- Name: nm_products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_products_id_seq OWNED BY public.nm_products.id;


--
-- Name: nm_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_return_items (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_id bigint NOT NULL,
    return_request_id bigint NOT NULL,
    order_item_id bigint NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_return_quantity_positive CHECK ((quantity > 0))
);


--
-- Name: nm_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_return_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_return_items_id_seq OWNED BY public.nm_return_items.id;


--
-- Name: nm_return_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_return_requests (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_id bigint NOT NULL,
    request_key character varying NOT NULL,
    reason character varying NOT NULL,
    status character varying DEFAULT 'requested'::character varying NOT NULL,
    reviewed_by bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_return_known_status CHECK (((status)::text = ANY ((ARRAY['requested'::character varying, 'under_review'::character varying, 'approved'::character varying, 'rejected'::character varying, 'received'::character varying, 'refunded'::character varying])::text[])))
);


--
-- Name: nm_return_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_return_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_return_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_return_requests_id_seq OWNED BY public.nm_return_requests.id;


--
-- Name: nm_shipment_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_shipment_items (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_id bigint NOT NULL,
    shipment_id bigint NOT NULL,
    order_item_id bigint NOT NULL,
    shipped_quantity integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_shipped_quantity_positive CHECK ((shipped_quantity > 0))
);


--
-- Name: nm_shipment_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_shipment_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_shipment_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_shipment_items_id_seq OWNED BY public.nm_shipment_items.id;


--
-- Name: nm_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_shipments (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_id bigint NOT NULL,
    shipment_key character varying NOT NULL,
    carrier_label character varying,
    status character varying NOT NULL,
    shipped_at timestamp(6) without time zone,
    delivered_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT nm_shipment_delivered_at CHECK ((((status)::text <> 'delivered'::text) OR (delivered_at IS NOT NULL))),
    CONSTRAINT nm_shipment_known_status CHECK (((status)::text = ANY ((ARRAY['label_created'::character varying, 'in_transit'::character varying, 'delivered'::character varying, 'exception'::character varying])::text[])))
);


--
-- Name: nm_shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_shipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_shipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_shipments_id_seq OWNED BY public.nm_shipments.id;


--
-- Name: nm_warranty_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nm_warranty_claims (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    order_item_id bigint NOT NULL,
    claim_key character varying NOT NULL,
    status character varying NOT NULL,
    reviewed_by bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: nm_warranty_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nm_warranty_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nm_warranty_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nm_warranty_claims_id_seq OWNED BY public.nm_warranty_claims.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id bigint NOT NULL,
    slug character varying NOT NULL,
    name character varying NOT NULL,
    vertical character varying NOT NULL,
    currency character varying NOT NULL,
    timezone character varying DEFAULT 'Asia/Ho_Chi_Minh'::character varying NOT NULL,
    default_locale character varying DEFAULT 'vi'::character varying NOT NULL,
    policy_version character varying DEFAULT '1.0.0'::character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT org_currency_known CHECK (((currency)::text = ANY ((ARRAY['USD'::character varying, 'VND'::character varying])::text[])))
);


--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: tf_activation_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_activation_events (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    subscription_id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    result character varying NOT NULL,
    occurred_at timestamp(6) without time zone NOT NULL,
    activated_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT tf_activation_known_result CHECK (((result)::text = ANY ((ARRAY['succeeded'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT tf_activation_result_timestamp CHECK (((((result)::text = 'succeeded'::text) AND (activated_at IS NOT NULL)) OR (((result)::text = 'failed'::text) AND (activated_at IS NULL))))
);


--
-- Name: tf_activation_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_activation_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_activation_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_activation_events_id_seq OWNED BY public.tf_activation_events.id;


--
-- Name: tf_api_request_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_api_request_events (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    workspace_id bigint NOT NULL,
    request_id character varying NOT NULL,
    status_code integer NOT NULL,
    route character varying NOT NULL,
    occurred_at timestamp(6) without time zone NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT tf_request_status_http CHECK (((status_code >= 100) AND (status_code <= 599)))
);


--
-- Name: tf_api_request_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_api_request_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_api_request_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_api_request_events_id_seq OWNED BY public.tf_api_request_events.id;


--
-- Name: tf_export_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_export_jobs (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    workspace_id bigint NOT NULL,
    job_key character varying NOT NULL,
    status character varying NOT NULL,
    error_code character varying,
    completed_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT tf_export_known_status CHECK (((status)::text = ANY ((ARRAY['queued'::character varying, 'running'::character varying, 'succeeded'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: tf_export_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_export_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_export_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_export_jobs_id_seq OWNED BY public.tf_export_jobs.id;


--
-- Name: tf_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_invoices (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    workspace_id bigint NOT NULL,
    subscription_id bigint NOT NULL,
    invoice_number character varying NOT NULL,
    total_cents bigint NOT NULL,
    status character varying NOT NULL,
    paid_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT tf_invoice_positive_cents CHECK ((total_cents >= 0)),
    CONSTRAINT tf_invoice_status_known CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'failed'::character varying, 'refunded'::character varying])::text[]))),
    CONSTRAINT tf_paid_requires_timestamp CHECK ((((status)::text <> 'paid'::text) OR (paid_at IS NOT NULL)))
);


--
-- Name: tf_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_invoices_id_seq OWNED BY public.tf_invoices.id;


--
-- Name: tf_service_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_service_incidents (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    incident_key character varying NOT NULL,
    window_start timestamp(6) without time zone NOT NULL,
    window_end timestamp(6) without time zone,
    affected_components text NOT NULL,
    confirmed_cause text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT tf_incident_valid_interval CHECK (((window_end IS NULL) OR (window_end >= window_start)))
);


--
-- Name: tf_service_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_service_incidents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_service_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_service_incidents_id_seq OWNED BY public.tf_service_incidents.id;


--
-- Name: tf_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_subscriptions (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    workspace_id bigint NOT NULL,
    plan_code character varying DEFAULT 'free'::character varying NOT NULL,
    requested_plan_code character varying,
    status character varying DEFAULT 'free'::character varying NOT NULL,
    effective_at timestamp(6) without time zone,
    renew_at timestamp(6) without time zone,
    pending_change_code character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT tf_sub_plan_known CHECK (((plan_code)::text = ANY ((ARRAY['free'::character varying, 'starter'::character varying, 'pro'::character varying, 'business'::character varying])::text[]))),
    CONSTRAINT tf_sub_requested_plan_known CHECK (((requested_plan_code IS NULL) OR ((requested_plan_code)::text = ANY ((ARRAY['free'::character varying, 'starter'::character varying, 'pro'::character varying, 'business'::character varying])::text[])))),
    CONSTRAINT tf_sub_status_known CHECK (((status)::text = ANY ((ARRAY['free'::character varying, 'active'::character varying, 'past_due'::character varying, 'canceled'::character varying])::text[])))
);


--
-- Name: tf_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_subscriptions_id_seq OWNED BY public.tf_subscriptions.id;


--
-- Name: tf_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tf_workspaces (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    workspace_key character varying NOT NULL,
    owner_user_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: tf_workspaces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tf_workspaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tf_workspaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tf_workspaces_id_seq OWNED BY public.tf_workspaces.id;


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_messages (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    ticket_id bigint NOT NULL,
    actor_user_id bigint,
    actor_type character varying NOT NULL,
    visibility character varying NOT NULL,
    channel character varying DEFAULT 'portal'::character varying NOT NULL,
    body text NOT NULL,
    sent_at timestamp(6) without time zone,
    idempotency_key character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT message_known_visibility CHECK (((visibility)::text = ANY ((ARRAY['public'::character varying, 'internal'::character varying])::text[])))
);


--
-- Name: ticket_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ticket_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ticket_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ticket_messages_id_seq OWNED BY public.ticket_messages.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tickets (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    assignee_id bigint,
    number character varying NOT NULL,
    category character varying NOT NULL,
    priority character varying DEFAULT 'P3'::character varying NOT NULL,
    status character varying DEFAULT 'new'::character varying NOT NULL,
    business_ref character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    CONSTRAINT ticket_known_priority CHECK (((priority)::text = ANY ((ARRAY['P1'::character varying, 'P2'::character varying, 'P3'::character varying, 'P4'::character varying])::text[]))),
    CONSTRAINT ticket_known_status CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'open'::character varying, 'pending_customer'::character varying, 'pending_internal'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying NOT NULL,
    display_name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events ALTER COLUMN id SET DEFAULT nextval('public.audit_events_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: knowledge_article_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_article_versions ALTER COLUMN id SET DEFAULT nextval('public.knowledge_article_versions_id_seq'::regclass);


--
-- Name: knowledge_articles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_articles ALTER COLUMN id SET DEFAULT nextval('public.knowledge_articles_id_seq'::regclass);


--
-- Name: knowledge_chunk_embeddings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_chunk_embeddings ALTER COLUMN id SET DEFAULT nextval('public.knowledge_chunk_embeddings_id_seq'::regclass);


--
-- Name: knowledge_chunks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_chunks ALTER COLUMN id SET DEFAULT nextval('public.knowledge_chunks_id_seq'::regclass);


--
-- Name: memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memberships ALTER COLUMN id SET DEFAULT nextval('public.memberships_id_seq'::regclass);


--
-- Name: nm_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_order_items ALTER COLUMN id SET DEFAULT nextval('public.nm_order_items_id_seq'::regclass);


--
-- Name: nm_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_orders ALTER COLUMN id SET DEFAULT nextval('public.nm_orders_id_seq'::regclass);


--
-- Name: nm_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_payments ALTER COLUMN id SET DEFAULT nextval('public.nm_payments_id_seq'::regclass);


--
-- Name: nm_products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_products ALTER COLUMN id SET DEFAULT nextval('public.nm_products_id_seq'::regclass);


--
-- Name: nm_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_items ALTER COLUMN id SET DEFAULT nextval('public.nm_return_items_id_seq'::regclass);


--
-- Name: nm_return_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_requests ALTER COLUMN id SET DEFAULT nextval('public.nm_return_requests_id_seq'::regclass);


--
-- Name: nm_shipment_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipment_items ALTER COLUMN id SET DEFAULT nextval('public.nm_shipment_items_id_seq'::regclass);


--
-- Name: nm_shipments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipments ALTER COLUMN id SET DEFAULT nextval('public.nm_shipments_id_seq'::regclass);


--
-- Name: nm_warranty_claims id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_warranty_claims ALTER COLUMN id SET DEFAULT nextval('public.nm_warranty_claims_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: tf_activation_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_activation_events ALTER COLUMN id SET DEFAULT nextval('public.tf_activation_events_id_seq'::regclass);


--
-- Name: tf_api_request_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_api_request_events ALTER COLUMN id SET DEFAULT nextval('public.tf_api_request_events_id_seq'::regclass);


--
-- Name: tf_export_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_export_jobs ALTER COLUMN id SET DEFAULT nextval('public.tf_export_jobs_id_seq'::regclass);


--
-- Name: tf_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_invoices ALTER COLUMN id SET DEFAULT nextval('public.tf_invoices_id_seq'::regclass);


--
-- Name: tf_service_incidents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_service_incidents ALTER COLUMN id SET DEFAULT nextval('public.tf_service_incidents_id_seq'::regclass);


--
-- Name: tf_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.tf_subscriptions_id_seq'::regclass);


--
-- Name: tf_workspaces id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_workspaces ALTER COLUMN id SET DEFAULT nextval('public.tf_workspaces_id_seq'::regclass);


--
-- Name: ticket_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages ALTER COLUMN id SET DEFAULT nextval('public.ticket_messages_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: knowledge_article_versions knowledge_article_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_article_versions
    ADD CONSTRAINT knowledge_article_versions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_articles knowledge_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_articles
    ADD CONSTRAINT knowledge_articles_pkey PRIMARY KEY (id);


--
-- Name: knowledge_chunk_embeddings knowledge_chunk_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_chunk_embeddings
    ADD CONSTRAINT knowledge_chunk_embeddings_pkey PRIMARY KEY (id);


--
-- Name: knowledge_chunks knowledge_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: nm_order_items nm_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_order_items
    ADD CONSTRAINT nm_order_items_pkey PRIMARY KEY (id);


--
-- Name: nm_orders nm_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_orders
    ADD CONSTRAINT nm_orders_pkey PRIMARY KEY (id);


--
-- Name: nm_payments nm_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_payments
    ADD CONSTRAINT nm_payments_pkey PRIMARY KEY (id);


--
-- Name: nm_products nm_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_products
    ADD CONSTRAINT nm_products_pkey PRIMARY KEY (id);


--
-- Name: nm_return_items nm_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_items
    ADD CONSTRAINT nm_return_items_pkey PRIMARY KEY (id);


--
-- Name: nm_return_requests nm_return_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_requests
    ADD CONSTRAINT nm_return_requests_pkey PRIMARY KEY (id);


--
-- Name: nm_shipment_items nm_shipment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipment_items
    ADD CONSTRAINT nm_shipment_items_pkey PRIMARY KEY (id);


--
-- Name: nm_shipments nm_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipments
    ADD CONSTRAINT nm_shipments_pkey PRIMARY KEY (id);


--
-- Name: nm_warranty_claims nm_warranty_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_warranty_claims
    ADD CONSTRAINT nm_warranty_claims_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: tf_activation_events tf_activation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_activation_events
    ADD CONSTRAINT tf_activation_events_pkey PRIMARY KEY (id);


--
-- Name: tf_api_request_events tf_api_request_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_api_request_events
    ADD CONSTRAINT tf_api_request_events_pkey PRIMARY KEY (id);


--
-- Name: tf_export_jobs tf_export_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_export_jobs
    ADD CONSTRAINT tf_export_jobs_pkey PRIMARY KEY (id);


--
-- Name: tf_invoices tf_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_invoices
    ADD CONSTRAINT tf_invoices_pkey PRIMARY KEY (id);


--
-- Name: tf_service_incidents tf_service_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_service_incidents
    ADD CONSTRAINT tf_service_incidents_pkey PRIMARY KEY (id);


--
-- Name: tf_subscriptions tf_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_subscriptions
    ADD CONSTRAINT tf_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tf_workspaces tf_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_workspaces
    ADD CONSTRAINT tf_workspaces_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_embeddings_tenant_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_embeddings_tenant_model ON public.knowledge_chunk_embeddings USING btree (organization_id, model_id, model_revision);


--
-- Name: index_audit_events_on_organization_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_audit_events_on_organization_id_and_created_at ON public.audit_events USING btree (organization_id, created_at);


--
-- Name: index_audit_events_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_audit_events_on_organization_id_and_id ON public.audit_events USING btree (organization_id, id);


--
-- Name: index_customers_on_organization_id_and_external_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_customers_on_organization_id_and_external_key ON public.customers USING btree (organization_id, external_key);


--
-- Name: index_customers_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_customers_on_organization_id_and_id ON public.customers USING btree (organization_id, id);


--
-- Name: index_kb_chunks_fts_simple; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_kb_chunks_fts_simple ON public.knowledge_chunks USING gin (to_tsvector('simple'::regconfig, body));


--
-- Name: index_kb_publication_filter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_kb_publication_filter ON public.knowledge_article_versions USING btree (organization_id, status, locale);


--
-- Name: index_knowledge_article_versions_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_knowledge_article_versions_on_organization_id_and_id ON public.knowledge_article_versions USING btree (organization_id, id);


--
-- Name: index_knowledge_articles_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_knowledge_articles_on_organization_id_and_id ON public.knowledge_articles USING btree (organization_id, id);


--
-- Name: index_memberships_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_memberships_on_organization_id_and_id ON public.memberships USING btree (organization_id, id);


--
-- Name: index_memberships_on_organization_id_and_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_memberships_on_organization_id_and_user_id ON public.memberships USING btree (organization_id, user_id);


--
-- Name: index_nm_order_items_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_order_items_on_organization_id_and_id ON public.nm_order_items USING btree (organization_id, id);


--
-- Name: index_nm_orders_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_orders_on_organization_id_and_id ON public.nm_orders USING btree (organization_id, id);


--
-- Name: index_nm_orders_on_organization_id_and_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_orders_on_organization_id_and_order_number ON public.nm_orders USING btree (organization_id, order_number);


--
-- Name: index_nm_payments_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_payments_on_organization_id_and_id ON public.nm_payments USING btree (organization_id, id);


--
-- Name: index_nm_payments_on_organization_id_and_payment_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_payments_on_organization_id_and_payment_key ON public.nm_payments USING btree (organization_id, payment_key);


--
-- Name: index_nm_products_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_products_on_organization_id_and_id ON public.nm_products USING btree (organization_id, id);


--
-- Name: index_nm_products_on_organization_id_and_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_products_on_organization_id_and_sku ON public.nm_products USING btree (organization_id, sku);


--
-- Name: index_nm_return_items_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_return_items_on_organization_id_and_id ON public.nm_return_items USING btree (organization_id, id);


--
-- Name: index_nm_return_requests_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_return_requests_on_organization_id_and_id ON public.nm_return_requests USING btree (organization_id, id);


--
-- Name: index_nm_return_requests_on_organization_id_and_request_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_return_requests_on_organization_id_and_request_key ON public.nm_return_requests USING btree (organization_id, request_key);


--
-- Name: index_nm_shipment_items_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_shipment_items_on_organization_id_and_id ON public.nm_shipment_items USING btree (organization_id, id);


--
-- Name: index_nm_shipments_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_shipments_on_organization_id_and_id ON public.nm_shipments USING btree (organization_id, id);


--
-- Name: index_nm_shipments_on_organization_id_and_shipment_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_shipments_on_organization_id_and_shipment_key ON public.nm_shipments USING btree (organization_id, shipment_key);


--
-- Name: index_nm_warranty_claims_on_organization_id_and_claim_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_warranty_claims_on_organization_id_and_claim_key ON public.nm_warranty_claims USING btree (organization_id, claim_key);


--
-- Name: index_nm_warranty_claims_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_nm_warranty_claims_on_organization_id_and_id ON public.nm_warranty_claims USING btree (organization_id, id);


--
-- Name: index_organizations_on_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_organizations_on_slug ON public.organizations USING btree (slug);


--
-- Name: index_tf_activation_events_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_activation_events_on_organization_id_and_id ON public.tf_activation_events USING btree (organization_id, id);


--
-- Name: index_tf_api_request_events_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_api_request_events_on_organization_id_and_id ON public.tf_api_request_events USING btree (organization_id, id);


--
-- Name: index_tf_api_request_events_on_organization_id_and_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_api_request_events_on_organization_id_and_request_id ON public.tf_api_request_events USING btree (organization_id, request_id);


--
-- Name: index_tf_export_jobs_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_export_jobs_on_organization_id_and_id ON public.tf_export_jobs USING btree (organization_id, id);


--
-- Name: index_tf_export_jobs_on_organization_id_and_job_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_export_jobs_on_organization_id_and_job_key ON public.tf_export_jobs USING btree (organization_id, job_key);


--
-- Name: index_tf_invoices_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_invoices_on_organization_id_and_id ON public.tf_invoices USING btree (organization_id, id);


--
-- Name: index_tf_invoices_on_organization_id_and_invoice_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_invoices_on_organization_id_and_invoice_number ON public.tf_invoices USING btree (organization_id, invoice_number);


--
-- Name: index_tf_service_incidents_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_service_incidents_on_organization_id_and_id ON public.tf_service_incidents USING btree (organization_id, id);


--
-- Name: index_tf_service_incidents_on_organization_id_and_incident_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_service_incidents_on_organization_id_and_incident_key ON public.tf_service_incidents USING btree (organization_id, incident_key);


--
-- Name: index_tf_subscriptions_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_subscriptions_on_organization_id_and_id ON public.tf_subscriptions USING btree (organization_id, id);


--
-- Name: index_tf_subscriptions_on_organization_id_and_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_subscriptions_on_organization_id_and_workspace_id ON public.tf_subscriptions USING btree (organization_id, workspace_id);


--
-- Name: index_tf_workspaces_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_workspaces_on_organization_id_and_id ON public.tf_workspaces USING btree (organization_id, id);


--
-- Name: index_tf_workspaces_on_organization_id_and_workspace_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tf_workspaces_on_organization_id_and_workspace_key ON public.tf_workspaces USING btree (organization_id, workspace_key);


--
-- Name: index_ticket_messages_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_ticket_messages_on_organization_id_and_id ON public.ticket_messages USING btree (organization_id, id);


--
-- Name: index_tickets_on_organization_id_and_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tickets_on_organization_id_and_id ON public.tickets USING btree (organization_id, id);


--
-- Name: index_tickets_on_organization_id_and_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_tickets_on_organization_id_and_number ON public.tickets USING btree (organization_id, number);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: nm_items_order_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX nm_items_order_composite ON public.nm_order_items USING btree (organization_id, order_id, id);


--
-- Name: nm_returns_order_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX nm_returns_order_composite ON public.nm_return_requests USING btree (organization_id, order_id, id);


--
-- Name: nm_ships_order_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX nm_ships_order_composite ON public.nm_shipments USING btree (organization_id, order_id, id);


--
-- Name: tf_invoices_subscription_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tf_invoices_subscription_composite ON public.tf_invoices USING btree (organization_id, subscription_id, id);


--
-- Name: tf_subscriptions_workspace_composite; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tf_subscriptions_workspace_composite ON public.tf_subscriptions USING btree (organization_id, workspace_id, id);


--
-- Name: uniq_chunk_embedding_model_revision; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_chunk_embedding_model_revision ON public.knowledge_chunk_embeddings USING btree (organization_id, knowledge_chunk_id, model_id, model_revision);


--
-- Name: uniq_current_published_kb_language; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_current_published_kb_language ON public.knowledge_article_versions USING btree (organization_id, knowledge_article_id, locale) WHERE ((status)::text = 'approved'::text);


--
-- Name: uniq_kb_article_tenant_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_kb_article_tenant_key ON public.knowledge_articles USING btree (organization_id, article_key);


--
-- Name: uniq_kb_chunk_per_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_kb_chunk_per_version ON public.knowledge_chunks USING btree (organization_id, knowledge_article_version_id, chunk_index);


--
-- Name: uniq_kb_version_per_locale; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_kb_version_per_locale ON public.knowledge_article_versions USING btree (organization_id, knowledge_article_id, locale, version_number);


--
-- Name: uniq_knowledge_chunks_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_knowledge_chunks_tenant_id ON public.knowledge_chunks USING btree (organization_id, id);


--
-- Name: uniq_message_tenant_idempotency; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_message_tenant_idempotency ON public.ticket_messages USING btree (organization_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: uniq_nm_order_item_sku_snapshot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_nm_order_item_sku_snapshot ON public.nm_order_items USING btree (organization_id, order_id, sku_snapshot);


--
-- Name: uniq_nm_return_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_nm_return_item ON public.nm_return_items USING btree (organization_id, return_request_id, order_item_id);


--
-- Name: uniq_nm_ship_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_nm_ship_item ON public.nm_shipment_items USING btree (organization_id, shipment_id, order_item_id);


--
-- Name: uniq_tf_activation_in_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_tf_activation_in_invoice ON public.tf_activation_events USING btree (organization_id, subscription_id, invoice_id, result);


--
-- Name: knowledge_chunk_embeddings fk_chunk_embeddings_tenant; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_chunk_embeddings
    ADD CONSTRAINT fk_chunk_embeddings_tenant FOREIGN KEY (organization_id, knowledge_chunk_id) REFERENCES public.knowledge_chunks(organization_id, id);


--
-- Name: audit_events fk_rails_03bd4ae43f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT fk_rails_03bd4ae43f FOREIGN KEY (organization_id, ticket_id) REFERENCES public.tickets(organization_id, id);


--
-- Name: tf_workspaces fk_rails_0badbd3f00; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_workspaces
    ADD CONSTRAINT fk_rails_0badbd3f00 FOREIGN KEY (organization_id, owner_user_id) REFERENCES public.memberships(organization_id, user_id);


--
-- Name: tf_invoices fk_rails_0bbaed7e89; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_invoices
    ADD CONSTRAINT fk_rails_0bbaed7e89 FOREIGN KEY (organization_id, workspace_id, subscription_id) REFERENCES public.tf_subscriptions(organization_id, workspace_id, id);


--
-- Name: nm_orders fk_rails_1f0600b666; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_orders
    ADD CONSTRAINT fk_rails_1f0600b666 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_subscriptions fk_rails_23d47cd851; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_subscriptions
    ADD CONSTRAINT fk_rails_23d47cd851 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tickets fk_rails_2a0cf1501f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_rails_2a0cf1501f FOREIGN KEY (organization_id, assignee_id) REFERENCES public.memberships(organization_id, user_id);


--
-- Name: nm_shipments fk_rails_3232913625; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipments
    ADD CONSTRAINT fk_rails_3232913625 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_return_items fk_rails_3592b67bfa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_items
    ADD CONSTRAINT fk_rails_3592b67bfa FOREIGN KEY (organization_id, order_id, order_item_id) REFERENCES public.nm_order_items(organization_id, order_id, id);


--
-- Name: nm_warranty_claims fk_rails_3883298422; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_warranty_claims
    ADD CONSTRAINT fk_rails_3883298422 FOREIGN KEY (organization_id, order_item_id) REFERENCES public.nm_order_items(organization_id, id);


--
-- Name: tf_api_request_events fk_rails_3ef79fba00; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_api_request_events
    ADD CONSTRAINT fk_rails_3ef79fba00 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_export_jobs fk_rails_41a481abd1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_export_jobs
    ADD CONSTRAINT fk_rails_41a481abd1 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_shipment_items fk_rails_423d9a01e9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipment_items
    ADD CONSTRAINT fk_rails_423d9a01e9 FOREIGN KEY (organization_id, order_id, shipment_id) REFERENCES public.nm_shipments(organization_id, order_id, id);


--
-- Name: tf_activation_events fk_rails_42502039e5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_activation_events
    ADD CONSTRAINT fk_rails_42502039e5 FOREIGN KEY (organization_id, subscription_id, invoice_id) REFERENCES public.tf_invoices(organization_id, subscription_id, id);


--
-- Name: nm_shipments fk_rails_44f0763770; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipments
    ADD CONSTRAINT fk_rails_44f0763770 FOREIGN KEY (organization_id, order_id) REFERENCES public.nm_orders(organization_id, id);


--
-- Name: nm_return_requests fk_rails_50276869fd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_requests
    ADD CONSTRAINT fk_rails_50276869fd FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: customers fk_rails_58234c715e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT fk_rails_58234c715e FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: knowledge_chunks fk_rails_5a7f2b8457; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT fk_rails_5a7f2b8457 FOREIGN KEY (organization_id, knowledge_article_version_id) REFERENCES public.knowledge_article_versions(organization_id, id);


--
-- Name: tf_api_request_events fk_rails_614955293d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_api_request_events
    ADD CONSTRAINT fk_rails_614955293d FOREIGN KEY (organization_id, workspace_id) REFERENCES public.tf_workspaces(organization_id, id);


--
-- Name: memberships fk_rails_64267aab58; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT fk_rails_64267aab58 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_shipment_items fk_rails_6eb6d65439; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipment_items
    ADD CONSTRAINT fk_rails_6eb6d65439 FOREIGN KEY (organization_id, order_id, order_item_id) REFERENCES public.nm_order_items(organization_id, order_id, id);


--
-- Name: tf_activation_events fk_rails_6fd5d5b5be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_activation_events
    ADD CONSTRAINT fk_rails_6fd5d5b5be FOREIGN KEY (organization_id, subscription_id) REFERENCES public.tf_subscriptions(organization_id, id);


--
-- Name: tf_export_jobs fk_rails_7c0031ff0c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_export_jobs
    ADD CONSTRAINT fk_rails_7c0031ff0c FOREIGN KEY (organization_id, workspace_id) REFERENCES public.tf_workspaces(organization_id, id);


--
-- Name: nm_orders fk_rails_7c63a0a327; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_orders
    ADD CONSTRAINT fk_rails_7c63a0a327 FOREIGN KEY (organization_id, customer_id) REFERENCES public.customers(organization_id, id);


--
-- Name: nm_return_items fk_rails_7cbdae526f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_items
    ADD CONSTRAINT fk_rails_7cbdae526f FOREIGN KEY (organization_id, order_id, return_request_id) REFERENCES public.nm_return_requests(organization_id, order_id, id);


--
-- Name: ticket_messages fk_rails_7fe43ed8b1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT fk_rails_7fe43ed8b1 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_shipment_items fk_rails_85125b0f24; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_shipment_items
    ADD CONSTRAINT fk_rails_85125b0f24 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_products fk_rails_8c6626c183; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_products
    ADD CONSTRAINT fk_rails_8c6626c183 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_invoices fk_rails_8c946fc65b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_invoices
    ADD CONSTRAINT fk_rails_8c946fc65b FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_workspaces fk_rails_8d9cb084b1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_workspaces
    ADD CONSTRAINT fk_rails_8d9cb084b1 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: memberships fk_rails_99326fb65d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT fk_rails_99326fb65d FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tf_activation_events fk_rails_99e9bcb4d9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_activation_events
    ADD CONSTRAINT fk_rails_99e9bcb4d9 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_warranty_claims fk_rails_9c9e1b611a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_warranty_claims
    ADD CONSTRAINT fk_rails_9c9e1b611a FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: nm_return_items fk_rails_a38c7676eb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_items
    ADD CONSTRAINT fk_rails_a38c7676eb FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: audit_events fk_rails_a39de7fd58; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT fk_rails_a39de7fd58 FOREIGN KEY (organization_id, actor_user_id) REFERENCES public.memberships(organization_id, user_id);


--
-- Name: nm_return_requests fk_rails_a3d168dd49; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_requests
    ADD CONSTRAINT fk_rails_a3d168dd49 FOREIGN KEY (organization_id, order_id) REFERENCES public.nm_orders(organization_id, id);


--
-- Name: tickets fk_rails_a9acc485db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_rails_a9acc485db FOREIGN KEY (organization_id, customer_id) REFERENCES public.customers(organization_id, id);


--
-- Name: nm_warranty_claims fk_rails_aad0710df2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_warranty_claims
    ADD CONSTRAINT fk_rails_aad0710df2 FOREIGN KEY (organization_id, reviewed_by) REFERENCES public.memberships(organization_id, user_id);


--
-- Name: nm_return_requests fk_rails_ad93433b6c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_return_requests
    ADD CONSTRAINT fk_rails_ad93433b6c FOREIGN KEY (organization_id, reviewed_by) REFERENCES public.memberships(organization_id, user_id);


--
-- Name: knowledge_article_versions fk_rails_b2db665225; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_article_versions
    ADD CONSTRAINT fk_rails_b2db665225 FOREIGN KEY (organization_id, approved_by) REFERENCES public.memberships(organization_id, user_id);


--
-- Name: tickets fk_rails_b62b455ecb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_rails_b62b455ecb FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_subscriptions fk_rails_ba3cfce710; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_subscriptions
    ADD CONSTRAINT fk_rails_ba3cfce710 FOREIGN KEY (organization_id, workspace_id) REFERENCES public.tf_workspaces(organization_id, id);


--
-- Name: nm_order_items fk_rails_bd476846ed; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_order_items
    ADD CONSTRAINT fk_rails_bd476846ed FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: ticket_messages fk_rails_bdce308225; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT fk_rails_bdce308225 FOREIGN KEY (organization_id, ticket_id) REFERENCES public.tickets(organization_id, id);


--
-- Name: audit_events fk_rails_be0ed9e37f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT fk_rails_be0ed9e37f FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_workspaces fk_rails_c156b3a201; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_workspaces
    ADD CONSTRAINT fk_rails_c156b3a201 FOREIGN KEY (organization_id, customer_id) REFERENCES public.customers(organization_id, id);


--
-- Name: nm_payments fk_rails_c7f654980d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_payments
    ADD CONSTRAINT fk_rails_c7f654980d FOREIGN KEY (organization_id, order_id) REFERENCES public.nm_orders(organization_id, id);


--
-- Name: knowledge_article_versions fk_rails_ca97bb3d57; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_article_versions
    ADD CONSTRAINT fk_rails_ca97bb3d57 FOREIGN KEY (organization_id, knowledge_article_id) REFERENCES public.knowledge_articles(organization_id, id);


--
-- Name: nm_order_items fk_rails_d7f1a22ea5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_order_items
    ADD CONSTRAINT fk_rails_d7f1a22ea5 FOREIGN KEY (organization_id, order_id) REFERENCES public.nm_orders(organization_id, id);


--
-- Name: nm_payments fk_rails_d8ee00c2db; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nm_payments
    ADD CONSTRAINT fk_rails_d8ee00c2db FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_service_incidents fk_rails_e12ecf4700; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_service_incidents
    ADD CONSTRAINT fk_rails_e12ecf4700 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: tf_invoices fk_rails_f9ac0187a0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tf_invoices
    ADD CONSTRAINT fk_rails_f9ac0187a0 FOREIGN KEY (organization_id, workspace_id) REFERENCES public.tf_workspaces(organization_id, id);


--
-- Name: knowledge_articles fk_rails_faf7f89509; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_articles
    ADD CONSTRAINT fk_rails_faf7f89509 FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- PostgreSQL database dump complete
--

SET search_path TO "$user", public;

INSERT INTO "schema_migrations" (version) VALUES
('20261029010000'),
('20261028000500'),
('20261028000400'),
('20261028000300'),
('20261028000200'),
('20261028000100');

