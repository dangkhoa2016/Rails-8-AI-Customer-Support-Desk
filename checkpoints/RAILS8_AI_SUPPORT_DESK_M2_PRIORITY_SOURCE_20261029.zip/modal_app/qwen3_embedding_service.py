"""Modal embedding service (SOURCE_ONLY; not deployed or benchmarked).
Requires Modal Secret rails8-support-desk-embedding with:
 EMBED_API_TOKEN = random secret (20+ chars)
 EMBED_MODEL_REVISION = pinned full 40-char HF commit.
Never send raw customer data; only reviewed/approved synthetic KB text.
"""
import hashlib
import hmac
import os
import modal

MODEL_ID = "Qwen/Qwen3-Embedding-0.6B"
DIMENSIONS = 1024
app = modal.App("rails8-support-desk-m2-embeddings")
image = modal.Image.debian_slim(python_version="3.11").pip_install(
    "torch==2.6.0",
    "transformers==4.51.3",
    "sentence-transformers==4.1.0",
    "fastapi==0.115.12",
    "pydantic==2.11.3",
)


@app.function(
    image=image,
    gpu="T4",
    timeout=600,
    scaledown_window=180,
    secrets=[modal.Secret.from_name("rails8-support-desk-embedding")],
)
@modal.asgi_app()
def embedding_api():
    from fastapi import FastAPI, Header, HTTPException
    from pydantic import BaseModel, Field
    from typing import Literal
    from functools import lru_cache

    web = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    class RequestPayload(BaseModel):
        texts: list[str] = Field(min_length=1, max_length=16)
        kind: Literal["document", "query"]

    @lru_cache(maxsize=1)
    def get_model():
        from sentence_transformers import SentenceTransformer
        revision = os.environ.get("EMBED_MODEL_REVISION", "")
        if len(revision) != 40 or not all(c in "0123456789abcdef" for c in revision.lower()):
            raise RuntimeError("EMBED_MODEL_REVISION must be a pinned 40-character commit SHA")
        return SentenceTransformer(MODEL_ID, revision=revision, device="cuda")

    @web.post("/embed")
    def embed(payload: RequestPayload, authorization: str = Header(default="")):
        token = os.environ.get("EMBED_API_TOKEN", "")
        supplied = authorization.removeprefix("Bearer ")
        if len(token) < 20 or not hmac.compare_digest(supplied, token):
            raise HTTPException(status_code=401, detail="unauthorized")
        if any(not t.strip() or len(t.encode("utf-8")) > 16_384 for t in payload.texts):
            raise HTTPException(status_code=422, detail="invalid text size")
        vectors = get_model().encode(
            payload.texts,
            prompt_name="query" if payload.kind == "query" else None,
            normalize_embeddings=True,
            batch_size=min(8, len(payload.texts)),
            show_progress_bar=False,
        ).tolist()
        if any(len(v) != DIMENSIONS for v in vectors):
            raise HTTPException(status_code=500, detail="dimension mismatch")
        return {
            "model_id": MODEL_ID,
            "model_revision": os.environ["EMBED_MODEL_REVISION"],
            "kind": payload.kind,
            "dimensions": DIMENSIONS,
            "input_sha256": [hashlib.sha256(t.encode("utf-8")).hexdigest() for t in payload.texts],
            "vectors": vectors,
        }

    return web
