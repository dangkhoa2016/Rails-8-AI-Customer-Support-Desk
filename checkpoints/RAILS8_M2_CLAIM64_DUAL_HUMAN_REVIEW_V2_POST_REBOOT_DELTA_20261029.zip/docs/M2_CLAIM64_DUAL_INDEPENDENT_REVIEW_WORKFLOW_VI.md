# M2 — Kiểm duyệt độc lập 64 claim (VI)

**Ngày:** 29/10/2026. **Trạng thái:** REVIEW_WORKBOOK_READY / HUMAN_ADJUDICATION_NOT_RUN / NOT_RELEASE.

## 1. Căn cứ và phạm vi

Rails 8 AI Customer Support Desk gồm hai doanh nghiệp synthetic TeamFlow Cloud và NovaMart Store. Bộ M0 20 business policies v1.0.0 đã được phê duyệt. Nguồn kiểm duyệt gồm 64 claim độc lập thuộc 32 câu tổng hợp, cùng 12 bài Knowledge Base approved v2, với article version, tenant, locale và body SHA256. Không thay đổi nguồn, không sửa mốc nghiệm thu trước hoặc trạng thái scope gate đã bị khóa sau sealed80 FAIL.

Kết quả partition-aware gần nhất chỉ chứng minh dữ liệu nguồn và ID có thể được xác minh ở tầng cấu trúc trên tập development; nó KHÔNG chứng minh correct policy entailment, semantic answerability, độ đúng phủ định hoặc độ chính xác production. AI không được ghi nghiệp vụ, tự hoàn tiền, kích hoạt gói, gửi hàng hoặc trả lời khách hàng mà không qua người phụ trách.

## 2. Workbook tiếng Việt và tiếng Anh

Hai file chính ở thư mục evidence-m2-claim64-independent-review-v2-20261029:
- index.vi.html
- index.en.html

Mã tạo file: script/render_m2_independent_review_v2.py. Hàng đợi frozen: evidence-m2-claim32x2-20261029/claim-level-blind-human-validation.json. KB approved frozen: evidence-m2-claim64-provisional-audit-20261029/approved-kb-v2-readonly-snapshot.json.

Mỗi workbook hiển thị đủ 64 claim, câu tổng hợp, mệnh đề độc lập và 12 bài KB approved. Giao diện tách riêng tiếng Việt/Anh; văn bản nguồn của từng claim vẫn giữ nguyên locale. Không hiển thị developer gold, gợi ý AI, assistant posthoc labels hoặc lựa chọn của reviewer khác. Reviewer có thể lọc tenant/locale, xem KB, dán trích dẫn chính xác, xuất bản nháp JSON, nhập lại bản nháp để tiếp tục và xuất bản hoàn tất khi đủ điều kiện.

**Không có autosave:** file HTML không lưu browser storage, không gọi API, không chạy inference, không gửi dữ liệu về server. Hãy xuất JSON nháp thường xuyên trước khi thoát hoặc đổi máy. Import kiểm tra source manifest SHA256, candidate evidence SHA256, KB snapshot SHA256, đủ 64 ID riêng biệt và tenant/locale trước khi khôi phục.

## 3. Tiêu chí cho người kiểm duyệt thật

- affirmative_policy: chính sách hỗ trợ câu trả lời khẳng định / có điều kiện; cần bài KB cùng tenant, locale và đoạn trích nguyên văn ít nhất 20 ký tự.
- explicit_negative_policy: bài KB rõ ràng hỗ trợ câu trả lời KHÔNG, khác với trường hợp chưa có thông tin; cũng phải dẫn trích nguyên văn.
- not_documented: KB approved không quy định; không chọn bài KB làm nguồn hỗ trợ và viết ít nhất 20 ký tự giải thích kết quả rà soát.
- uncertain_needs_second_reviewer: cần phân xử thêm, giải thích tối thiểu 20 ký tự; không được coi là review hoàn tất.

Bản final mang trạng thái COMPLETE_SELF_ATTESTED_UNVERIFIED chỉ được xuất nếu 64/64 hợp lệ, không unresolved, người review có ID và đánh dấu tự xác nhận. Đây không xác minh danh tính, tính độc lập hay quyền phê duyệt release.

## 4. Hai reviewer độc lập

Reviewer A và B làm việc riêng, không chia sẻ kết luận trước khi hoàn tất và lưu hai JSON riêng. Dùng những lệnh sau khi đã có file từ người thật:

    python3 script/validate_m2_external_review_export.py /path/reviewer-a.json
    python3 script/validate_m2_external_review_export.py /path/reviewer-b.json
    python3 script/compare_m2_dual_external_reviews.py /path/reviewer-a.json /path/reviewer-b.json --output /path/dual-comparison.json

Validator kiểm tra tất cả claim và trích dẫn exact source; tool so sánh phát hiện disagreement về label / cited article, tổng hợp Cohen kappa (chỉ chẩn đoán) và tenant×locale breakdown. Hai reviewer thống nhất 100% vẫn không xác nhận policy correctness. Công cụ luôn khóa release; cần người thật phân xử, xác thực độc lập, owner signoff và sealed holdout hoàn toàn mới.

Không tạo JSON reviewer thực bằng AI; những fixture dùng trong unit tests chỉ là dữ liệu giả, không được đưa vào release pipeline.

## 5. Khôi phục sau Colab reboot

Thiết bị mới d912002e2a9f (device ID d2536713-6975-49cb-8955-969067f3726f). Repository/previous checkpoint còn, nhưng workbook v2 chưa sao lưu ở thiết bị cũ. Đã phục hồi mới hai HTML và tool so sánh trên thiết bị này. Chromium headless đã mở cả hai trang, kiểm tra đủ cards/KB, import nháp, final gating và không network request: PASS hai ngôn ngữ. Dual-review validator unit tests 8/8 PASS.

Mật khẩu preview và Modal CLI credentials từ Colab cũ không tự xuất hiện trên máy mới. Mọi Quick Tunnel mới phải sử dụng bí mật đủ mạnh, giới hạn chỉ HTML approved; không đưa mật khẩu hoặc link tạm vào Git.

## 6. Điểm tiếp tục

Chờ hai bản reviewer JSON thực, chạy validator và đối chiếu bất đồng. Human semantic acceptance hiện NOT_RUN; scope gate và claim-level release tiếp tục BLOCKED. Không chạy lại GPU để giả lập vai trò người kiểm duyệt.
