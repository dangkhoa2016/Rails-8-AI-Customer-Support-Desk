# M3 — Fix "Switch account" on the Cloudflare Private Demo

Date: 2026-10-29. App: Rails 8 AI Customer Support Desk.

## Root cause

After selecting a demo role, clicking **Switch account** returned HTTP 405, `Public preview is read-only: changes disabled`.

The error was reproduced before the patch through Cloudflare HTTPS. Rails `button_to method: :delete` submits an HTML **POST /demo/sign_out** with a hidden `_method=delete` field. The outer private-preview gate previously allowed only a literal HTTP DELETE, so it rejected this legitimate session-only form before Rails could apply method override.

## Scoped remediation

In `lib/private_colab_preview_gate.rb`, allow **only** `POST /demo/sign_out` with `_method=delete` (plus the already accepted literal DELETE). Keep Rails' DELETE route, session reset and CSRF checks. Do not add a GET logout route or loosen business-mutation rules.

Added evidence and regression:
- `test/unit/private_colab_preview_role_switch_test.rb` — exact allowed logout form; deny plain POST, POST with patch override, ticket mutations, KB approval and wrong hostname.
- `test/integration/demo_account_role_guide_test.rb` — real Rails logout resets session and returns to the six-account picker.
- `test/smoke_private_preview_role_switch.py` — localhost and Cloudflare HTTPS end-to-end test switching TeamFlow Viewer → NovaMart Owner without business writes.

## Results

- **Before:** HTTPS logout form yielded HTTP 405.
- **After:** localhost and HTTPS form submission redirect HTTP 302 to `/demo/sign_in`; second sign-in as NovaMart Owner and dashboard HTTP 200.
- **Safety:** HTTPS POST /tickets, POST /knowledge_articles/1/approve, PATCH /tickets/1/status, and unqualified POST /demo/sign_out remain HTTP 405.
- **Rails regression:** 89 tests / 4,568 assertions / zero failures/errors/skips.
- **Invariants:** 240 tickets, 440 messages, 84 embeddings, 12 approved KB v2; sealed80 answerability remains BLOCKED.
- Cloudflare hostname and private password unchanged. Rails was restarted to load the updated middleware. No GPU calls, business data modifications, Git commit or push.
- No passwords, session cookies, or CSRF tokens are included in evidence.

## User workflow

Log in to the private preview, choose a tenant and Viewer/Agent/Owner account. Click **Switch account** in navigation to return to the account picker and select a different tenant/role. **Session switching is allowed; business state mutations remain blocked over the public tunnel.**
