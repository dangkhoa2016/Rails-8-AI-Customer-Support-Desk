# M3 — Sửa nút Đổi tài khoản trên Cloudflare Private Demo

Ngày: 2026-10-29. Ứng dụng: Rails 8 AI Customer Support Desk.

## Vấn đề

Khi đăng nhập rồi nhấn **Đổi tài khoản** từ thanh điều hướng, người dùng gặp HTTP 405: `Public preview is read-only: changes disabled`.

Đã tái hiện trên Cloudflare HTTPS trước khi sửa: trình duyệt gửi **HTTP POST /demo/sign_out** với hidden form field `_method=delete` (Rails `button_to method: :delete`). Middleware `PrivateColabPreviewGate` trước đó chỉ cho phép request có HTTP method DELETE và do vậy chặn POST hợp lệ trước khi Rack/Rails xử lý method override.

## Sửa giới hạn phạm vi

File `lib/private_colab_preview_gate.rb`: cho phép **chính xác** `POST /demo/sign_out` nếu form có `_method=delete`, và tiếp tục cho phép HTTP DELETE vốn có. Rails routes vẫn là DELETE, xử lý CSRF token và `reset_session`. Không tạo endpoint GET để logout và không nới chính sách read-only cho business data.

Bổ sung:
- `test/unit/private_colab_preview_role_switch_test.rb`: cho phép POST+delete override và từ chối POST thường, POST patch, ticket mutation, KB approval và hostname giả.
- `test/integration/demo_account_role_guide_test.rb`: kiểm tra Rails logout reset session và quay lại dropdown lựa chọn tài khoản.
- `test/smoke_private_preview_role_switch.py`: thử thật localhost và Cloudflare HTTPS; đăng nhập TeamFlow Viewer → Đổi tài khoản → NovaMart Owner, không thao tác ghi business.

## Kết quả nghiệm thu

- Trước sửa: HTTPS POST+_method=delete → **405** (evidence `pre-fix-failure.json`).
- Sau sửa: localhost & HTTPS POST+_method=delete → **302** về `/demo/sign_in`, sau đó chọn NovaMart Owner thành công và dashboard **200**.
- Security: POST /tickets, POST /knowledge_articles/1/approve, PATCH /tickets/1/status, POST /demo/sign_out không có đúng method override đều **405** trên HTTPS.
- Rails test suite **89 tests / 4.568 assertions / 0 failures / 0 errors / 0 skips**.
- DB: 240 tickets, 440 messages, 84 embeddings, 12 approved KB versions, sealed80 vẫn BLOCKED.
- Cloudflare origin và mật khẩu preview không đổi; Rails chỉ được restart để nạp middleware mới. Không chạy GPU, không sửa business dataset, không commit/push.
- Không lưu mật khẩu, session cookie hay CSRF token trong evidence.

## Hướng dẫn sử dụng

1. Mở Private Demo, nhập mật khẩu và chọn tài khoản Viewer, Agent hoặc Owner.
2. Trong thanh điều hướng, chọn **Đổi tài khoản**.
3. Dropdown đăng nhập xuất hiện; chọn role/tenant khác để so sánh quyền.

Điểm khác biệt: đổi tài khoản là thao tác **session** được phép; thay đổi dữ liệu nghiệp vụ qua tunnel vẫn bị khóa.
