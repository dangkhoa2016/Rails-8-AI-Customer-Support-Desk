# M2 — Tenant-Scoped Examples and Evidence Abstention (EN)

**Date:** 2026-10-29 (ICT)  
**Status:** M2 internal synthetic pilot; NOT production-ready.  
**Tenants:** TeamFlow Cloud and NovaMart Store.

## Problem

The user selected NovaMart Store and asked about a paid SaaS invoice and unactivated plan. The original search displayed five irrelevant NovaMart shipping/return passages. SQL correctly enforced the NovaMart tenant boundary; the exact same query correctly retrieved `TF-KB-012` in TeamFlow. This was a relevance/abstention/UX failure, **not established cross-tenant leakage**.

## Implemented

- VI/EN example questions now follow `current_organization.slug`; unknown tenants receive no examples for either business.
- The UI identifies the active organization and offers a demo-account switch link. There is **no automatic tenant switching**.
- `KnowledgeRelevanceGate` loads `review/m2_relevance_gate_pilot_20261029.json`. It verifies pinned 4B/4B revisions, a fingerprint of the 12 approved versions, 84 embeddings, and organization policy versions **before calling GPU**. A corpus change fails closed until recalibrated.
- Candidates remain tenant/ACL/approved/locale/date/SHA-filtered before Modal. The calibrated gate filters individual ranked chunks; returning zero or fewer than five chunks is expected. The UI clearly states that no sufficiently supported evidence was found and requires human review.
- No business writes, policy changes, editorial approvals, reseeding, embeddings regeneration or model redeployment.

## Labeled evaluation and conservative cutoff

Synthetic VI/EN questions were human-labeled against the six approved v2 KB articles independently of model outputs.

| Phase | Supported | Unsupported | Observation |
|---|---:|---:|---|
| Initial set | 12 | 20 | First provisional 5.4375 cutoff separated these examples |
| Stress | 4 | 12 | One false positive on API quota change intent |
| Lockbox | 4 | 8 | Another false positive for hourly delivery rescheduling at provisional 6.328125 |
| Final frozen holdout | 4 | 8 | Not used to fit the final cutoff |

Using the first 60 cases, a **conservative raw-logit threshold of 7.421875** was selected as the midpoint between the highest unsupported score (7.3828125) and the next higher supported score (7.4609375). The objective is to prioritize avoiding false positives; positive evidence can be withheld.

- Calibration set: **18/20 supported accepted with correct Top-1**, **40/40 unsupported rejected**; 2 supported cases conservatively abstained.
- Frozen final holdout: **4/4 supported accepted**, **8/8 unsupported rejected**.
- These are *small pilot samples*, **not production precision/recall claims**. Raw logits are not probabilities, and the cutoff is invalidated by any material approved-corpus change.

### Real GPU acceptance after Rails integration

- NovaMart + SaaS activation question (VI): **0 qualified results**, PASS.
- TeamFlow + identical question (VI): **`TF-KB-012` Top-1**, two qualified chunks with citation/SHA256, PASS.
- NovaMart + shipping threshold question (VI): **`NM-KB-014` Top-1**, two qualified chunks, PASS.
- The three queries used real pinned Qwen3-Embedding-4B and Qwen3-Reranker-4B on Modal, sequentially, with no modifications to the original **100 articles, 212 versions, 12 approved versions, 84 embeddings**.
- Timing includes any cold start; see `evidence-m2-relevance-20261029/live-gate-acceptance.json`.

## Provenance

- `review/m2_relevance_{eval,stress_eval,lockbox_eval,final_holdout}_20261029.json`: prompts and preassigned labels.
- `evidence-m2-relevance-20261029/{live-eval,stress-eval,lockbox-eval,final-holdout}.jsonl`: live scores, citations, cosine distances and query SHA256.
- `review/m2_relevance_gate_pilot_20261029.json`: cutoff derivation, evidence hashes, pinned models and database fingerprint.
- `script/m2_relevance_live_evaluate.rb`, `script/build_m2_relevance_gate.rb`, `script/verify_m2_relevance_live_gate.rb`.
- `app/services/knowledge_relevance_gate.rb`, reranked retrieval service, controller/view and VI/EN locales.
- Synthetic-only queries; no credentials or personal data in reports. Fixture seed: `20261029`; deterministic inference prompts; one sequential caller.

## Limits and future gates

1. A relevance score is **not a complete-answer or entailment validator**. A topically similar but unsupported user request may still receive a false-positive evidence suggestion.
2. Two of the 20 calibration positives were withheld. Abstention does not prove that no answer exists; have a human review.
3. Only 6 of 100 articles have approved v2 content. Expand the editorial set only with human approval; rebuild calibration for each new approved-corpus snapshot.
4. Obtain larger sealed evaluation sets and measure per-tenant/per-language false positives, false abstentions, partial-answer failures and adversarial paraphrases. Evaluate an independent answerability verification step before public launch.
5. Quick Tunnel/password demo and GPU budgets are internal synthetic pilot controls, not production authentication or cost governance. No autonomous business writes or M3 release authorization.

**Not performed:** database reset/reseed, re-embedding, model replacement, Modal redeployment, Git commit/push.
