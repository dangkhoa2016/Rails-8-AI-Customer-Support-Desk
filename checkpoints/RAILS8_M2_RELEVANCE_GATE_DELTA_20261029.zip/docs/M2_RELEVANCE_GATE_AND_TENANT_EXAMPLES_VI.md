# M2 — Tìm kiếm KB theo tenant và từ chối bằng chứng không đủ liên quan (VI)

**Ngày:** 2026-10-29 (ICT)  
**Trạng thái:** Thử nghiệm M2, không phải production-ready.  
**Phạm vi:** TeamFlow Cloud và NovaMart Store (dữ liệu synthetic).

## Bối cảnh

Trước cải thiện, người dùng chọn NovaMart Store nhưng hỏi về hóa đơn SaaS đã thanh toán mà gói chưa kích hoạt. Ứng dụng trả 5 đoạn shipping/return NovaMart không phù hợp. SQL vẫn lọc đúng tenant. Cùng câu đó tại TeamFlow Cloud trả `TF-KB-012` bằng GPU thật. Đây là **false relevance**, không phải bằng chứng cross-tenant leak.

## Thay đổi

- Ví dụ VI/EN được chọn theo `current_organization.slug`. Tenant không nhận diện không có ví dụ của doanh nghiệp khác.
- Giao diện nhấn mạnh tên tenant, phạm vi KB và đường dẫn đổi demo membership; **không tự chuyển tenant**.
- `KnowledgeRelevanceGate` đọc ngưỡng từ `review/m2_relevance_gate_pilot_20261029.json`, xác minh pinned model và fingerprint 12 approved versions/84 embeddings cùng policy version trước GPU. Nếu snapshot thay đổi, truy vấn bị khóa an toàn và yêu cầu hiệu chỉnh lại.
- Chỉ các chunk có rerank logit đủ cao mới được hiển thị; số kết quả có thể bằng 0 hoặc nhỏ hơn 5. UI hiện trạng thái không đủ bằng chứng và đề nghị nhân viên xem xét, không giả vờ đã có câu trả lời.
- Tenant/ACL/approved/locale/date/digest filters vẫn thực hiện **trước khi gửi candidate sang Modal**. Không đổi policy, editorial approval, dữ liệu giao dịch, model hoặc deployment.

## Hiệu chỉnh có nhãn và chống overfitting

Các câu đều synthetic, VI/EN, gold labels được viết từ 6 bài KB v2 đã approved, không lấy từ output AI.

| Giai đoạn | Có bằng chứng | Không có bằng chứng | Ghi chú |
|---|---:|---:|---|
| Tập 32 ban đầu | 12 | 20 | Ngưỡng thử đầu 5.4375 tách được tập này |
| Stress 16 | 4 | 12 | Phát hiện 1 false positive khi hỏi tăng API quota |
| Lockbox 12 | 4 | 8 | Phát hiện thêm 1 false positive với câu hẹn lịch giao hàng theo giờ ở ngưỡng 6.328125 |
| Frozen final holdout 12 | 4 | 8 | **Không dùng để chọn ngưỡng cuối** |

Sau 60 mẫu đầu, chọn ngưỡng **7.421875** theo quy tắc định sẵn: trung điểm giữa negative lớn nhất 7.3828125 và positive gần nhất phía trên 7.4609375, ưu tiên loại false positive. Trong 60 mẫu sử dụng để hiệu chỉnh: **18/20 positive được nhận**, **40/40 negative bị từ chối**; 2 positive bị từ chối bảo thủ. Trong frozen holdout tiếp theo: **4/4 positive được nhận**, **8/8 negative bị từ chối**. Các số này là **mẫu nhỏ, KHÔNG phải ước lượng độ chính xác production**. Raw logit không phải xác suất; không suy luận rằng ngưỡng vẫn đúng với các KB version hay loại câu hỏi mới.

### Đối chứng GPU sau khi tích hợp Rails

- NovaMart + câu hỏi SaaS activation VI: **0 kết quả**, PASS.
- TeamFlow + cùng câu VI: **TF-KB-012** Top-1, 2 qualified chunks giữ citation/SHA256, PASS.
- NovaMart + shipping fee VI: **NM-KB-014** Top-1, 2 qualified chunks, PASS.
- Tất cả 3 lời gọi qua mô hình 4B/4B thật, sequential, không thay đổi 100 bài / 212 versions / 12 approved / 84 embeddings.
- Thời gian lần đầu bao gồm cold start; xem `evidence-m2-relevance-20261029/live-gate-acceptance.json`.

## Truy vết

- `review/m2_relevance_{eval,stress_eval,lockbox_eval,final_holdout}_20261029.json`: câu hỏi và nhãn.
- `evidence-m2-relevance-20261029/{live-eval,stress-eval,lockbox-eval,final-holdout}.jsonl`: results thực, từng citation, logit, cosine, hash câu.
- `review/m2_relevance_gate_pilot_20261029.json`: công thức hiệu chỉnh, mức ngưỡng, model pin, DB fingerprint, SHA256 của evidence.
- `script/m2_relevance_live_evaluate.rb`, `script/build_m2_relevance_gate.rb`, `script/verify_m2_relevance_live_gate.rb`.
- `app/services/knowledge_relevance_gate.rb`, `knowledge_reranked_retrieval.rb`, Rails controller/view, locale VI/EN.
- Không chứa credentials/PII; truy vấn chỉ synthetic. Seed fixture: `20261029`; không có sampling ngẫu nhiên khi inference; 1 luồng tuần tự.

## Rủi ro và bước tiếp

1. Gate mới đo **mức liên quan của đoạn**, không phải kiểm chứng từng mệnh đề/khả năng trả lời đầy đủ. Một câu có chủ đề giống KB nhưng đòi thông tin chưa hỗ trợ vẫn có nguy cơ false positive.
2. Bài đúng có thể bị từ chối (2/20 trong mẫu hiệu chỉnh). Không coi trạng thái này là chắc chắn không có tài liệu; nhờ nhân viên kiểm tra.
3. Đánh giá trên corpus nhỏ 6/100 bài có v2 approved. Khi mở rộng editorial phải thu thập positive/negative mới và hiệu chỉnh lại; fingerprint hiện tại chủ động fail-closed.
4. Cần bộ đánh giá sealed nhiều ca độc lập, phân lớp intent/answerability, phân tích FPR/false abstain theo tenant/ngôn ngữ, test đối kháng và đánh giá human before release.
5. Quick Tunnel + demo password + ngân sách GPU vẫn chỉ dành cho internal synthetic preview. Không tự động business writes, không M3 tickets, không Git push.

**Không thực hiện:** reset/reseed DB, tăng phạm vi approved KB, re-embed, redeploy GPU, thay pinned model.
