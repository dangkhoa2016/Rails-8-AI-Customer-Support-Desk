# M5.3 — Ticket reply clarity and tenant-scoped Knowledge Base priorities (2026-10-30)

## Scope
- UI/copy only (Rails ERB and separate EN/VI locale files), plus computed approval status from existing data.
- No ticket messages, M0 policy, human approval workflow, AI routing, Modal deployment, synthetic business data or tenant-isolation changes.
- Six priority articles exist **across two tenants**: TeamFlow Cloud has two, NovaMart Store has four. Each signed-in tenant sees only its own records.
- Sealed80 answerability remains BLOCKED.

## Changes
1. Ticket details, such as /tickets/117: heading "Internal notes and replies (demo)" with explicitly separate "Internal note — staff only" and "Public reply — saved in demo only" options. Copy explains that Rails and audit logs store the result but no email/SMS/notification is sent. Human confirmation for public messages is unchanged.
2. /knowledge_articles: tenant-specific heading and count. VI/EN status is computed from the **latest** KnowledgeArticleVersion, active_on? and organization policy version, rather than hard-coded.
3. "Compare VI / EN" keeps owner/admin editorial access; other-tenant content remains isolated. Removed stale "M2 · EDITORIAL REVIEW · Modal NOT_RUN" hero label.
4. Independent EN and VI translations.

## Evidence
- New tests: 4 cases, 56 assertions, zero failures/errors/skips.
- Full Rails suite: 118 tests, 4,963 assertions, zero failures/errors/skips.
- Private HTTPS smoke: PASS TeamFlow (2 articles with approved VI/EN), NovaMart (4, approved VI/EN), and ticket 117 internal/public copy.
- No GPU calls and no business writes in acceptance smoke.
- Evidence: /tmp/rails8_ui_clarity_m53_test.log, /tmp/rails8_ui_clarity_m53_full_regression.log, /tmp/rails8_m53_ui_clarity_https_evidence.json.
- Test paths: test/integration/editorial_priority_ticket_copy_test.rb and test/smoke_m53_ticket_kb_clarity_https.py.

## Boundaries
- A public reply is a public-visibility ticket record in the synthetic demo, not an externally delivered customer message.
- Editorial comparisons remain owner/admin only. The existing twelve priority language versions are all approved; a future pending latest version automatically shows Pending approval.
- No Git commit, history rewrite or push performed for this UI update.
