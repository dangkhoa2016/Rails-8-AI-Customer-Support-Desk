# M5.3 — Làm rõ Ticket Reply và Knowledge Base Priority (2026-10-30)

## Phạm vi
- Chỉ cập nhật giao diện/bản dịch (Rails ERB + locale VI/EN), và tính trạng thái bài KB từ dữ liệu hiện hữu.
- Không sửa ticket messages, policy M0, approval, AI routing, Modal, PostgreSQL dataset hoặc tenant isolation.
- Nhóm KB ưu tiên gốc có 6 bài **trên hai tenant**: TeamFlow Cloud 2, NovaMart Store 4. Mỗi tenant chỉ xem bài của chính tenant.
- Không tuyên bố AI answerability đạt: sealed80 vẫn BLOCKED.

## Những sửa đổi
1. Trang ticket, ví dụ /tickets/117: tiêu đề "Ghi chú và phản hồi (demo)", dropdown phân biệt "Ghi chú nội bộ — chỉ nhân viên xem" và "Phản hồi công khai — chỉ lưu trong demo"; mô tả chi tiết và xác nhận thủ công với public reply. Backend vẫn lưu Rails + audit, không gửi email/SMS/notification bên ngoài.
2. Trang /knowledge_articles: đổi tiêu đề theo tenant và số lượng hiện tại; dùng VI/EN trạng thái từ bản KnowledgeArticleVersion **mới nhất**, active_on?, policy_version hiện tại; không hard-code chữ "Đã duyệt".
3. Đổi nút "Xem đối chiếu VI / EN", giữ role owner/admin cho trang editor. Không lộ bài của tenant còn lại. Bỏ hero cũ "M2 · EDITORIAL REVIEW · Modal NOT_RUN" (đã lỗi thời).
4. Bản dịch VI/EN tách riêng.

## Bằng chứng
- Test mới: 4 cases, 56 assertions, 0 failures/errors/skips.
- Full Rails regression: 118 tests, 4.963 assertions, 0 failures/errors/skips.
- HTTPS private preview smoke: PASS TeamFlow (2, VI+EN approved), NovaMart (4, VI+EN approved), ticket 117 (internal/public copy).
- 0 GPU calls và 0 business writes trong smoke. Dữ liệu production/synthetic không thay đổi.
- Local evidence: /tmp/rails8_ui_clarity_m53_test.log, /tmp/rails8_ui_clarity_m53_full_regression.log, /tmp/rails8_m53_ui_clarity_https_evidence.json.
- Test: test/integration/editorial_priority_ticket_copy_test.rb, test/smoke_m53_ticket_kb_clarity_https.py.

## Giới hạn
- Public reply trong demo chỉ là record nội bộ có visibility public; chưa thực sự gửi cho khách.
- Priority editorial comparison vẫn dành cho owner/admin. VI/EN hiện đã approved trên 6 bài trong dataset, nhưng tương lai nếu có bản nháp mới, trạng thái hiển thị sẽ tự chuyển về Chờ duyệt.
- Không tạo/rewrite/push commit trong thay đổi này.
