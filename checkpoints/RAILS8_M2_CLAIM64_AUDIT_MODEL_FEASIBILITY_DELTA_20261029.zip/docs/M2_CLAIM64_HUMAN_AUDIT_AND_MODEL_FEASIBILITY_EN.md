# M2 — 64-Claim Audit and Decomposition + NLI Model Feasibility (EN)

**Reviewed:** October 29, 2026 (Asia/Ho_Chi_Minh)  
**Status:** `ASSISTANT_PROVISIONAL_AUDIT_COMPLETE / INDEPENDENT_HUMAN_REVIEW_PENDING / NEW_MODEL_NOT_DEPLOYED`  
**Scope:** Synthetic TeamFlow Cloud and NovaMart Store in Rails 8 AI Customer Support Desk. AI remains human-assist only: it must not autonomously reply to customers, approve/refund billing, replace products, alter subscriptions, or write business data.

## 1. The original binary labeling problem

The prior claim-level lockbox `review/m2_claim_level_manual32x2_lockbox_20261029.json` contained 32 composite questions, manually decomposed into 64 atomic claims. The initial 96-query Modal GPU evaluation returned atomic **TP 15 / FP 0 / FN 17 / TN 32**. This is pilot evidence, not a production claim-safety certification.

A read-only second-pass review of the exact **12 approved KB v2** (TeamFlow TF-KB-012/015 and NovaMart NM-KB-014/020/029/030, VI and EN versions) showed five questions marked unsupported by the developer whose **negative answers** are actually grounded by approved policy:

- `CL-TF-VI-03-2`: guaranteed upgrade fix within 15 minutes? TF-KB-012 forbids unauthorized completion-time promises.
- `CL-TF-EN-03-2`: guaranteed activation fix within 30 minutes? TF-KB-012 does not authorize a deadline guarantee.
- `CL-NM-VI-03-2`: guarantee arrival at 20:00 tomorrow? NM-KB-020 expressly treats its delivery window as an estimate.
- `CL-NM-EN-03-2`: guaranteed noon arrival tomorrow? NM-KB-020 provides no such guarantee.
- `CL-NM-EN-06-2`: may AI automatically approve and dispatch replacement? NM-KB-030 disallows AI replacement decisions.

None of these forbidden actions becomes allowed. The policy supports a **clear “No”**, which differs materially from **“the approved KB does not address this”**. The original gold labels and GPU evidence are preserved unchanged.

## 2. Provisional assistant audit — NOT independent human adjudication

| Provisional class | Count |
|---|---:|
| `policy_supported_affirmative` — affirmative/conditional policy answer | 28 |
| `policy_supported_explicit_negative` — explicit policy-backed “No” | 9 |
| `not_documented_in_approved_kb` — no identified approved policy | 27 |
| **Total** | **64** |

A *diagnostic-only*, post-hoc comparison yields **TP 15 / FP 0 / FN 22 / TN 27** (15/37 policy-answerable claims, ~40.5% recall). This is **not** an independently blinded retest; the assistant was potentially exposed to old model predictions and previous labels. Do not treat the updated figures as a clean benchmark or improve thresholds against these now-open cases.

Evidence:
- `review/m2_claim64_assistant_provisional_semantic_audit_20261029.json` SHA256 `3139de9f3c0488a58476e40ba26fb63e1ed851aede9ded99e3ccdc36786b22fd`.
- `evidence-m2-claim64-provisional-audit-20261029/assistant-provisional-claim-comparison.json` SHA256 `fd286ed0aa957a339a81de4629db4ec5a92fbccc2a1afd9aec26743c3b75e29c`.
- Exact approved corpus snapshot `approved-kb-v2-readonly-snapshot.json`, including tenant, locale, article version and body SHA256, SHA256 `12cb87609c5de1c082e692648e55615785b31f5faf84c280bfaaa1fd0a15695f`.
- DB before/after **100 articles / 212 versions / 12 approved / 84 embeddings**. Zero KB/editorial changes, business writes or inference evidence mutation.

## 3. Independent reviewer workbook — ready but not signed

File: `evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`, SHA256 `2cb975bab8f921a10907409af8893bb3f08d94823eb24a95bde3044b071c1531`.

This HTML file runs **offline only**, displays 64 questions plus 12 approved v2 KB documents, and lets an external reviewer select:
- `affirmative_policy`: policy supports affirmative/conditional guidance.
- `explicit_negative_policy`: the approved policy explicitly refutes or forbids an action.
- `not_documented`: no adequate approved source identified; do not assert that the company does not offer the capability.
- `uncertain_needs_second_reviewer`: a second reviewer is required.

Each review needs a citation to the correct approved article and a short policy excerpt, plus any case-data dependencies. The workbook **excludes all old developer gold, assistant labels and model predictions**. It can export the reviewer’s annotations as a JSON file in their own browser without uploads. The external human review is **NOT_RUN**, and there is no invented reviewer sign-off.

## 4. Candidate models: researched, not installed or deployed

### Candidate A — decomposition

**`Qwen/Qwen3-4B-Instruct-2507`** (https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507)

- Four-billion-parameter multilingual text instruction model; model card declares **Apache-2.0**. Non-thinking variant. Attractive as a constrained JSON generator of up to four atomic questions, with exact source character spans and an unresolved-intents field.
- BF16 model weights alone are approximately 8 GB, excluding KV cache and activations. A single **A10 (24 GB)** is a reasonable feasibility target, **not a verified runtime claim**. Limit pilot inputs to 4,096 tokens, output to 384 tokens, concurrency to one. Exact revision, VRAM, startup time and compatibility must be confirmed by a separate POC.
- Must preserve negations, qualifiers, all requested actions and ambiguity. Any source spans missing in generated output must fail closed for human review.

### Candidate B — multilingual NLI

**`MoritzLaurer/mDeBERTa-v3-base-mnli-xnli`** (https://huggingface.co/MoritzLaurer/mDeBERTa-v3-base-mnli-xnli)

- Card declares **MIT**, approximately **0.3B parameters**, and multilingual training on XNLI/MNLI, including Vietnamese and English.
- Input is an exact, authorization-checked approved-KB excerpt (premise) plus a **declarative hypothesis** derived from the customer’s atomized question. Output is entailment, neutral or contradiction — not a business decision.
- The model card notes potential FP16 issues in some DeBERTa versions. Prefer a separate measured FP32 pilot (~1.2 GB weights in theory) rather than silently asserting half-precision correctness. T4/L4 GPU fit and latency are estimates, **not run acceptance**.
- Never interpret model softmax as a calibrated probability that a policy answer is safe. A predicted contradiction cannot authorize a refund/replacement or an unsupervised negative reply; explicit textual support and human approval are still required.

### Candidate C — comparison NLI model

**`joeddav/xlm-roberta-large-xnli`** (https://huggingface.co/joeddav/xlm-roberta-large-xnli)

MIT-licensed, trained on multilingual XNLI including Vietnamese and English. Suitable as a cross-check against mDeBERTa. Agreement between two imperfect NLI models does not establish logical certainty.

Gemma 3 4B is another possible multilingual generator but requires separate license/access review; it is not the preferred first POC given Qwen3 Apache-2.0 availability.

## 5. Current Modal pricing and scenarios — NOT actual charges

As of 2026-10-29, Modal pricing (https://modal.com/pricing) lists GPU rates of **A10 $0.000306/s**, **T4 $0.000164/s**, and **L4 $0.000222/s**.

Illustrative GPU-only budget with *one A10 for decomposition plus one T4 for NLI*, each running for:
- **10 minutes:** ~$0.282
- **20 minutes:** ~$0.564
- **30 minutes:** ~$0.846

These arithmetic scenarios are not per-claim unit prices, nor actual billed usage. Startup/container-keepalive, CPU, memory, storage, egress, retries, potential region multipliers and other chargeable resource time are additional. HTTP response time differs from billable GPU running time.

## 6. Offline model contracts and test results

Source code:
- `script/m2_future_model_contracts.py`: strict JSON-level validator and source-span requirements for future decomposition, plus source-authentic approved-KB NLI envelope with pinning and three-way finite scores.
- `test/test_m2_future_model_contracts.py`: **10 offline Python unittest PASS**.

`rails8.m2.claim_decomposition.v1` requires tenant/locale/question SHA256, 1–4 claims, exact source_start/end/excerpt, declarative hypothesis, intent type, needs_case_data and unresolved spans. The validator rejects any source content not accounted for by a claim or unresolved span, forged quotes, PII-like inputs or cross-tenant data.

`rails8.m2.nli_candidate.v1` binds tenant, locale, article_key, version_id, approved body SHA256, exact premise substring, hypothesis, pinned model ID and 40-char revision, three finite NLI scores and a consistent predicted label. Invalid score sums, fabricated premises or mismatched versions are rejected.

**These checks prove only schema/source integrity**, not semantic fidelity of paraphrased hypotheses or entailment accuracy. All tests use mock fixtures; **new-model inference = NOT_RUN**.

## 7. Evidence-backed continuation gates

1. An actual independent reviewer must complete and sign the gold-free workbook against approved KB v2, including second-review arbitration for uncertain items. Do not insert fake human sign-off.
2. Prepare NEW calibration examples and a **new sealed, previously unused holdout**; the previous 64- and 80-case suites have been opened. Include tenant/locale balance, supported affirmatives, explicit negatives, unknown/no-policy, mixed intents, PII, prompt-injection and missing case-specific records.
3. If authorized, deploy candidate models to **isolated new Modal apps** with pinned exact revisions, private tokens, concurrency cap one, hard budget, monitoring and rollback; leave existing embedding/reranker endpoints intact. Do not insert new inference into Rails or the public preview.
4. Measure strict JSON parse/coverage rates, dropped intents and invented claims, 3-way NLI per-label FP/FN, cross-tenant safety, P50/P95 warm and cold latency, VRAM, actual billed compute and end-to-end user-facing cost. Verify model config id2label instead of assuming label order.
5. Proposed clean sealed acceptance: **zero unsafe accepted claims on hard negatives**, recall at least 80% in **each** VI/EN cohort, 100% tenant integrity and no business writes. Even zero FPs on a small set does not establish production safety.
6. Any user-visible staff pilot requires human approval and a new review gate. The previously failed M2 scope verifier remains **BLOCK_PREVIEW_FLAG** and preview remains relevance-only.

## 8. Current status

- Approved KB v2 audit and 64 assistant provisional classifications complete, with five labeling conflicts identified.
- Gold-free offline reviewer workbook ready; **independent human evaluation PENDING**.
- Candidate model/licensing/compute feasibility researched; strict offline contracts **10/10 PASS**.
- New inference models, GPU deployments, external independent annotation, integration and new holdout **NOT_RUN**.
- Rails baseline, PostgreSQL data, existing Modal model deployments, Cloudflare relevance-only preview and earlier M0/M1/M2 acceptances preserved.
- No Git commits/push or business writes.

**Next execution point:** obtain an actual independent reviewer export, then begin a *separate*, capped GPU POC for the decomposition/NLI candidates using newly locked acceptance criteria.
