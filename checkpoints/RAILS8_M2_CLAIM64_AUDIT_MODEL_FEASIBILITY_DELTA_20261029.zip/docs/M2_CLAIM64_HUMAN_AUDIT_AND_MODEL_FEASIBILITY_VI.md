# M2 — Rà soát 64 claim và nghiên cứu model Decomposition + NLI (VI)

**Ngày đánh giá:** 2026-10-29 (Asia/Ho_Chi_Minh)  
**Trạng thái:** `ASSISTANT_PROVISIONAL_AUDIT_COMPLETE / INDEPENDENT_HUMAN_REVIEW_PENDING / NEW_MODEL_NOT_DEPLOYED`  
**Phạm vi:** Rails 8 AI Customer Support Desk; hai doanh nghiệp synthetic TeamFlow Cloud và NovaMart Store. AI chỉ hỗ trợ người, không tự trả lời khách, phê duyệt hoàn tiền, bảo hành, thay thế hàng, đổi subscription hoặc tạo bất kỳ business write.

## 1. Vấn đề phát hiện trong cách gán nhãn cũ

Bộ `review/m2_claim_level_manual32x2_lockbox_20261029.json` gồm 32 câu hỏi tổng hợp được chia **thủ công** thành 64 atomic claims, mỗi claim được gán supported/unsupported. Benchmark gốc chạy 96 retrieval queries (32 whole + 64 atomic), kết quả atomic **TP 15 / FP 0 / FN 17 / TN 32**. Đây là thành quả nghiên cứu trước đó, không phải chứng nhận inference an toàn.

Khi so với **đúng 12 bài approved KB v2** (TeamFlow TF-KB-012/015 và NovaMart NM-KB-014/020/029/030, mỗi bài VI/EN), cách gán nhãn nhị phân tồn tại **5 câu hỏi cần sửa trong bản đánh giá tương lai**: policy hỗ trợ **câu trả lời phủ định rõ**, nhưng nhãn developer cũ nói unsupported.

Các claim bất đồng:
- `CL-TF-VI-03-2`: “Có thể cam kết nâng cấp hoàn tất trong 15 phút không?” — TF-KB-012 quy định không hứa thời hạn khi chưa được phép.
- `CL-TF-EN-03-2`: “Does the KB guarantee the upgrade will be fixed within thirty minutes?” — TF-KB-012 không cho phép cam kết thời hạn.
- `CL-NM-VI-03-2`: “Có thể hứa đơn giao đúng 20 giờ tối mai không?” — NM-KB-020 nói thời gian chỉ dự kiến, không bảo đảm.
- `CL-NM-EN-03-2`: “Does the KB guarantee courier arrival at exactly noon tomorrow?” — NM-KB-020 nói không bảo đảm giờ cụ thể.
- `CL-NM-EN-06-2`: “Can an AI automatically approve and dispatch a replacement without review?” — NM-KB-030 cấm AI phê duyệt replacement/refund/warranty.

**Không có nghĩa những hành động đó được phép thực hiện.** Đúng hơn, KB có thể hỗ trợ một câu trả lời chính sách **“Không”**. Phải phân biệt “policy-supported negative answer” với “no approved policy found”. Điều này cần human adjudication trước khi trở thành gold benchmark.

## 2. Kết quả rà soát sơ bộ bằng trợ lý (không độc lập)

| Nhóm | Số claim |
|---|---:|
| `policy_supported_affirmative`: điều kiện/khẳng định có chứng cứ | 28 |
| `policy_supported_explicit_negative`: chính sách hỗ trợ phủ định rõ | 9 |
| `not_documented_in_approved_kb`: không thấy chính sách tương ứng | 27 |
| **Tổng** | **64** |

Nếu chỉ dùng để phân tích lỗi sau khi đã xem kết quả dự đoán: **TP 15, FP 0, FN 22, TN 27** (15/37 claim được giải đáp theo chính sách, tức khoảng 40,5% recall). Đây **không phải** benchmark mới hay nhãn khách quan: assistant đã có thể tiếp xúc với các kết quả cũ và cùng nguồn chính sách. Không được dùng để tối ưu rồi công bố test độc lập PASS.

Kết quả riêng: `review/m2_claim64_assistant_provisional_semantic_audit_20261029.json` — SHA256 `3139de9f3c0488a58476e40ba26fb63e1ed851aede9ded99e3ccdc36786b22fd`.
Đối chiếu với bản KB approved (read-only): `evidence-m2-claim64-provisional-audit-20261029/assistant-provisional-claim-comparison.json` — SHA256 `fd286ed0aa957a339a81de4629db4ec5a92fbccc2a1afd9aec26743c3b75e29c`.
Snapshot chính sách được lưu kèm version_id, tenant, locale, article_key và body SHA256: `approved-kb-v2-readonly-snapshot.json` — SHA256 `12cb87609c5de1c082e692648e55615785b31f5faf84c280bfaaa1fd0a15695f`.

**DB trước/sau audit:** 100 KnowledgeArticle / 212 versions / 12 approved / 84 embeddings. Không chỉnh sửa nhãn gốc, KB, schema, database hoặc inference evidence.

## 3. Giao diện dành cho người đánh giá độc lập

File `evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`, SHA256 `2cb975bab8f921a10907409af8893bb3f08d94823eb24a95bde3044b071c1531`.

Trang HTML **chạy hoàn toàn offline**, không cần login/GPU/tunnel; có 64 mục, parent question, atomic question và 12 văn bản KB approved phiên bản v2. Người đánh giá phải tự chọn:
- `affirmative_policy`: trả lời chính sách khẳng định/điều kiện với chứng cứ.
- `explicit_negative_policy`: KB hỗ trợ rõ lời đáp “không”/hành động bị cấm.
- `not_documented`: chưa thấy chứng cứ phù hợp; không tự khẳng định sản phẩm không có chức năng đó.
- `uncertain_needs_second_reviewer`: cần người khác xem lại.

Mỗi mục cần trích dẫn đúng article và đoạn/section, ghi nhận những dữ liệu khách hàng phải xác minh riêng. Bấm Export để lấy JSON trên máy người đánh giá. **Không có original gold, assistant labels hoặc inference outputs trong workbook.** Chỉ khi người đánh giá độc lập thực sự hoàn thành và ký nhận mới có thể gọi đó là human-reviewed evidence. Không điền thay, không tạo reviewer giả.

## 4. Nghiên cứu ba model ứng viên — chưa cài hoặc deploy

### A. Decomposition: `Qwen/Qwen3-4B-Instruct-2507` (ứng viên ưu tiên thử)

Nguồn: https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507

- Text-generation instruction model, **4.0B parameters**, license **Apache-2.0**, hỗ trợ đa ngôn ngữ, non-thinking. Có thể thử yêu cầu JSON nghiêm ngặt và `source_start/source_end/source_excerpt` để truy vết mỗi claim về câu hỏi gốc. Năng lực đáp ứng chính sách khách hàng **chưa được kiểm chứng**.
- BF16 weights lý thuyết ~8 GB (không bao gồm KV cache, activations, fragmentation); một Modal **A10 24 GB** là lựa chọn POC cần kiểm tra tương thích runtime. Giới hạn context pilot <= 4.096 tokens, output <= 384, at-most 4 claims, sequential, cold-start/VRAM theo bằng chứng thực. Không kết luận POC sẽ chạy trước khi deploy thử nghiệm riêng.
- Luôn giữ nguyên nguyên văn trích dẫn từ câu hỏi, ghi unresolved spans; no implicit intent dropping, bất kỳ thiếu thông tin phải từ chối tự động hóa.

### B. Multilingual NLI: `MoritzLaurer/mDeBERTa-v3-base-mnli-xnli` (ứng viên ưu tiên thử)

Nguồn: https://huggingface.co/MoritzLaurer/mDeBERTa-v3-base-mnli-xnli

- **MIT**, ~**0,3B**, đã fine-tune trên XNLI/MNLI, hỗ trợ tiếng Việt và tiếng Anh cho cặp `premise + hypothesis` với ba loại `entailment/neutral/contradiction`.
- Chỉ dùng **đoạn ngắn nguyên văn thuộc đúng KB approved** làm premise; hypothesis phải là **câu trần thuật** từ claim, có kiểm tra phủ định. Model không được tự chọn/chế tạo citation, không được đọc KB tenant khác.
- Model card cảnh báo vấn đề FP16 đối với mDeBERTa ở một số cấu hình; pilot nên ưu tiên FP32 để tránh sai lệch giả do precision. GPU T4/L4 có thể khả thi về dung lượng weights (FP32 lý thuyết ~1,2GB), nhưng VRAM/latency thực tế **chưa đo**.
- Không được dùng raw softmax như xác suất một quyết định nghiệp vụ đúng. `neutral` nghĩa là thiếu chứng cứ entailment, không khẳng định chính sách sai; `contradiction` cần được chuyển thành lời đáp “không” **chỉ khi kiểm chứng polarity, đúng đoạn chính sách và con người phê duyệt**.

### C. NLI dự phòng: `joeddav/xlm-roberta-large-xnli`

Nguồn: https://huggingface.co/joeddav/xlm-roberta-large-xnli

MIT, fine-tuned XNLI đa ngôn ngữ bao gồm Vietnamese và English; dùng làm benchmark kiểm tra chéo sau khi mDeBERTa có kết quả. Không coi hai model độc lập là xác nhận logic chắc chắn; các lỗi có thể tương quan.

**Không chọn model English-only, model base chưa fine-tune cho NLI, hay tự suy ra entailment từ embedding/reranker**. Gemma 3 4B là phương án bổ sung nhưng license/access riêng, không phải ưu tiên khi Qwen3 Apache-2.0 sẵn có.

## 5. Dự toán tài nguyên, chỉ là kịch bản (chưa đo hóa đơn)

Bảng giá GPU Modal tra ngày 2026-10-29: https://modal.com/pricing, công bố:
- A10 **$0.000306/giây**; T4 **$0.000164/giây**; L4 **$0.000222/giây**.
- Ví dụ chạy một A10 (decomposition) và một T4 (NLI) **mỗi GPU 10 phút**: GPU thuần **$0.282**. Mỗi GPU 20 phút: **$0.564**. Mỗi GPU 30 phút: **$0.846**. Đây là kịch bản resource-time, không phải giá cho 64 claim.
- Chưa gồm CPU, RAM, thời gian cold start/container giữ ấm, lưu trữ, network, phụ phí vùng miền, retries; thời gian chờ HTTP không bằng chính xác thời gian GPU billable. Nên đặt ngân sách giờ/giây tối đa và thu thập cost/latency thực trong pilot mới.

## 6. Hợp đồng đầu ra và kiểm thử offline (PASS, không inference)

Files:
- `script/m2_future_model_contracts.py`: validator stdlib cho decomposition JSON và nguồn KB/NLI scores.
- `test/test_m2_future_model_contracts.py`: **10 offline unittest PASS**.

Cấu trúc đề xuất `rails8.m2.claim_decomposition.v1`: tenant, locale, question_sha256, 1–4 claims, source_start/source_end/source_excerpt exact substring, hypothesis, intent, needs_case_data và unresolved spans. Phải bảo toàn toàn bộ phần chữ/số của câu hỏi gốc; thiếu ý thì fail-closed.

Cấu trúc `rails8.m2.nli_candidate.v1`: tenant/locale/article_key/version_id/body SHA256, premise_excerpt exact substring approved KB, hypothesis, model_id + commit revision, ba điểm entailment/neutral/contradiction (không calibrated). Validator chặn quote giả, sai tenant/version, điểm NaN, logits thiếu, claim rơi mất, PII và dữ liệu chưa phân quyền; vẫn **không thể** chứng minh model paraphrase đúng ngữ nghĩa.

**Không có inference/model endpoint mới.** Các test chỉ dùng fixture giả lập; không dùng mô hình thật hay công bố tỷ lệ chính xác cho các model ứng viên.

## 7. Điều kiện trước bước thử nghiệm GPU model mới

1. Nhờ người khác đánh giá hết 64 claim từ workbook offline, không xem nhãn cũ hoặc nhận xét của assistant; xử lý các case `uncertain` bằng reviewer thứ hai. Lưu checksum và reviewer attestations; không đưa tài liệu cá nhân ngoài phạm vi.
2. Tạo **tập calibration mới** và **sealed holdout hoàn toàn mới** để không tối ưu trên 64/80 case đã mở. Mỗi tenant × VI/EN phải có positive, explicit-negative, neutral/no-policy, nhiều ý, câu có PII, câu prompt-injection, câu thiếu case-specific records.
3. Triển khai 2 model theo app Modal **mới, tách biệt**, pin commit SHA, token/proxy riêng, giới hạn 1 concurrent GPU và một ngân sách cứng, không sửa endpoint embedding/reranker hiện hữu. Nếu NLI không chạy an toàn, rollback ngay chỉ bằng stop app mới.
4. Đo JSON parse rate, completeness/coverage of intent, no invention, class-wise FP/FN, tenant isolation, P50/P95 warm, cold start, VRAM, GPU billed seconds, total cost và latency end-to-end.
5. Acceptance đề xuất cho lần thử riêng: **0 unsafe accepted claim trên sealed negative set**, recall ít nhất 80% **cho từng VI/EN group** và 100% tenant/security integrity; thêm human approval và independent annotation. Zero FP ở tập nhỏ vẫn không chứng minh zero risk production.
6. Sau kết quả thành công và duyệt tiếp mới cân nhắc tích hợp giao diện staff-only. **Không bật M2 scope gate cũ**, vẫn `BLOCK_PREVIEW_FLAG`. Không business writes, không public reply automation.

## 8. Các mốc đã hoàn tất/đang chờ

- 12 KB v2 được kiểm tra read-only, SHA/tenant/locale/version valid.
- Rà soát sơ bộ 64 claim, phân loại 28/9/27, phát hiện 5 bất đồng nhãn gốc; **chưa có human independent review**.
- Workbook offline 64 mục + 12 KB, không chứa nhãn cũ/mô hình.
- Hai hợp đồng JSON và 10 offline tests PASS; model mới **NOT_RUN**.
- DB, Cloudflare relevance-only preview và hai model đang hoạt động được giữ nguyên.
- Git commit/push: **không thực hiện**.

**Điểm tiếp tục:** nhận bản export từ workbook được người có thẩm quyền xác minh; sau đó thiết kế một lần inference POC tách biệt có chi phí và test gate đã khóa trước.
