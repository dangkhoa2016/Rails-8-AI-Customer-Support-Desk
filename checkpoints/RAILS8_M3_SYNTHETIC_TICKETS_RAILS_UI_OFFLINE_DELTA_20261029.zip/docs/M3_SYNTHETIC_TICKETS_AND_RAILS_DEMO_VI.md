# M3 — Synthetic support tickets và Rails demo (29/10/2026)

## Phạm vi và cấp độ nghiệm thu

Bộ M3 hiện là **dữ liệu giả lập đã tạo + kiểm tra offline**, chưa import vào PostgreSQL trên Colab sau reboot; không phải semantic gold và không chứng nhận production. M0 20 policy v1.0.0, M2 12 KB approved v2 và quyết định chủ dự án chấp nhận 64/64 claim để **demo synthetic** vẫn giữ nguyên. Không cần hai reviewer độc lập để dùng dữ liệu mẫu. Sealed80 **BLOCKED** (FP=3, supported recall=0.70); không bật `M2_ANSWERABILITY_SCOPE_ENABLE`, không auto-reply hoặc AI business writes.

## Dữ liệu và provenance

- M1 source: `data/m1_business_records.json`, SHA256 `6a266e42c0099c18d8560ed88e835f8873b62c35811dac28e350667ce3d68680`.
- M3 generator: `script/build_m3_synthetic_tickets.py`; seed cố định `20261029`.
- Dataset: `data/m3_synthetic_tickets.json`, SHA256 `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd`.
- Manifest: `data/m3_synthetic_tickets.manifest.json`, gồm SHA, source pin, trạng thái `db_import_execution=NOT_RUN`.
- 240 tickets, 440 messages, 216 tham chiếu nghiệp vụ phân biệt, 120 tickets/tenant; VI/EN 60/60 từng tenant. **Mỗi danh mục và mỗi trạng thái cân bằng VI/EN**.
- TeamFlow: billing/activation, workspace, export, API, incident, subscription. NovaMart: order, payment, shipment/partial, return, warranty, damage.
- Tất cả customer và order/workspace/invoice/reference liên kết với đúng tenant. Trường `source_facts` đối chiếu dữ liệu M1, không phải câu trả lời chính sách; không tạo semantic gold hoặc reviewer giả.
- Ticket dùng trạng thái DB hiện có: `new`, `open`, `pending_customer`, `pending_internal`, `resolved`, `closed`. `pending_internal` là trạng thái chờ xử lý nội bộ (có thể đại diện escalation trong demo), không tạo trạng thái DB mới.
- Tin nhắn seed: customer public intake + ghi chú triage nội bộ do script mẫu tạo (trừ ticket `new`). Không có email outbound; không có public agent reply tự động hoặc hành động AI. Lịch sử là **dữ liệu giả lập**, không phải người thật đã phê duyệt.

## Những phần đã chạy thật

```bash
python3 script/build_m3_synthetic_tickets.py
python3 script/validate_m3_synthetic_tickets.py
python3 test/test_m3_synthetic_tickets.py
```

Kết quả: `PASS_OFFLINE_M3_INTEGRITY_ONLY`; **10/10 unit tests PASS**. Kiểm lỗi tenant/cross-customer, locale/category/status, chronology, nguồn M1, checksum, giả mạo human gold và visibility. Các bản nháp lệch phân bổ được lưu tại `evidence-m3-synthetic-tickets-20261029/draft-rejected/`.

**Rails test/DB import: NOT_RUN** trong phiên này vì Colab không có Ruby/Bundler, `.env.notebook`, PostgreSQL CLI/DB runtime. Kết quả đã PASS M1/M2 trước reboot không bị đổi.

## Rails UI đã cập nhật (mã nguồn; runtime chưa nghiệm thu)

- Ticket index: tìm theo mã ticket, mã customer, mã business reference và lọc theo status, locale, category; query luôn nằm trong tenant hiện hành.
- Ticket detail: hiển thị customer locale, reference, liên kết lookup read-only cho invoice TeamFlow hoặc order NovaMart, và lối sang AI KB Search cho agent có quyền.
- VI/EN locale strings, disclaimer synthetic, relevance-only và yêu cầu human approval. Không prefill hay tự gửi nội dung ticket sang Modal.
- Rails integration tests mới: `test/integration/m3_ticket_demo_ui_test.rb`, **NOT_RUN**.

## Quy trình khôi phục/import sau khi database được xác nhận

1. Xác minh đúng device Colab, kiểm Git diff, checksum và Modal evidence backup. Kiểm tra riêng Ruby/Bundler, PostgreSQL, `.env.notebook` tồn tại; không in mật khẩu/tokens.
2. **Chỉ sau khi** có backup DB an toàn và các M1/M2 read-only invariants đúng, chạy validator offline. Không chạy `db:reset`, `db:seed`, `run_full_m1.sh` hoặc `run_full_m2.sh` trên DB hiện hữu.
3. Nếu DB thật sự chứa M1 đã kiểm chứng, ở **development** và PostgreSQL, có thể chạy độc lập:

```bash
source script/use_notebook_env.sh
python3 script/validate_m3_synthetic_tickets.py
M3_SYNTHETIC_DEMO=YES bin/rails runner db/seeds/m3_synthetic_tickets.rb
bin/rails test test/integration/m3_ticket_demo_ui_test.rb
```

Importer `db/seeds/m3_synthetic_tickets.rb` từ chối production, thiếu opt-in, sai SHA, thiếu M1 refs, sai customer/tenant/fact, dữ liệu seed bị người khác sửa; dùng transaction, idempotent theo ticket number + message key, audit event `synthetic.ticket_seeded`. **Chưa chạy lệnh import**, không được ghi rằng 240 ticket đang hiện trong Rails DB.

4. Mở Rails trên loopback qua private, authenticated proxy phù hợp; không đưa đăng nhập demo passwordless trực tiếp lên public Quick Tunnel. Nếu Modal tokens chưa khôi phục, AI Search giữ trạng thái disabled.
5. Test phân quyền owner/admin/agent/viewer, tenant, 4 strata VI/EN, read-only lookups, reply approval và audit. Chỉ sau đó mới nâng trạng thái thành `PASS_POSTGRESQL`/`PASS_RAILS_UI`.

## Chưa làm

- Restore Rails/PostgreSQL interactive runtime sau reboot và DB import M3.
- Bộ 120 evaluation cases và đánh giá semantic độc lập (không chặn demo mẫu).
- Production auth, async, rate limit, monitoring, privacy/PII workflow, backup/restore và cost controls.
- Không commit/push Git nếu chưa được yêu cầu.

Tài liệu EN tương ứng: `docs/M3_SYNTHETIC_TICKETS_AND_RAILS_DEMO_EN.md`.
