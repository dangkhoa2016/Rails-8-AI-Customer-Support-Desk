# M3 — Synthetic Support Tickets and Rails Demo (2026-10-29)

## Scope and acceptance level

M3 is an **offline-built and validated synthetic dataset**, not yet imported into PostgreSQL after the Colab reboot. It is neither semantic gold nor production-certified. Keep the owner-approved M0 policy baseline (20 policies v1.0.0), M2 approved KB v2 (12 versions), and **64/64 owner-accepted sample claims for synthetic demo**. Independent dual review is not required to present samples. The sealed80 answerability gate remains **BLOCKED** (3 false positives; supported recall 0.70). No scope override, automated customer answers, or AI business writes.

## Data and provenance

- M1 canonical data: `data/m1_business_records.json`, SHA256 `6a266e42c0099c18d8560ed88e835f8873b62c35811dac28e350667ce3d68680`.
- Generator: `script/build_m3_synthetic_tickets.py`, deterministic seed `20261029`.
- Dataset: `data/m3_synthetic_tickets.json`, SHA256 `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd`.
- Manifest: `data/m3_synthetic_tickets.manifest.json`, including hashes, pinned source, and `db_import_execution=NOT_RUN`.
- 240 tickets, 440 messages, 216 distinct business references, 120 tickets per tenant, with 60 VI and 60 EN cases per tenant. Every category and lifecycle status is bilingual-balanced.
- TeamFlow scenarios cover billing/activation, workspace, export, API, incident, and subscription. NovaMart scenarios cover orders, payments, partial shipments, returns, warranties, and damages.
- Customer and business references are verified against M1 tenant relationships. `source_facts` are record snapshots, **not asserted policy answers** or independently signed human labels.
- Existing DB status enumeration is reused: `new`, `open`, `pending_customer`, `pending_internal`, `resolved`, `closed`. `pending_internal` can model internal escalation without a schema change.
- Seeded messages consist of customer intake and synthetic internal triage notes (except new tickets). The latter are scripted sample content, **not actual human-reviewed approvals**. No public agent reply, outbound email, or automated business write is seeded.

## Verified execution

```bash
python3 script/build_m3_synthetic_tickets.py
python3 script/validate_m3_synthetic_tickets.py
python3 test/test_m3_synthetic_tickets.py
```

Result: `PASS_OFFLINE_M3_INTEGRITY_ONLY`; **10/10 Python regression tests PASS**. Checks cover source SHA, customer/tenant/reference integrity, locale/category/status balancing, chronology, fake human labels, message visibility, and unsafe actions. Rejected imbalanced drafts are retained under `evidence-m3-synthetic-tickets-20261029/draft-rejected/`.

**Rails tests and DB import remain NOT_RUN** because Ruby/Bundler, PostgreSQL CLI/runtime, and `.env.notebook` were missing on the rebooted Colab. Earlier M1/M2 runtime results are historical and remain unchanged.

## Rails code improvements (not live-accepted)

- Tenant-scoped ticket search by ticket number, customer key, and business reference; status, locale, and category filters.
- Ticket detail case context with read-only TeamFlow invoice or NovaMart order links; staff-only manual AI KB Search link.
- VI/EN UI copy explicitly says synthetic and relevance-only; ticket bodies are never automatically sent to Modal.
- New integration suite: `test/integration/m3_ticket_demo_ui_test.rb`, **NOT_RUN**.

## Recovery/import procedure after database verification

1. Verify the correct Colab device, Git diff, checksums, and Modal evidence. Check presence of Ruby/Bundler, PostgreSQL, and notebook environment config without logging credentials.
2. Confirm a safe DB backup and read-only M1/M2 invariants **before changing the DB**. Never run `db:reset`, `db:seed`, or M1/M2 bulk importers against an unknown existing database.
3. Only against a verified **development PostgreSQL synthetic DB**:

```bash
source script/use_notebook_env.sh
python3 script/validate_m3_synthetic_tickets.py
M3_SYNTHETIC_DEMO=YES bin/rails runner db/seeds/m3_synthetic_tickets.rb
bin/rails test test/integration/m3_ticket_demo_ui_test.rb
```

The separate M3 importer fails closed without opt-in or correct SHA, tenant, customer, source facts, and M1 dataset. It uses a transaction and idempotent ticket-number/message-key matching and creates `synthetic.ticket_seeded` audit records. **It has not been run yet**.

4. Use a private, authenticated proxy for interactive Rails; never expose the passwordless development account selector directly through a public tunnel. Keep AI search disabled until private Modal credentials and existing gates have been safely restored.
5. Verify tenant/RBAC boundaries, all VI/EN strata, approved KB restriction, read-only source links, staff approvals, audit logging, and HTTP/CSRF behavior before claiming Rails/PostgreSQL acceptance.

## Remaining work

Restore the Rails/PostgreSQL runtime, perform the guarded M3 import and live acceptance, design 120 independent evaluation cases (optional for synthetic demo), then address production auth/privacy, queues, monitoring, rate limits, backup, and cost controls. No Git commit or push without an explicit request.

Corresponding Vietnamese documentation: `docs/M3_SYNTHETIC_TICKETS_AND_RAILS_DEMO_VI.md`.
