# Rails 8 AI Customer Support Desk

**Checkpoint hiện tại (2026-10-29): Rails 8 và PostgreSQL đã được kiểm chứng runtime trên database synthetic Colab development/test. Không làm lại M0/M1. M2 đã có 12 phiên bản v2 song ngữ được duyệt qua ủy quyền, 84 chunks đủ điều kiện, và nguồn tích hợp Qwen3-Embedding-4B + Qwen3-Reranker-4B. Hai model 4B đã chạy thật trên Modal GPU A10G, 84 embeddings thật đã lưu pgvector và 12 câu hỏi VI/EN đã được chấm điểm reranker.**

## Phạm vi đã có

- Một ứng dụng Rails 8, PostgreSQL, views server-rendered ERB, giao diện VI/EN, không cần frontend build tool.
- Hai tenant tổng hợp: `TeamFlow Cloud` (`b2b_saas`) và `NovaMart Store` (`ecommerce`).
- Đăng nhập nhanh qua tài khoản tổng hợp **chỉ trong development/test**, không có authentication production. Session lưu user + tenant từ membership được xác minh; không tin tenant ID từ params hoặc AI.
- Dashboard riêng từng tenant; danh sách khách hàng; tra cứu invoice TeamFlow và order/partial shipment NovaMart bằng service chỉ đọc kiểm tra tenant và customer.
- Tạo ticket thủ công, xem hội thoại, internal notes, public reply chỉ sau khi agent xác nhận; audit events, idempotency key và state transitions.
- 7 migrations (M1/M2 gốc cùng 2 migrations embeddings), 22 business/core models nguồn + AuditEvent/ApplicationRecord, deterministic dataset với 100 khách, 80 hóa đơn, 120 đơn hàng và các records liên quan; Rails seed/importer và 2 fixtures.
- Ruby policy tests, Python validation, integration test Rails, script thu thập logs và checksum.

**Cập nhật M3 (2026-10-29):** Đã tạo và kiểm tra **offline** 240 synthetic tickets, 440 messages, 216 business references; 60 VI + 60 EN cho từng tenant, **10/10 Python tests PASS**. Đã thêm Rails importer development-only và bộ lọc UI có tenant scope vào mã nguồn; **chưa import PostgreSQL và chưa chạy Rails M3 UI tests sau Colab reboot**. Xem `docs/M3_SYNTHETIC_TICKETS_AND_RAILS_DEMO_VI.md`. **Chưa hoàn tất:** editorial 100 bài KB, đánh giá semantic độc lập, bộ 120 evaluation cases, production authentication/proxy authorization, email outbound và dữ liệu khách thật. Pilot 12 câu hỏi VI/EN đo thật đạt Top1=12/12 và MRR@5=1,0 (tập nhỏ); lexical baseline đơn giản đạt Recall@8 = 0/12.

## Bắt đầu trên môi trường đã có Ruby 3.3+ / PostgreSQL

```bash
cd Rails-8-AI-Customer-Support-Desk
bundle install
# Tạo PostgreSQL role/database demo, rồi xuất PGHOST/PGUSER/PGPASSWORD/PGDATABASE
export RAILS_ENV=development M1_SYNTHETIC_DEMO=YES
bin/rails db:create db:migrate
bin/rails runner db/seeds/m1_full_business_records.rb
bin/rails runner script/verify_m1_database.rb
bin/rails server -b 127.0.0.1 -p 3000
```

Mở `http://127.0.0.1:3000/demo/sign_in`. Chọn `tf-agent@example.test` hoặc `nm-agent@example.test` qua giao diện; đổi tài khoản để kiểm tra tenant. Không sử dụng màn hình login demo cho production hoặc dữ liệu thật.

## Chạy full acceptance trên Kaggle/Colab (sau khi upload/giải nén)

Bật notebook internet để cài Ruby/gems/PostgreSQL. Chạy trong thư mục project bằng quyền root mặc định của notebook:

```bash
bash script/notebook_setup.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bin/rails server -b 127.0.0.1 -p 3000
```

`script/notebook_setup.sh` chỉ intended cho máy notebook disposable; tạo PostgreSQL user/password cục bộ vào `.env.notebook` (gitignored). Mọi command trong `run_full_m1.sh` có stdout/stderr, exit code, UTC timestamps tại `evidence-run/`. Phần chưa chạy vẫn `NOT_RUN`, không bịa kết quả. **Không được mở Quick Tunnel ra Internet khi sử dụng đăng nhập demo không cần mật khẩu**; chỉ localhost và môi trường thử nghiệm có kiểm soát. Khi thêm authentication/RBAC production mới đánh giá public exposure.

## Docker Compose (phương án local có Docker)

```bash
docker compose up --build
# localhost:3000; chỉ bind host loopback
```

Database trong compose dùng mật khẩu demo cố định **chỉ để kiểm thử local**; không dùng trên Internet hoặc production. Mỗi khởi động có importer idempotent. Docker compose và container cũng **chưa được chạy/kiểm chứng** ở workspace hiện tại.

## Bằng chứng, chính sách và nguyên tắc an toàn

- Canonical policy `docs/RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json`, M0 approved, policy version `1.0.0`.
- Dataset `data/m1_business_records.json`, seed `20261028`, reference time `2026-10-28T00:00:00+07:00`.
- Giữ SHA256, không thay dữ liệu gốc để chạy theo ảnh/ticket riêng, không dùng AI làm gold.
- Customer và business lookups luôn được tenant-scope; no cross-tenant relationship theo composite DB FK.
- AI chưa tích hợp, không được gán các thay đổi nghiệp vụ cho AI; public reply do người xác nhận. Dù lưu public message, **không có outbound email**.
- Các tài liệu song ngữ và nguồn gốc M0 nằm trong `docs/`.

**Không coi `PASS_SOURCE_ONLY` hoặc `PASS_OFFLINE_ONLY` là `PASS_POSTGRESQL` hay `PASS_AI`.**

- Modal proxy auth và tìm kiếm Rails nội bộ: `docs/M2_MODAL_PROXY_AND_RAILS_SEARCH_VI.md`

- **AI Search Rails đã chạy thật qua preview riêng trong Colab**: `docs/M2_RAILS_AI_SEARCH_LIVE_UI_VI.md`

- **Cập nhật truy cập Colab iframe:** `docs/M2_COLAB_IFRAME_ACCESS_FIX_VI.md`

- **Cloudflare Quick Tunnel: preview có mật khẩu và quyền chỉ đọc:** `docs/M2_CLOUDFLARE_PRIVATE_PREVIEW_VI.md`

## M2 — Kho kiến thức song ngữ (bổ sung ngày 2026-10-28)

Baseline M2 gốc gồm 100 bài, 200 phiên bản v1 draft và 1.400 chunks. Ngày 2026-10-29, **12 phiên bản v2 VI/EN được duyệt qua ủy quyền của tài khoản demo owner**, hiện có **212 phiên bản, 1.484 chunks**, trong đó **84 chunks approved/active**. PostgreSQL pgvector đã cài và migration mới chuyển sang `vector(2560)`; các test Rails PASS. Hai dịch vụ Qwen3-Embedding-4B và Qwen3-Reranker-4B đã deploy trên Modal A10G trong environment `rails-8-ai-customer-support-desk`; đã ghi 84 embeddings thật và đo reranking 12 câu VI/EN với Top1=12/12. Đây chỉ là pilot M2, chưa hoàn tất M2/M3.

- **Nghiệm thu live** 4B/4B, provenance và bảo mật: `docs/M2_DUAL_QWEN3_4B_LIVE_ACCEPTANCE_VI.md`
- Hướng dẫn triển khai trước đó: `docs/M2_DUAL_QWEN3_4B_IMPLEMENTATION_VI.md`
- Hướng dẫn M2 đầy đủ: `docs/M2_IMPLEMENTATION_GUIDE_VI.md`
- Preview để duyệt offline: `preview/m2_knowledge/index.html`
- Dataset: `data/m2/knowledge_drafts.json`
- Khi chạy Kaggle/Colab, sau M1: `bash script/run_full_m2.sh`

Evidence offline cũ không phải AI acceptance. Đã có runtime PostgreSQL evidence riêng; không chạy lại M1/M2 importer khi database có KB v2 được duyệt.

### Khắc phục lỗi xác thực PostgreSQL trên Kaggle/Colab

Nếu xuất hiện `FATAL: password authentication failed for user "support_desk"` ngay sau `service postgresql start`, script phiên bản cũ đã truyền các biến PGUSER/PGPASSWORD của ứng dụng vào lệnh quản trị role. Không xóa database, không cần cài đặt lại Ruby/gems. Từ thư mục project, chạy:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

Bản sửa thực thi quản trị qua Unix socket `postgres` với môi trường sạch, sau đó xác minh kết nối TCP của `support_desk`. Mật khẩu vẫn nằm trong `.env.notebook` (git-ignored), không ghi vào logs. Chỉ dùng cho demo synthetic trên Kaggle/Colab; **không** sử dụng cho production hay máy có PostgreSQL thật.
