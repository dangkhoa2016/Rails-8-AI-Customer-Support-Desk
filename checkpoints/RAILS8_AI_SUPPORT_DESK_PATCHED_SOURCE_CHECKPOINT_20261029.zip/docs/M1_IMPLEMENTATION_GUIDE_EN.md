# Rails 8 AI Customer Support Desk — M1 Workspace and Acceptance Guide (EN)

**Policy:** M0 approved (`policy_version=1.0.0`). **M1:** implementation sources and deterministic synthetic business dataset have been generated and verified **offline only**. Rails migration, PostgreSQL seeding, live Rails authorization tests and Modal inference have **NOT** been run.

## Prepared and tested assets

- Approved canonical blueprint and paired VI/EN specifications preserved, including 20 policy IDs and 100 planned KB titles (no KB full text).
- Three Rails 8 migration drafts for tenant/shared tables and the two business verticals. Twenty-two ActiveRecord model wrappers and a tenant/customer-scoped agent-only read-only lookup service. No login UI, complete authentication or customer portal is implemented.
- Deterministic `m1_business_records.json` with 100 customers, 40 workspaces/subscriptions, 80 invoices, 35 exports, 50 API events, 8 incidents, 40 products, 120 orders, 180 order items, 120 payments, 130 shipments, 25 returns and 12 warranty claims, plus supporting activation/shipment/return rows and synthetic agent membership fixtures. **These are generated JSON records, not persisted PostgreSQL rows.**
- Transactional natural-key Rails importer, verification scripts, offline relationship checks (SQLite composite-FK emulation), unit tests including adversarial tampering, hashes and evidence.
- Original TeamFlow activation failure and NovaMart partial shipment reference fixtures are preserved.

## Reproduce offline checks

From the package root:

```bash
python3 m1_starter/script/generate_m1_dataset.py \
  --blueprint RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json \
  --out m1_starter/data/m1_business_records.json
python3 m1_starter/script/verify_m1_dataset.py \
  --blueprint RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json \
  --dataset m1_starter/data/m1_business_records.json \
  --report evidence/m1/offline-relational-verification.json
(cd m1_starter && python3 -m unittest discover -s test -p 'test_m1_dataset.py' -v)
ruby m1_starter/test/policy_rules_test.rb
```

The generator does not call AI or produce ticket/KB/evaluation gold. Reruns should generate a byte-identical dataset for the same seed, code and blueprint.

## Apply to a fresh Rails 8 + PostgreSQL synthetic-demo environment

Requirements: Ruby >= 3.2, Rails 8, Bundler, PostgreSQL server/client and a fresh disposable development database. Install these separately for your target Kaggle/Colab machine and verify versions. Internet is required there for initial dependency installation. **Never point the scripts to real customer data.**

```bash
ruby -v
gem install rails -v '~> 8.0' --no-document
rails new Rails-8-AI-Customer-Support-Desk --database=postgresql
cd Rails-8-AI-Customer-Support-Desk
bundle install
cd ..
# RAILS_PACKAGE must be an absolute path to this extracted package.
bash "$RAILS_PACKAGE/m1_starter/script/prepare_rails_app.sh" \
  "$PWD/Rails-8-AI-Customer-Support-Desk"
# Configure your own PostgreSQL service and DATABASE_URL/config/database.yml first.
M1_SYNTHETIC_DEMO=YES bash \
  "$RAILS_PACKAGE/m1_starter/script/run_m1_on_rails.sh" \
  "$PWD/Rails-8-AI-Customer-Support-Desk" \
  "$PWD/m1_postgres_evidence"
```

The preparer refuses to overwrite changed target files; the runner never deletes databases. It captures exit codes and logs for actual migration, initial import, verification, second import (idempotency) and verification. Do not claim database acceptance if any step fails.

## M1 acceptance still requiring real PostgreSQL execution

Require successfully executed Rails migrations, full row counts, duplicate-free reruns, tenant/customer access checks, reference fixtures and business money invariants. Stronger database-level cross-row guards for cumulative shipped quantities, immutable historical snapshots and allowed state transitions should be implemented and tested before claiming full business-rule hardening; offline checks do **not** prove those guards. Preserve failing cases and sanitized logs for external review.

Outside M1: 100 full-text KB articles, 240 tickets, 120 sealed gold evaluation cases, any Modal benchmark, production security certification or deployed UI.
