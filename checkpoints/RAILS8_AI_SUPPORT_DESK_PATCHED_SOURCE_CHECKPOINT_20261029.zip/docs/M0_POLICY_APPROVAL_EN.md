# M0 — APPROVED POLICY BASELINE (SYNTHETIC BUSINESSES)

**Status:** M0 APPROVED on 2026-10-28 (ICT), based on the project owner's confirmation in this conversation. **Policy version:** `1.0.0`.

This approves a baseline for two **synthetic business tenants** for implementation and testing; these are not real-world company terms. Approval does **not** imply database seeds, a running Rails app, or measured Modal inference.

Approved groups: M0-01 TeamFlow plans, M0-02 activation/billing/refund, M0-03 NovaMart shipping/payment, M0-04 returns/warranty/partial shipment, M0-05 shared SLA/lifecycle, M0-06 dataset quotas, M0-07 acceptance/security gates.

## Approved implementation clarifications

### M0-CLAR-001 — TF-POL-002, TF-POL-003
An invoice marked paid does not activate an upgrade unless its matching activation event succeeded. Keep requested_plan and effective_plan separate. On success, upgrades start a new billing cycle without proration; downgrades take effect at the next renewal.

### M0-CLAR-002 — TF-POL-002, TF-POL-007
A past_due subscription retains its last verified effective plan in the demo for read-only support lookup. Past_due alone must not trigger entitlement changes; only an authorized rule/workflow may change them.

### M0-CLAR-003 — TF-POL-007, TF-POL-008
Refund requests within 7 local calendar days (inclusive, counting the paid date as day zero) of the first paid invoice are eligible for human review, never automatic approval. Later requests are routed for exception review without a promise. A refund request alone does not change the subscription state.

### M0-CLAR-004 — NM-POL-004, NM-POL-005
Ordinary returns use the 7-calendar-day local-date window after confirmed delivery of the relevant item. Defective/damaged/missing/wrong-item reports use a separate 14-day local-date window. Day 7/day 14 remain eligible, day 8/day 15 are outside those standard windows.

### M0-CLAR-005 — NM-POL-005, NM-POL-006
A 14-day defect-report window is not a blanket warranty expiry. Warranty eligibility must be evaluated independently from the product warranty_months and verified item delivery date in this demo.

### M0-CLAR-006 — NM-POL-007, NM-POL-009
Order delivered requires all fulfillable order-item quantities to have a verified delivered shipment; a shipped order may have only partially delivered items. Partial delivery does not authorize automatic refund or replacement.

### M0-CLAR-007 — NM-POL-001, NM-POL-007
Orders may remain pending_payment before paid. Transition to confirmed, packing, shipped or delivered requires a matching authorized paid payment record. Partially_refunded is a payment state and does not automatically imply canceled fulfillment.

### M0-CLAR-008 — NM-POL-002, NM-POL-008
Use immutable order-item snapshots to calculate net merchandise total. Standard shipping is 30000 VND when net merchandise < 500000, otherwise 0 VND, without including shipping in the threshold.

## SLA interpretation
Business-hours SLA clock starts at the first inbound customer public message, stops at the first actually sent human-agent public reply; AI drafts and automated notices do not stop it. Pending_customer does not pause this first-response clock.

## Still not executed
Rails migrations, database seeds, full-text KB, tickets, evaluation cases, Modal inference and benchmarks: **NOT_RUN**.
