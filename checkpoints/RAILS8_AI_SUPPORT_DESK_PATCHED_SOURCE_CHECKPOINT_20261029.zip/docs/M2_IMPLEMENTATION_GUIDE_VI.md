# M2 — Knowledge Base song ngữ, quản trị phiên bản và truy xuất có quyền

**Trạng thái (2026-10-28):** Mã nguồn M2 và dữ liệu toàn văn đã tạo; **PASS_OFFLINE_ONLY**. Migrations PostgreSQL, Rails HTTP tests, embedding Model/Modal và kiểm thử retrieval runtime đều **NOT_RUN**. **Không có bài viết nào được tự phê duyệt.**

## 1. Phạm vi và nguồn dữ liệu

- 100 KB article ID chính xác từ JSON canonical M0: TeamFlow 50, NovaMart 50.
- 200 phiên bản nội dung (100 tiếng Việt + 100 tiếng Anh), 1.400 chunk xác định được SHA256.
- Không tạo thêm article ID, policy hoặc tính năng vượt ngoài nguồn thiết kế. Nội dung diễn giải an toàn và bằng chứng cần kiểm tra được biên soạn riêng theo mỗi chủ đề trong `script/m2/author_notes.tsv`.
- Mỗi bài có policy IDs ánh xạ từ `policy_knowledge_links`, cộng thêm nội dung policy M0 liên quan; bài không có policy ID trực tiếp luôn cảnh báo không tự khẳng định tính năng/giới hạn thiếu bằng chứng.
- M0 là **approval của business rules**, không phải approval của nội dung 100 bài. M2 toàn văn hiện là `draft`, `approved_by = null`, `approved_at = null`.
- `data/m2/knowledge_drafts.json` chứa nội dung, metadata, kiểm tra hash, quyền xem và chunks. Đây là dữ liệu **đã tạo ngoại tuyến** chứ chưa import vào DB.

## 2. Database và Rails

Migration `20261028000500_create_knowledge_base.rb` thêm:

- `knowledge_articles`: organization, article_key, category, audience (`public`/`agent`), policy_refs.
- `knowledge_article_versions`: organization, article, locale, version_number, title, body, status, effective dates, SHA256, policy version, source digest, approval actor/time.
- `knowledge_chunks`: organization, article version, chunk_index, body, SHA256, embedding status/version.

Composite foreign keys và unique indexes giúp chống tham chiếu sai tenant, ngăn hai bản `approved` cùng một article/locale. GIN `to_tsvector('simple', body)` dùng tìm kiếm từ vựng native PostgreSQL; **chưa có vector embedding và không tuyên bố semantic RAG**. Dữ liệu embeddings luôn `not_generated`.

Controller và services:

- `/knowledge_articles`: danh mục và tìm kiếm. Search service **chỉ** lấy version `approved`, policy khớp, trong thời hạn, có approver, đúng tenant, đúng locale và đúng audience.
- `/knowledge_articles/:id`: hiển thị nội dung; draft chỉ owner/admin thấy.
- `POST /knowledge_articles/:id/approve`: owner/admin có session/membership hợp lệ mới được duyệt; có audit; source hash phải khớp và chunks khôi phục chính xác full text; đã duyệt không được sửa nội dung âm thầm.
- `audience=agent`: agent/admin/owner được đọc, viewer/customer không được lấy qua retrieval.

## 3. Kiểm tra offline

```bash
python3 script/generate_m2_knowledge.py
python3 script/verify_m2_knowledge.py
python3 -m unittest discover -s test -p test_m2_knowledge.py -v
python3 script/render_m2_preview.py
python3 script/offline_scaffold_check.py
ruby script/check_erb_syntax.rb
```

Xem HTML riêng biệt trong `preview/m2_knowledge/index.html`; trang này **chỉ dành cho duyệt bản nháp offline**, không phải KB đã phát hành. Mỗi file theo doanh nghiệp/ngôn ngữ, không trộn dòng EN/VI.

## 4. Chạy Rails + PostgreSQL ở Kaggle/Colab

Chỉ chạy với **database demo tổng hợp** và môi trường development, không sử dụng dữ liệu cá nhân thật:

```bash
bash script/notebook_setup.sh
source script/use_notebook_env.sh
export RAILS_ENV=development M1_SYNTHETIC_DEMO=YES
bash script/run_full_m1.sh
bash script/run_full_m2.sh
bin/rails server -b 127.0.0.1 -p 3000
```

M2 script chạy migrate, import seed 2 lượt kiểm idempotency, xác minh database, kiểm thử HTTP security, xuất logs/exit codes/SHA256. Nó **không tự approve** bất kỳ bài viết nào. Sau khi nhân viên owner/admin thực sự rà soát và duyệt một bài, mới được tìm trong approved search.

Nếu DB không có M1 records, chạy seed M1 trước. Không chạy `db:drop`, `db:reset` hay đưa public demo login qua Cloudflare Tunnel. Bằng chứng runtime cần lưu và gửi review, đặc biệt `evidence-m2-runtime/m2-runtime-summary.json`, lỗi test và `checksums.sha256`.

## 5. Những việc còn dang dở để đạt M2 acceptance hoàn chỉnh

1. Chạy Rails boot, PostgreSQL migrations, seed và integration tests trên Kaggle/Colab, xử lý mọi lỗi thật.
2. Human review từng bài full-text và cả hai phiên bản VI/EN, phê duyệt qua quyền admin/owner; giữ lịch sử audit. Không tự coi M0 approval là KB approval.
3. Benchmark và chốt phiên bản embedding model trên Modal với chi phí, GPU, hash, kết quả thực; tạo embedding cho **approved/current chunks** (không nhét draft/expired KB vào index), lựa chọn pgvector và kiểm chứng dimension/model revision.
4. Đánh giá retrieval bằng tập case độc lập gồm đúng nguồn, đúng version/tenant/ACL; kiểm tra expired/draft, ngôn ngữ, prompt injection. Không dùng sealed evaluation cases của M3 để tuning.

## 6. Bằng chứng và bảo toàn chính sách

Các trường provenance tối thiểu: M0 policy version `1.0.0`, canonical blueprint SHA256, author notes SHA256, content/chunk SHA256, locale, article ID, source policy refs, index/embedding model revision nếu có. **Chưa có Modal endpoint, GPU results hoặc measured semantic accuracy.**

### Khắc phục lỗi xác thực PostgreSQL trên Kaggle/Colab

Nếu xuất hiện `FATAL: password authentication failed for user "support_desk"` ngay sau `service postgresql start`, script phiên bản cũ đã truyền các biến PGUSER/PGPASSWORD của ứng dụng vào lệnh quản trị role. Không xóa database, không cần cài đặt lại Ruby/gems. Từ thư mục project, chạy:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

Bản sửa thực thi quản trị qua Unix socket `postgres` với môi trường sạch, sau đó xác minh kết nối TCP của `support_desk`. Mật khẩu vẫn nằm trong `.env.notebook` (git-ignored), không ghi vào logs. Chỉ dùng cho demo synthetic trên Kaggle/Colab; **không** sử dụng cho production hay máy có PostgreSQL thật.
