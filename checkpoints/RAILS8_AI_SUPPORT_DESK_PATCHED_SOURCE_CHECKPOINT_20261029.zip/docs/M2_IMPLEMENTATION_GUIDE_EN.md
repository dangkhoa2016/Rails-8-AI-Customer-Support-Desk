# M2 — Bilingual Knowledge Base, Versioning, Human Approval and Scoped Retrieval

**Status (2026-10-28):** Full-text M2 sources and Rails integration written; **PASS_OFFLINE_ONLY**. Actual Rails/PostgreSQL execution, Modal embeddings, and semantic retrieval benchmarks remain **NOT_RUN**. No KB article has been silently approved.

## 1. Source and scope

- Exactly 100 canonical M0 article IDs: 50 TeamFlow Cloud and 50 NovaMart Store.
- 200 full-text language versions (100 Vietnamese and 100 English), with 1,400 SHA256-verifiable source chunks.
- Original mapped policy references come from `policy_knowledge_links`; policy content and M0 clarifications are included where relevant. Each topic has distinct verified-evidence and safe-response guidance written in `script/m2/author_notes.tsv`.
- An article without a direct approved policy mapping explicitly warns against inventing feature guarantees or operational contracts.
- Approval of the M0 business rules **does not constitute approval of editorial KB articles**. All 200 language versions remain `draft` with no reviewer attribution.
- The generated `data/m2/knowledge_drafts.json` is a reproducible offline artifact, **not seeded PostgreSQL rows**.

## 2. Rails data model and guarded access

Migration `20261028000500_create_knowledge_base.rb` adds organization-scoped articles, article versions and content chunks. Composite FKs, constrained statuses, policy versions, effective dates, reviewer metadata, SHA256 checks and scoped uniqueness support provenance. PostgreSQL native `to_tsvector('simple', body)` GIN indexing enables **lexical** retrieval; it is not vector search or an AI benchmark.

- `GET /knowledge_articles`: browse; authorized retrieval only returns current, approved, tenant-matching, locale-matching, audience-permitted versions.
- `GET /knowledge_articles/:id`: per-article review, with drafts limited to owner/admin.
- `POST /knowledge_articles/:id/approve`: owner/admin session authorization, content/chunk hash checks, immutable published content and audit event.
- `audience=agent` never appears to viewers/customers through the search service.

## 3. Offline verification

```bash
python3 script/generate_m2_knowledge.py
python3 script/verify_m2_knowledge.py
python3 -m unittest discover -s test -p test_m2_knowledge.py -v
python3 script/render_m2_preview.py
python3 script/offline_scaffold_check.py
ruby script/check_erb_syntax.rb
```

Open `preview/m2_knowledge/index.html` for **draft editorial review only**. Four separately localized pages allow reading and filtering all article texts without running Rails.

## 4. Kaggle/Colab runtime acceptance

On a disposable development machine containing only synthetic records:

```bash
bash script/notebook_setup.sh
source script/use_notebook_env.sh
export RAILS_ENV=development M1_SYNTHETIC_DEMO=YES
bash script/run_full_m1.sh
bash script/run_full_m2.sh
bin/rails server -b 127.0.0.1 -p 3000
```

The M2 script executes migrations, imports drafts twice to test idempotency, checks database relationships and runs Rails security integration tests. Logs, exit codes, timestamps and SHA256 files are collected in `evidence-m2-runtime/`. These commands have **not run in the authoring workspace**. Never expose the passwordless development demo publicly or use real customer records.

## 5. Pending M2 completion gates

1. Actual Rails 8/PostgreSQL boot, migration, seed and HTTP security tests; preserve failures and logs.
2. Human editorial review/approval per article and locale, with auditable reviewer identity; no auto-approval.
3. Benchmark and pin Modal embedding model/revision, GPU and cost. Embed **only approved/current chunks** with a versioned vector index after dimension verification; pgvector/vector search are not implemented yet.
4. Independent retrieval assessment for correct citations, version/date filtering, authorization and languages, including prompt injection cases. M3 sealed tests must remain separate from tuning.

**Provenance:** canonical M0 policy `1.0.0`, blueprint SHA256, author notes SHA256, article/chunk content digests, locale and policy references. There are no live Modal inference or measured retrieval accuracy claims.

### PostgreSQL authentication repair on Kaggle/Colab

If setup reports `FATAL: password authentication failed for user "support_desk"`, the old setup inherited application PostgreSQL variables while running admin commands. Do not reset or drop the database, and do not reinstall Ruby/gems. From the application root run:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

The repair uses a clean Unix-socket `postgres` admin connection, sets the local demo role password without logging it, then verifies TCP authentication as `support_desk`. Intended only for disposable synthetic Kaggle/Colab notebooks; never for production or real databases.
