# M0 — PHÊ DUYỆT BASELINE CHÍNH SÁCH (DOANH NGHIỆP GIẢ LẬP)

**Trạng thái:** ĐÃ PHÊ DUYỆT M0 vào ngày 2026-10-28 (ICT), theo phản hồi của chủ dự án trong cuộc trò chuyện. **Policy version:** `1.0.0`.

Đây là phê duyệt baseline của hai **doanh nghiệp giả lập** để triển khai và kiểm thử; không phải chính sách của một công ty có thật. M0 được duyệt **không** có nghĩa dữ liệu đã seed, Rails đã chạy, hay Modal đã được benchmark.

Các nhóm duyệt: M0-01 TeamFlow plans, M0-02 activation/billing/refund, M0-03 NovaMart shipping/payment, M0-04 returns/warranty/partial shipment, M0-05 shared SLA/lifecycle, M0-06 dataset quotas, M0-07 acceptance/security gates.

## Giải thích triển khai đã được duyệt

### M0-CLAR-001 — TF-POL-002, TF-POL-003
Hóa đơn paid chưa đủ để kích hoạt gói nâng cấp nếu activation event tương ứng chưa succeeded. Tách requested_plan và effective_plan. Nâng cấp thành công bắt đầu chu kỳ mới, không prorate; hạ gói có hiệu lực ở kỳ gia hạn tiếp theo.

### M0-CLAR-002 — TF-POL-002, TF-POL-007
Subscription past_due giữ gói effective đã xác minh gần nhất để hỗ trợ tra cứu trong demo. Không tự đổi entitlement chỉ từ past_due; thay đổi cần rule/workflow đã phân quyền.

### M0-CLAR-003 — TF-POL-007, TF-POL-008
Yêu cầu refund trong 7 ngày lịch địa phương (bao gồm ngày thứ 7, ngày paid là ngày 0) từ hóa đơn paid đầu tiên được xem xét thủ công, không tự phê duyệt. Quá hạn chuyển xét ngoại lệ, không hứa chấp thuận. Yêu cầu refund không tự thay đổi subscription.

### M0-CLAR-004 — NM-POL-004, NM-POL-005
Đổi/trả thông thường tính 7 ngày lịch theo ngày địa phương từ ngày giao xác nhận của item tương ứng; báo lỗi/hỏng/thiếu/sai là cửa sổ riêng 14 ngày lịch. Ngày 7/14 còn trong hạn; ngày 8/15 quá hạn tiêu chuẩn.

### M0-CLAR-005 — NM-POL-005, NM-POL-006
Cửa sổ 14 ngày báo lỗi không đồng nghĩa hết quyền bảo hành. Điều kiện bảo hành xét độc lập theo warranty_months và ngày giao sản phẩm đã được xác nhận trong demo.

### M0-CLAR-006 — NM-POL-007, NM-POL-009
Order delivered đòi hỏi mọi số lượng order-item cần giao đã có shipment được xác minh delivered; order shipped có thể mới giao một phần. Giao thiếu một phần không cho phép tự refund hoặc gửi thay thế.

### M0-CLAR-007 — NM-POL-001, NM-POL-007
Đơn có thể ở pending_payment trước khi paid. Chuyển confirmed, packing, shipped, delivered cần payment paid hợp lệ có phân quyền. partially_refunded là trạng thái thanh toán, không tự suy ra fulfillment đã canceled.

### M0-CLAR-008 — NM-POL-002, NM-POL-008
Dùng snapshot bất biến của order items tính tổng hàng sau discount; phí thường là 30.000 VND khi dưới 500.000 VND, ngược lại 0 VND; không cộng phí ship vào ngưỡng.

## Quy tắc SLA
Đồng hồ SLA giờ làm việc bắt đầu từ public message đầu tiên do khách gửi, dừng ở public reply đầu tiên thực sự do nhân viên gửi; AI draft và thông báo tự động không được tính. pending_customer không dừng đồng hồ first response.

## Hạng mục còn dang dở
Rails migrations, database seeds, full-text KB, tickets, evaluation cases, Modal inference và benchmark: **NOT_RUN**.
