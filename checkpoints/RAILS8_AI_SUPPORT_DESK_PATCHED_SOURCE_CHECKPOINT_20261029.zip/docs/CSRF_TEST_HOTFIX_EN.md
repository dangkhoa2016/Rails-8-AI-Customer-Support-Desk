# Rails 8 Support Desk — CSRF Integration Test Hotfix (2026-10-29)

Confirmed issue: 9 of 10 M1 security integration tests fail during the demo sign-in helper with `ActionController::InvalidAuthenticityToken`; the helper posts a membership without first obtaining the Rails CSRF token. Additional unsafe POST/PATCH requests in both M1 and M2 suites have the same vulnerability.

This patch only updates integration test code and adds a shared CSRF-aware request helper. Each state-changing request first GETs a rendered page to obtain a token from the current session; logins obtain the sign-in page token, while authenticated operations obtain the dashboard token. The controller resets the session on login, so a new token must be fetched afterwards. **No CSRF protection is disabled.** No migrations, seeds, business rules, or database state are modified.

Extract the ZIP into the Rails app directory, check `CSRF_TEST_HOTFIX_SHA256SUMS.txt`, execute `python3 script/verify_csrf_patch.py`, run the Rails M1 integration suite again, then run the full M1/M2 acceptance scripts if it passes. Runtime execution must be verified on Kaggle/Colab.
