# Rails 8 AI Customer Support Desk — M1 Seed Timestamp Hotfix

Date: 2026-10-29. Scope: M1 business-record import timestamps only.

## Confirmed source defect

JSON record maps have string keys, while the old importer read `attrs[:occurred_at]` and `attrs[:window_start]`. For `tf_api_request_events` and `tf_service_incidents` those expressions return `nil`; `Time.iso8601(nil)` cannot parse this. A failure rolls back the M1 transaction. M2 may then fail to find prerequisite organizations. This defect is demonstrated from the source; the notebook stderr is still required to confirm the actual exception.

## Apply in your existing Rails project directory

```bash
cd /path/to/Rails-8-AI-Customer-Support-Desk
unzip -o '<HOTFIX_ZIP>' -d .
sha256sum -c M1_SEED_TIMESTAMP_HOTFIX_SHA256SUMS.txt
ruby test/m1_seed_timestamp_test.rb
source script/use_notebook_env.sh
bash script/run_full_m1.sh
# Run M2 only after all M1 steps have returned exit 0.
bash script/run_full_m2.sh
```

Do not redo the initial notebook provisioning when PostgreSQL/gems are working. Do not drop or reset databases. The M1 importer is transactional and idempotent, and requires development mode with `M1_SYNTHETIC_DEMO=YES`.

## Inspect error logs if the problem persists

```bash
for f in evidence-run/07_seed_first.stderr.log evidence-m2-runtime/05_seed_first.stderr.log; do
  echo "===== $f ====="
  if [ -f "$f" ]; then tail -n 100 "$f"; else echo 'NOT_FOUND'; fi
done
```

Never share secrets, `.env.notebook` contents, or API tokens. PostgreSQL runtime tests have not been run inside the patch-authoring workspace.
