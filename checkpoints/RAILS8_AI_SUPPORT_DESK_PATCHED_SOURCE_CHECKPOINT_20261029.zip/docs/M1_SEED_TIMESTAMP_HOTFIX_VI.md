# Rails 8 AI Customer Support Desk — Bản vá M1 Seed Timestamp

Ngày: 2026-10-29. Phạm vi: chỉ xử lý timestamp trong M1 business-record importer.

## Lỗi đã phát hiện trong mã nguồn

Các bản ghi JSON dùng string keys, nhưng importer phiên bản trước tham chiếu `attrs[:occurred_at]` và `attrs[:window_start]`. Với `tf_api_request_events` và `tf_service_incidents`, giá trị này bằng `nil` nên `Time.iso8601(nil)` không thể xử lý. Importer chạy trong một transaction, lỗi làm rollback toàn bộ M1. M2 có thể không tìm thấy organizations vì M1 thất bại trước đó. Đây là lỗi suy ra trực tiếp từ mã nguồn; để xác định exception thực tế trên notebook cần xem stderr.

## Cách áp dụng (tại thư mục project Rails đã giải nén)

```bash
# Đặt <HOTFIX_ZIP> bằng path thực tế đến ZIP vừa upload vào Kaggle/Colab.
cd /path/to/Rails-8-AI-Customer-Support-Desk
unzip -o '<HOTFIX_ZIP>' -d .
sha256sum -c M1_SEED_TIMESTAMP_HOTFIX_SHA256SUMS.txt
ruby test/m1_seed_timestamp_test.rb
source script/use_notebook_env.sh
bash script/run_full_m1.sh
# Chỉ khi toàn bộ M1 exit code 0:
bash script/run_full_m2.sh
```

Không chạy lại `notebook_setup.sh` nếu PostgreSQL và Gems đã cài thành công. Không `db:drop`/`db:reset`. Script M1 dùng transaction và upsert idempotent; không xóa dữ liệu thật. Chỉ chạy trong development với `M1_SYNTHETIC_DEMO=YES`.

## Kiểm tra logs (nếu lỗi còn xảy ra)

```bash
for f in evidence-run/07_seed_first.stderr.log evidence-m2-runtime/05_seed_first.stderr.log; do
  echo "===== $f ====="
  if [ -f "$f" ]; then tail -n 100 "$f"; else echo 'NOT_FOUND'; fi
done
```

Đừng chia sẻ mật khẩu, `.env.notebook` hoặc tokens. Nếu còn lỗi, gửi traceback đã ẩn dữ liệu nhạy cảm. M1/M2 PostgreSQL runtime vẫn là `NOT_RUN` tại workspace tạo bản vá.
