# Rails 8 M1/M2 — Hotfix HTTP 404 trong integration tests

**Ngày:** 2026-10-29. **Phạm vi:** duy nhất `config/environments/test.rb`. Không sửa database, migrations, seeds, controllers, tenant filters hoặc CSRF protection.

## Bằng chứng / nguyên nhân

Colab: `10 runs, 98 assertions, 0 failures, 3 errors`. Ba lỗi đều là `ActiveRecord::RecordNotFound` tại `CustomersController#show`, `TicketsController#show`, `TicketsController#create` khi kiểm tra cross-tenant. Điều này cho thấy các truy vấn scoped không tìm thấy record thuộc tenant khác. Test lại đòi **HTTP 404**, trong khi `config.action_dispatch.show_exceptions = :none` khiến Rails ném exception trực tiếp.

Khắc phục: chỉ đổi `show_exceptions` từ `:none` sang `:rescuable` trong `config/environments/test.rb`. Rails 8 chuyển `RecordNotFound` thành 404 và tiếp tục raise những lỗi ngoài `rescue_responses`. **Không chọn `:all`, không rescue mọi exception và không tắt CSRF.**

## Áp dụng trên Colab/Kaggle (không xoá database)

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
unzip -o /content/RAILS8_AI_SUPPORT_DESK_TEST_404_HOTFIX_2026-10-29.zip -d .
sha256sum -c TEST_404_HOTFIX_SHA256SUMS.txt
python3 -m unittest discover -s test -p test_404_hotfix.py -v
python3 script/apply_test_404_hotfix.py
source script/use_notebook_env.sh

set +e
set -o pipefail
RAILS_ENV=test bin/rails test test/integration/support_desk_security_test.rb 2>&1 | tee /content/m1_http_security_404_retry.log
echo "M1_TEST_EXIT_CODE=${PIPESTATUS[0]}"
```

Nếu **M1_TEST_EXIT_CODE=0**, tiếp tục:

```bash
RAILS_ENV=test bin/rails test test/integration/knowledge_base_security_test.rb 2>&1 | tee /content/m2_http_security_404_retry.log
echo "M2_TEST_EXIT_CODE=${PIPESTATUS[0]}"
```

Sau khi cả hai PASS, chạy full acceptance và gửi `evidence-run/acceptance-summary.json` và `evidence-m2-runtime/m2-runtime-summary.json` cùng log nếu còn lỗi. Không kết luận PASS từ kiểm tra offline này.

## An toàn

Script có bảo vệ: chỉ sửa nếu tìm đúng một dòng `show_exceptions = :none`; nếu là `:rescuable` sẽ không sửa lần thứ hai; nếu là giá trị khác sẽ từ chối. Lần đầu ghi `config/environments/test.rb.pre-404-hotfix.bak` để rollback.
