# Rails 8 M1/M2 — HTTP 404 integration-test hotfix

**Date:** 2026-10-29. **Scope:** only `config/environments/test.rb`. No database, migration, seed, controller, tenant scope or CSRF code changes.

## Confirmed cause

Colab reported `10 runs, 98 assertions, 0 failures, 3 errors`. Each error is an `ActiveRecord::RecordNotFound` during deliberate cross-tenant access. The tenant-scoped query correctly fails to find the record, but test configuration `show_exceptions = :none` exposes the exception instead of HTTP 404, while the test asserts 404.

Solution: set `config.action_dispatch.show_exceptions = :rescuable` in the **test** environment only. Rails converts rescuable exceptions such as `RecordNotFound` into the appropriate HTTP status while re-raising unexpected programming errors. Do **not** use `:all`, broadly rescue exceptions, or disable CSRF.

## Apply and verify

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
unzip -o /content/RAILS8_AI_SUPPORT_DESK_TEST_404_HOTFIX_2026-10-29.zip -d .
sha256sum -c TEST_404_HOTFIX_SHA256SUMS.txt
python3 -m unittest discover -s test -p test_404_hotfix.py -v
python3 script/apply_test_404_hotfix.py
source script/use_notebook_env.sh

set +e
set -o pipefail
RAILS_ENV=test bin/rails test test/integration/support_desk_security_test.rb 2>&1 | tee /content/m1_http_security_404_retry.log
echo "M1_TEST_EXIT_CODE=${PIPESTATUS[0]}"
```

If M1 succeeds, run M2:

```bash
RAILS_ENV=test bin/rails test test/integration/knowledge_base_security_test.rb 2>&1 | tee /content/m2_http_security_404_retry.log
echo "M2_TEST_EXIT_CODE=${PIPESTATUS[0]}"
```

Only after both succeed run the full M1/M2 acceptance scripts. Runtime status remains NOT_RUN until verified on Colab/Kaggle. Script is idempotent and writes `config/environments/test.rb.pre-404-hotfix.bak` before the first modification.
