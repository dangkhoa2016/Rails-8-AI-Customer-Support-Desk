# Rails 8 AI Customer Support Desk — M1 Workspace và hướng dẫn nghiệm thu (VI)

**Mốc chính sách:** M0 đã được phê duyệt (`policy_version=1.0.0`). **M1:** mã nguồn, dữ liệu synthetic deterministic và kiểm tra OFFLINE đã tạo. **Chưa chạy Rails migrations, PostgreSQL seed, Rails authorization tests hoặc Modal inference.**

## Nội dung thực sự đã làm

- Bảo toàn JSON canonical đã phê duyệt, tài liệu Business Specification VI/EN, 20 policy IDs, 100 KB article titles và bản snapshot trước phê duyệt.
- Chuẩn bị 3 Rails migrations: shared tenant/ticket core, TeamFlow business records, NovaMart business records, chỉ áp dụng cho DB demo mới.
- Tạo 22 Rails model wrappers và dịch vụ `ReadOnlyBusinessLookup` kiểm tra membership và customer scope trước khi tra cứu. Đây là lớp dịch vụ nội bộ, **chưa có đăng nhập, controller, customer portal hay production RBAC**.
- Sinh deterministic JSON bằng `m1_starter/script/generate_m1_dataset.py`; tạo source M1 business data (không phải tickets/KB/evaluation gold), gồm các bản ghi theo quotas: 100 customers, 40 workspaces/subscriptions, 80 invoices, 35 exports, 50 API events, 8 incidents, 40 products, 120 orders, 180 order items, 120 payments, 130 shipments, 25 returns, 12 claims; cùng activation events, shipment items, synthetic users/memberships.
- Giữ 2 reference fixtures: TeamFlow paid invoice + activation failed; NovaMart order `NM-2026-0042` gồm 1 kiện delivered + 1 kiện in_transit.
- Chuẩn bị Rails importer transaction/idempotency + database verification script; chạy được sau khi có PostgreSQL thật.
- Thực hiện offline relational/business checks, deterministic replay và negative tamper tests; SQLite được dùng để **mô phỏng một tập composite FK**, không thay thế PostgreSQL.

## Chạy lại offline trên workspace bất kỳ

Từ thư mục gốc của package:

```bash
python3 m1_starter/script/generate_m1_dataset.py \
  --blueprint RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json \
  --out m1_starter/data/m1_business_records.json
python3 m1_starter/script/verify_m1_dataset.py \
  --blueprint RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json \
  --dataset m1_starter/data/m1_business_records.json \
  --report evidence/m1/offline-relational-verification.json
(cd m1_starter && python3 -m unittest discover -s test -p 'test_m1_dataset.py' -v)
ruby m1_starter/test/policy_rules_test.rb
```

Source generator không sử dụng AI và không sinh gold labels. Lần chạy lại phải tạo **byte-identical** JSON SHA256 nếu code và canonical blueprint không thay đổi.

## Chạy Rails 8/PostgreSQL lần đầu trên Kaggle hoặc Colab

Yêu cầu: Ruby >= 3.2, Rails 8, Bundler, PostgreSQL server đang chạy, libpq headers, database user và quyền tạo DB. Kaggle/Colab phải có internet trong bước cài dependencies. Không mặc định môi trường này đã sẵn sàng; **không chạy trên database chứa dữ liệu thật**.

```bash
# Cài Ruby 3.3+ và PostgreSQL bằng phương pháp phù hợp môi trường trước.
ruby -v
# Tạo Rails app mới một lần (nếu chưa tạo)
gem install rails -v '~> 8.0' --no-document
rails new Rails-8-AI-Customer-Support-Desk --database=postgresql
cd Rails-8-AI-Customer-Support-Desk
bundle install
cd ..

# Giả sử đã giải nén package và RAILS_PACKAGE là đường dẫn tuyệt đối.
bash "$RAILS_PACKAGE/m1_starter/script/prepare_rails_app.sh" \
  "$PWD/Rails-8-AI-Customer-Support-Desk"

# Cấu hình PostgreSQL riêng theo Kaggle/Colab, ví dụ DATABASE_URL hoặc config/database.yml.
# Chỉ chạy với DB mới dùng riêng cho demo, KHÔNG có khách hàng thật.
M1_SYNTHETIC_DEMO=YES bash \
  "$RAILS_PACKAGE/m1_starter/script/run_m1_on_rails.sh" \
  "$PWD/Rails-8-AI-Customer-Support-Desk" \
  "$PWD/m1_postgres_evidence"
```

`prepare_rails_app.sh` chỉ sao chép file nếu đích chưa tồn tại hoặc byte-identical, không tự ghi đè code đã sửa. `run_m1_on_rails.sh` không xóa/reset database; chạy migration, Ruby unit tests, importer, database verifier, **seed lần thứ hai** và verify lại để kiểm chứng idempotency. Có lệnh và exit code từng bước, logs riêng và `checksums.sha256`. Nếu test thất bại, **giữ nguyên failed logs**, không công bố PASS.

## Acceptance gate M1 trên PostgreSQL (chưa đạt)

1. Rails migration thực chạy thành công trên PostgreSQL mới, phiên bản và command được ghi lại.
2. Seed lần đầu và lần hai thành công; row counts đúng; không trùng hoặc hỏng dữ liệu.
3. Check composite FKs, tenant/customer authorization, verified business lookups, hai reference fixtures và snapshot money invariants.
4. Bổ sung và kiểm tra DB-level transactional guard cho cumulative shipment quantities, immutable order snapshots, payment authorization và state transitions trước khi tuyên bố hardening hoàn tất. Hiện các quy tắc cross-row còn được kiểm tra bằng offline verifier và post-seed verification; **chưa được bảo đảm hoàn toàn bằng DB triggers**.
5. Gửi về `m1_postgres_evidence` gồm logs, pass/fail, table counts, environment, checksums; không đưa token/password/PII vào gói công khai.

**Không thuộc M1:** 100 full-text KB, 240 tickets, 120 sealed evaluation cases, Modal inference, frontend demo, screenshots, tuyên bố production-ready.
