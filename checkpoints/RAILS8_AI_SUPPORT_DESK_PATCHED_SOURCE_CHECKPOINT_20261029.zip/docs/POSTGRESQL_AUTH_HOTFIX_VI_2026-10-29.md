# Sửa lỗi xác thực PostgreSQL — Kaggle / Colab (29-10-2026)

## Dấu hiệu

`service postgresql start` thành công, sau đó `psql`/`createuser` báo `FATAL: password authentication failed for user "support_desk"`. Đây là lỗi bootstrap script dùng nhầm `PGUSER=support_desk` khi chạy lệnh quản trị dưới OS account `postgres`. Không liên quan dữ liệu KB, tickets hoặc M0.

## Sửa nhanh notebook đã cài đặt một phần

Giữ nguyên `.env.notebook`, không cài lại Ruby/gems và không xóa database. Trong thư mục project đã áp dụng hotfix:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

Kỳ vọng thấy: `PASS: postgres local peer admin + support_desk TCP password authentication.` Nếu lỗi tiếp diễn, chỉ gửi thông báo lỗi đã che credentials, không gửi `.env.notebook`.

Nếu đang dùng ZIP project cũ: upload ZIP hotfix nhỏ, giải nén vào **thư mục project hiện tại** để ghi đè `script/notebook_setup.sh`, bổ sung `script/repair_notebook_postgres.sh`, rồi chạy các lệnh trên.

## Tại sao an toàn hơn

- Quản trị role qua Unix socket với OS account `postgres`, môi trường sạch `env -i` và `-U postgres`.
- Dùng lại mật khẩu sinh trước đó, cập nhật `support_desk` qua SQL stdin (không lộ mật khẩu trong argv).
- Kiểm tra thực tế `support_desk` có thể xác thực TCP bằng chính `.env.notebook`.
- Không chạy `db:drop`, `db:reset`; role tạo lại được khi gọi lặp, database giữ nguyên.
- Chỉ hoạt động trong notebook disposable Kaggle/Colab, dev synthetic; không dùng cho môi trường production.

**Giới hạn:** Script đã được kiểm tra cú pháp và offline; thử nghiệm xác thực PostgreSQL thực tế cần chạy trên Kaggle/Colab, chưa được nghiệm thu trong workspace này.
