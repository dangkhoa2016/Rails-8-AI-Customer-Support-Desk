# M2 SESSION HANDOFF — Rails 8 AI Customer Support Desk

**Ngày:** 2026-10-28 (ICT). **Cấp triển khai:** Source/offline authoring. **KHÔNG coi là đã được nghiệm thu runtime.**

## A1. EXACT CONTINUATION POINT

1. Giữ nguyên M0-approved canonical policy `1.0.0`, TeamFlow Cloud và NovaMart Store; không chọn lại doanh nghiệp, không thay policy, không tái tạo M1.
2. M1 đã có standalone Rails source và deterministic business-records JSON; Rails 8/PostgreSQL thật chưa chạy. Gói này dựa trên nguyên trạng đó và bổ sung M2, không ghi đè workspace M1 gốc.
3. M2 đã **sinh 100 bài toàn văn** (50 TeamFlow, 50 NovaMart), mỗi bài hai bản VI/EN = **200 editorial drafts**; **1.400 chunks** chưa có embedding; `data/m2/knowledge_drafts.json`. Toàn bộ status `draft`; không có article version nào approved.
4. Đã soạn content bằng 100 bộ author notes song ngữ theo đúng catalog IDs/policy refs và M0 clarifications, có hash và dữ liệu nguồn; không lấy model output làm evidence hay gold.
5. Đã viết migration 005, 3 models, service publication (human-only), service lexical retrieval (tenant + ACL + locale + approved/effective policy), controller + views VI/EN, Rails integration tests, offline negative tests, importer idempotent, verification scripts và HTML review preview.
6. Kiểm chứng offline **PASS**: 14 Python M2 tests, source/ERB checks, M1 regression, byte-identical deterministic regeneration, hash validation. **Rails boot, PostgreSQL migrations/seed/tests, API/inference/embeddings Modal, semantic RAG benchmark: NOT_RUN**.
7. **Bước tiếp theo:** trên Kaggle/Colab với database demo, chạy `bash script/notebook_setup.sh`, `source script/use_notebook_env.sh`, `bash script/run_full_m1.sh`, `bash script/run_full_m2.sh`, kiểm tra evidence, sửa runtime issues nếu xuất hiện. Chỉ sau đó cho owner/admin review và approve KB từng bản ngôn ngữ (KHÔNG approve tự động), rồi lập benchmark embeddings trên Modal và pgvector.
8. Nếu M2 chưa hoàn thiện runtime/approval/vector, không chuyển trạng thái M2 thành DONE hoặc quảng bá là RAG AI đã chạy. **M3 tickets/evaluation** vẫn NOT_STARTED.

## Artifact map

- `docs/RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json` — source M0 policy; không đổi.
- `script/m2/author_notes.tsv` — nội dung biên tập riêng cho 100 tiêu đề, mỗi bản VI/EN có evidence+guidance.
- `script/generate_m2_knowledge.py` — generator deterministic, luôn xuất drafts.
- `data/m2/knowledge_drafts.json` — 100 logical articles, 200 language draft versions, 1400 chunks.
- `db/migrate/20261028000500_create_knowledge_base.rb` — migration Rails/PostgreSQL (chưa chạy).
- `db/seeds/m2_knowledge_base.rb` — idempotent importer (chưa chạy).
- `app/models/knowledge_*`, `app/services/knowledge_*`, `app/controllers/knowledge_articles_controller.rb` — version, approval, scoped lookup.
- `app/views/knowledge_articles/`, `config/locales/{vi,en}.yml` — editorial UI.
- `test/integration/knowledge_base_security_test.rb` — runtime test source chưa chạy.
- `test/test_m2_knowledge.py` — offline + negative test source, đã chạy.
- `script/run_full_m2.sh`, `script/verify_m2_database.rb` — Kaggle/Colab commands/evidence (chưa chạy).
- `preview/m2_knowledge/index.html` — static DRAFT review preview, 4 separate tenant/language pages.
- `review/m2_editorial_review_manifest.csv` — 200 rows, review decisions intentionally blank.
- `evidence/m2/m2-offline-manifest.json` — actual offline commands/times/exit codes, other states NOT_RUN.
- `docs/M2_IMPLEMENTATION_GUIDE_VI.md`, `docs/M2_IMPLEMENTATION_GUIDE_EN.md` — runbooks.

## Rules not to violate

- M0 approval != editorial KB approval.
- Generated drafts != seeded PostgreSQL rows.
- Native PostgreSQL `tsvector` search source != executed lexical benchmark, and is **not** vector similarity/RAG inference.
- Only owner/admin Rails session may approve. Agent/Viewer cannot publish.
- Unapproved, expired, superseded, mismatched-policy or cross-tenant KB must not enter retrieval.
- Do not auto-send public replies or let AI mutate business data.
- No public Quick Tunnel for demo passwordless login; no real PII/tokens.

---

## English continuation summary

The M2 source stage has generated exactly 100 canonical full-text KB articles with paired Vietnamese/English drafts (200 versions and 1,400 chunks). All are deliberately pending editorial approval; no embeddings or Modal inference were executed. Migration, importer, guarded publishing, PostgreSQL lexical search code and integration tests are included but require actual Rails/PostgreSQL execution. Offline source/integrity tests pass. Resume by running the provided M1 and M2 acceptance scripts on a disposable Kaggle/Colab notebook, reviewing runtime evidence, then approving edited articles with owner/admin authority and benchmarking pinned Modal embeddings before claiming M2 RAG acceptance.
