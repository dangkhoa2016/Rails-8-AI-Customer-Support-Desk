# Rails 8 Support Desk — Bản vá CSRF cho Integration Tests (29/10/2026)

## Nguyên nhân xác nhận

Colab chạy `10 runs, 3 assertions, 0 failures, 9 errors` với `ActionController::InvalidAuthenticityToken` tại helper `sign_in` (dòng 110) trong `support_desk_security_test.rb`. Code gốc POST login mà không GET trang và không cung cấp CSRF token. Các request POST/PATCH nghiệp vụ trong M1/M2 cũng cần token khi test bật CSRF verification.

## Sửa gì

- Thêm `test/support/csrf_requests.rb`, helper GET một trang được server render và lấy `<meta name="csrf-token">` từ chính session hiện tại.
- Đổi `sign_in` và các POST/PATCH trong test M1/M2 sang `post_with_csrf`/`patch_with_csrf`.
- GET lại token sau mỗi lần login/account switch vì controller gọi `reset_session`.
- **KHÔNG** tắt bảo vệ CSRF, không thay đổi controller, DB, migrations hoặc seeds.

## Cách dùng trên Colab/Kaggle

Giải nén ở thư mục Rails đang chạy (KHÔNG giải nén ở thư mục cha):

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
unzip -o /content/RAILS8_AI_SUPPORT_DESK_CSRF_TEST_HOTFIX_2026-10-29.zip -d .
sha256sum -c CSRF_TEST_HOTFIX_SHA256SUMS.txt
python3 script/verify_csrf_patch.py
ruby -c test/support/csrf_requests.rb
ruby -c test/integration/support_desk_security_test.rb
ruby -c test/integration/knowledge_base_security_test.rb
source script/use_notebook_env.sh
set -o pipefail
RAILS_ENV=test bin/rails test test/integration/support_desk_security_test.rb 2>&1 | tee /content/support_desk_http_security_csrf_retry.log
printf 'TEST_EXIT_CODE=%s\n' "${PIPESTATUS[0]}"
```

Nếu PASS, tiếp tục `bash script/run_full_m1.sh`, sau đó `bash script/run_full_m2.sh`. Không chạy `db:drop` hoặc `db:reset`. Nếu phát sinh assertion khác, giữ nguyên failure log để kiểm tra thay vì sửa theo phỏng đoán.

## Xác minh ở workspace

Đã chạy syntax và static-coverage checks. Rails/PostgreSQL test runtime chỉ có thể xác nhận tại Colab/Kaggle. Không tuyên bố runtime PASS trước khi có log.
