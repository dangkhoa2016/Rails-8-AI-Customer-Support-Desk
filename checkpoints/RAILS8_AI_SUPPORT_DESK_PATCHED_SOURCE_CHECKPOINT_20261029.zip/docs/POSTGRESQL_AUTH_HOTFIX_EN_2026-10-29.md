# PostgreSQL authentication hotfix — Kaggle / Colab (2026-10-29)

When `service postgresql start` succeeds but `psql`/`createuser` fails with `FATAL: password authentication failed for user "support_desk"`, the setup script is incorrectly reusing app PG environment variables in admin commands.

## Recover without reinstalling

Patch the existing project scripts, then run from the project root:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

Expected message: `PASS: postgres local peer admin + support_desk TCP password authentication.` Keep `.env.notebook` private; do not share it in logs. No databases are dropped or reset. Use only in disposable synthetic Kaggle/Colab development notebooks.

The repair was statically checked and all offline regression tests passed, but has **not** yet been runtime-tested against a live PostgreSQL instance in this workspace.
