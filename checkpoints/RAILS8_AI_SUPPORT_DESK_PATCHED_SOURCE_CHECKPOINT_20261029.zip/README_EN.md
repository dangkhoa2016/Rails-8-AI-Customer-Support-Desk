# Rails 8 AI Customer Support Desk

**Status: standalone Rails 8 application source created; OFFLINE checks only. Rails boot, PostgreSQL migrations, HTTP integration tests and database seeding have not executed in this workspace because Rails gems and package registry access are unavailable.**

## Included in this stage

- One Rails 8 app with PostgreSQL and server-rendered ERB views, separate EN/VI localizations, and no frontend build tooling.
- Two synthetic tenants: `TeamFlow Cloud` (`b2b_saas`) and `NovaMart Store` (`ecommerce`).
- **Development/test-only** passwordless synthetic account selector. Membership-verified session selects a tenant; neither model output nor request parameters can override it. This is **not production authentication**.
- Tenant-scoped dashboard, customers, TeamFlow invoices, NovaMart orders and partial shipments, with read-only authorized lookups.
- Manual ticket intake, conversation history, internal notes, explicit agent-approved public replies, audit records, idempotency, constrained state transitions.
- Five Rails migrations (four M1 and one M2), imported M1 business/core models, deterministic M1 business records and relational fixtures, seed importer, validation scripts and regression tests.

**Not yet delivered/accepted:** Approved/published KB or vector embeddings (100 bilingual full-text editorial drafts have been generated offline in M2), 240 M3 tickets, 120 final evaluation cases, Modal inference, embeddings/RAG, AI drafts, production security, live customer authentication or email delivery. No AI benchmark claims are made.

## Run with existing Ruby 3.3+ and PostgreSQL

```bash
cd Rails-8-AI-Customer-Support-Desk
bundle install
# Configure a disposable local PostgreSQL demo role/database through PGHOST/PGUSER/PGPASSWORD/PGDATABASE.
export RAILS_ENV=development M1_SYNTHETIC_DEMO=YES
bin/rails db:create db:migrate
bin/rails runner db/seeds/m1_full_business_records.rb
bin/rails runner script/verify_m1_database.rb
bin/rails server -b 127.0.0.1 -p 3000
```

Visit `http://127.0.0.1:3000/demo/sign_in`, select a synthetic TeamFlow/NovaMart agent, and inspect the workflows. Sessions and records are separated by tenant. **Do not use the demo login or synthetic database on a public production site.**

## Full acceptance on Kaggle/Colab

With notebook Internet enabled, extract the app and run as the notebook root user:

```bash
bash script/notebook_setup.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bin/rails server -b 127.0.0.1 -p 3000
```

The notebook setup installs runtime dependencies, uses mise to install Ruby 3.3 and creates a locally stored `.env.notebook` for a disposable PostgreSQL account. The full acceptance script collects commands, UTC timestamps, stdout/stderr, exit codes and SHA256 in `evidence-run/`. It contains no `db:drop` or `db:reset` and refuses non-development mode. **Do not expose the passwordless demo through a public Quick Tunnel.** Only consider public exposure after proper authentication/authorization hardening.

Alternative local Docker setup (not run in this workspace): `docker compose up --build`. The fixed Compose database password is for isolated localhost development only.

## Provenance and limitations

- Canonical M0-approved policy is `docs/RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json`, version `1.0.0`.
- The synthetic M1 dataset lives in `data/m1_business_records.json`; seed `20261028`, reference time `2026-10-28T00:00:00+07:00`.
- Evidence-backed read-only lookups and database-level composite FKs are intended to prevent tenant leakage, pending runtime tests.
- Public replies are stored after an explicit human approval action. There is **no actual external email or Modal AI endpoint**.
- Original M0 documents, policy approval logs and immutable source snapshot are available under `docs/`.

**`PASS_SOURCE_ONLY` and `PASS_OFFLINE_ONLY` must never be represented as PostgreSQL or AI acceptance.**

## M2 — Bilingual Knowledge Base (added 2026-10-28)

The M2 workspace now contains **100 generated full-text KB articles** (50 per tenant) with separate Vietnamese/English versions: **200 editorial drafts and 1,400 chunks**. This is offline-generated content, **not approved/published material**. A fifth Rails migration, review/approval UI and tenant/locale/ACL/status/effective-date-filtered lexical search are included. Embeddings, pgvector, live Modal inference and actual Rails/PostgreSQL execution remain **NOT_RUN**.

- M2 implementation and acceptance: `docs/M2_IMPLEMENTATION_GUIDE_EN.md`
- Standalone editorial preview: `preview/m2_knowledge/index.html`
- Deterministic full-text data: `data/m2/knowledge_drafts.json`
- Kaggle/Colab after M1: `bash script/run_full_m2.sh`

Offline checks do not constitute Rails/PostgreSQL or AI acceptance.

### PostgreSQL authentication repair on Kaggle/Colab

If setup reports `FATAL: password authentication failed for user "support_desk"`, the old setup inherited application PostgreSQL variables while running admin commands. Do not reset or drop the database, and do not reinstall Ruby/gems. From the application root run:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

The repair uses a clean Unix-socket `postgres` admin connection, sets the local demo role password without logging it, then verifies TCP authentication as `support_desk`. Intended only for disposable synthetic Kaggle/Colab notebooks; never for production or real databases.
