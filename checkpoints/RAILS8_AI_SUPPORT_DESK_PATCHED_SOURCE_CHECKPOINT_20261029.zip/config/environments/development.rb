Rails.application.configure do
  config.enable_reloading = true
  config.eager_load = false
  config.consider_all_requests_local = true
  config.action_controller.perform_caching = false
  config.active_support.deprecation = :log
  config.active_record.verbose_query_logs = true
  config.action_mailer.default_url_options = { host: 'localhost', port: 3000 }
  config.hosts << /.*\.trycloudflare\.com/ if ENV['ALLOW_QUICK_TUNNEL'] == 'YES'
end
