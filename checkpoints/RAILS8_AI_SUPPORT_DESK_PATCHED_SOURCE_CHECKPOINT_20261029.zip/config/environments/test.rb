Rails.application.configure do
  config.enable_reloading = false
  config.eager_load = ENV['CI'] == 'true'
  config.consider_all_requests_local = true
  config.action_controller.perform_caching = false
  config.action_dispatch.show_exceptions = :rescuable
  config.active_support.deprecation = :stderr
  config.action_mailer.delivery_method = :test
end
