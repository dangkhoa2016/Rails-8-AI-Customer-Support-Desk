# M2 — Isolated Modal GPU POC: Qwen3 decomposition and mDeBERTa NLI (EN)

**Executed:** October 29, 2026, Asia/Ho_Chi_Minh  
**Status:** `GPU_POC_EXECUTED_NOT_RELEASE / DECOMPOSITION_SOURCE_INTEGRITY_FAIL / NLI_NOT_QUALIFIED / HUMAN64_PENDING`

## 1. Isolation and model provenance

This was a **one-time Modal run**, not `modal deploy`. Both functions lived in the ephemeral application `rails8-support-desk-m2-claim-nli-onetime-poc`. There were no HTTP endpoints, webhooks, customer data, Rails DB writes, or new public features. Each GPU job was capped to a single container, `scaledown_window=2`, with timeouts of **480 seconds for A10** and **300 seconds for T4**. The local CLI had an overall process timeout. The ephemeral Modal app is now **stopped**; the two previous pinned Qwen3-Embedding-4B and Qwen3-Reranker-4B applications remain **deployed**.

Exact model revisions independently retrieved from Hugging Face before running:
- `Qwen/Qwen3-4B-Instruct-2507` pinned SHA `cdbee75f17c01a7cc42f958dc650907174af0554`, Apache-2.0, A10.
- `MoritzLaurer/mDeBERTa-v3-base-mnli-xnli` pinned SHA `8adb042d524ecd5c26d3e3ba0e3fbcf7e2d0864c`, MIT, T4, FP32.

Approved KB, the Rails preview (relevance-only), the sealed80 fail-closed optional scope flag, model services and business data remain untouched. No Git commits or pushes were requested or made during this stage.

## 2. Frozen BEFORE inference: development-only cases

`review/m2_new_models_isolated_poc_development_20261029.json` is a new developer-authored **8-question decomposition / 12-pair NLI** development manifest, with 2 questions per TeamFlow/NovaMart × VI/EN and 4 pairs per NLI label (entailment, neutral, contradiction). It is **not** a new blinded holdout and labels are **not independently adjudicated**.

Manifest SHA256: `bab124fdab56ed5b0bc1d36b5208a240d4ddcca0bed6b336914df0158e50508a`.

NLI policy premises came from exact approved KB v2 `Authoritative policy` / `Chính sách có hiệu lực` sections with tenant, locale, article version and full-body SHA256. Frozen premise manifest `review/m2_new_models_isolated_poc_nli_premises_20261029.json` SHA256: `419e2e6c7547c579f410c99587a9449d52e259115086cd84b77a9fb4bb73874e`.

## 3. Qwen3-4B-Instruct-2507, measured on A10

| Metric | Observed |
|---|---:|
| Development composite questions | 8 |
| Valid JSON parse | **7/8** |
| Strict source_excerpt+Unicode-offset contract | **0/8** |
| Model load time inside the GPU job | 30.254 s |
| Total generation time for eight responses | 64.507 s |
| Median response generation time | 7.941 s |
| Remote invocation wall time including model startup | 105.096 s |
| Peak torch CUDA allocation | 8,168,526,336 bytes (~7.61 GiB) |

Seven parsed JSON objects have `source_excerpt` that **does not match the original question substring at the claimed `source_start/source_end` Unicode offsets**. The validator calls this a `fabricated excerpt`; it means **source-span mismatch**, not necessarily that a phrase never occurs elsewhere in the question. One response was not JSON-parsable.

No model output was silently repaired, no offsets adjusted for acceptance, and no semantic-fidelity pass was inferred. The model can run and return text, but **its present JSON/source-span format does not meet the proposed safe claim-extraction contract**. Result: `BLOCK_DECOMPOSITION_INTEGRATION`.

A future design may have the model select exact *excerpts* while deterministic host code locates and verifies source positions, handles duplicates/omissions and marks ambiguous spans unresolved. It requires a **new**, independently created development test and a separate held-out test.

## 4. mDeBERTa-v3-base-mnli-xnli, measured on T4 FP32

| Metric | Observed |
|---|---:|
| NLI pairs with exact approved-KB source provenance | **12/12** |
| Predicted label matching developer labels | **9/12 (75%)** |
| ID2LABEL read from model config | 0 entailment, 1 neutral, 2 contradiction |
| Model load time | 6.486 s |
| Remote invocation wall time | 18.168 s |
| Peak torch CUDA allocation | 1,175,723,008 bytes (~1.10 GiB) |

Confusion matrix (developer labels as rows, model prediction columns):

| Label | Entailment | Neutral | Contradiction |
|---|---:|---:|---:|
| Entailment | 3 | 0 | 1 |
| Neutral | 0 | 3 | 1 |
| Contradiction | 0 | 1 | 3 |

Mismatches:
- `NLI-TF-VI-N` developer neutral → model contradiction: the premise provides **no stated refund routing guarantee in two hours**, which must not be equated with an explicit negative policy.
- `NLI-NM-EN-E` developer entailment → model contradiction; predicted contradiction softmax **0.3940** versus neutral **0.3937**, essentially tied and uncalibrated.
- `NLI-NM-EN-C` developer contradiction → model neutral: on automatic approval of a day-seven ordinary return, even though approved policy requires human review.

A raw three-way softmax is **not** a calibrated probability that a customer-facing answer is authorized or correct. Although the source integrity passed, this is a small **developer-labeled** POC, not independent semantic acceptance. Result: `BLOCK_NLI_INTEGRATION`.

## 5. Resource and cost accounting

Ephemeral Modal image build took **80.85 seconds** during first use. It is separate from GPU inference and must not be conflated with model-generation time.

Measured remote-invocation wall time: **105.096 s A10** + **18.168 s T4** = **123.264 s total**. Under the published GPU-only rates at https://modal.com/pricing (A10 **$0.000306/s**; T4 **$0.000164/s**), multiplying *these client-observed invocation durations* yields an **illustrative ~$0.03514 GPU-only figure**. **It is NOT a verified Modal invoice**: network wait, GPU billed seconds, startup and retained container time differ. CPU, RAM, image building, storage, egress, any failed preliminary attempt and actual bills are not reconciled here.

## 6. Evidence, safety checks and rollback

Implementation and evaluation:
- `modal_app/m2_claim_nli_poc.py`: two capped, pinned, isolated Modal functions; no ASGI app, no secret requirement, no persistent service endpoint.
- `script/evaluate_m2_new_model_poc.py`: verifies exact frozen hashes and both model revisions, Qwen JSON/source-span contract, NLI KB SHA/version/source and confusion matrix. No post-inference threshold fitting.
- `script/render_m2_new_model_poc_review.py`: generates self-contained static offline review HTML showing the eight Qwen raw responses and 12 NLI predictions.
- `script/validate_m2_external_review_export.py`: separately checks 64-claim external human review exports for correct source hashes, tenant, article, exact policy quote and completeness. It **cannot authenticate reviewer identity or independence**.
- `test/test_m2_external_review_export.py`: **5 PASS** (synthetic negative/incomplete tests, not signed human decisions).

In `evidence-m2-new-modal-model-poc-20261029/`:
- `decomposition-live.json` SHA256 `7b0a598e210886d9c17d0d78009b534400f4a86ce1e05537b66c544d6b249328`
- `nli-live.json` SHA256 `93c84e2615e06d80687c56facdbe84e788da98902fc6d9b626d7082d9ffd4bdb`
- `poc-evaluation.json` SHA256 `7a33d722c555cc2a95fbd68895d57df672a4978835737f8323c3015fa2b0d970`
- `poc-review-static.html` SHA256 `7c47f6863919c17427822a6abf893941698117c01926c293acdb7793e1b8cbff`
- Additional `preflight.json`, `modal-run.log`, `full-rails-tests.log`, `external-review-validator-tests.log`.

**Full Rails regression: 78 tests, 4,424 assertions, zero failures/errors/skips.** Five external export validator unit tests PASS. The independent 64-claim human review remains **NOT_RUN**; no reviewer sign-off is claimed. No DB resets or KB changes.

## 7. Continuation

1. Obtain an actual human review of all 64 claims using `evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`. The export validator requires 20+ exact source characters for affirmative/negative policy citations and explanatory notes for no-policy or uncertain classes. It is not an identity or authorization check; independent sign-off must be verified separately.
2. For decomposition, create a **new developmental set** to assess deterministic source-span recovery from model-selected exact substrings; fail on ambiguous multiple matches, dropped intents and altered polarity. Preserve all failed original outputs.
3. For NLI, isolate explicit-negative vs unsupported-neutral judgments and apply human confirmation of both source entailment and action permissions. Never use similarity scores as policy authority.
4. Use a separate **new locked holdout** with VI/EN balance, multi-intent negative guarantees, action requests, case-specific facts, PII/prompt-injection, and human adjudications only after iterating on **fresh dev data**. Proposed target >=80% recall per VI/EN stratum and zero unsafe accepted hard-negative claims; zero on a finite holdout never proves real-world zero risk.
5. Do not enable the old scope gate or expose these trial model outputs via the Rails preview. Preserve all previously approved data/versions and production-like model services.

**Final assessment:** GPU feasibility observed (two models ran successfully), **quality/safety acceptance FAILED**. No release.
