# M2 — GPU POC độc lập: Qwen3 tách ý + mDeBERTa NLI (VI)

**Ngày:** 2026-10-29 (Asia/Ho_Chi_Minh)  
**Trạng thái:** `GPU_POC_EXECUTED_NOT_RELEASE` / `DECOMPOSITION_FAIL_STRICT_SOURCE` / `NLI_NOT_QUALIFIED` / `HUMAN64_PENDING`.

## 1. Quyết định kiến trúc và bảo toàn hệ thống

Hai model thử nghiệm chạy bằng **Modal ephemeral jobs** trong app `rails8-support-desk-m2-claim-nli-onetime-poc`, **không deploy endpoint HTTP, không công khai tunnel, không sửa Rails controller, không truy cập database production hoặc tự tạo business writes**. Mỗi job chạy trên một GPU, giới hạn `max_containers=1`, `scaledown_window=2`, timeout **480 s A10** và **300 s T4**; toàn bộ `modal run` có timeout phía Colab. Không có token/proxy credential trong bundle POC.

Model pin xác minh trực tiếp qua HF API trước khi chạy:
- Qwen `Qwen/Qwen3-4B-Instruct-2507` SHA `cdbee75f17c01a7cc42f958dc650907174af0554`, Apache-2.0, A10.
- NLI `MoritzLaurer/mDeBERTa-v3-base-mnli-xnli` SHA `8adb042d524ecd5c26d3e3ba0e3fbcf7e2d0864c`, MIT, T4, FP32.

Các endpoint `Qwen3-Embedding-4B` và `Qwen3-Reranker-4B` đã nghiệm thu trước vẫn **deployed**; app thử nghiệm **stopped** sau khi hoàn tất. Feature `M2_ANSWERABILITY_SCOPE_ENABLE` vẫn bị interlock của sealed80 BLOCK; không tích hợp claim-level mới vào UI. Dữ liệu synthetic approved giữ nguyên.

## 2. Bộ dữ liệu POC khóa trước GPU

`review/m2_new_models_isolated_poc_development_20261029.json`:
- **8 câu tổng hợp mới**, mỗi tenant TeamFlow/NovaMart × ngôn ngữ VI/EN có 2 câu.
- **12 mệnh đề NLI developer-authored**: 4 entailment, 4 neutral, 4 contradiction; 3 mỗi tenant×locale. Không dùng nhãn human độc lập.
- Manifest SHA256: `bab124fdab56ed5b0bc1d36b5208a240d4ddcca0bed6b336914df0158e50508a`.

`review/m2_new_models_isolated_poc_nli_premises_20261029.json`: lưu chính xác trích đoạn `Authoritative policy` hoặc `Chính sách có hiệu lực` từ 12 approved KB v2; mỗi đoạn còn gắn đúng tenant, locale, article_key, version_id và SHA256 toàn bài. SHA256 `419e2e6c7547c579f410c99587a9449d52e259115086cd84b77a9fb4bb73874e`.

Hai file được tạo **trước inference**, không thay đổi trong quá trình đánh giá. Cả 8/12 chỉ là **development smoke cases**, không phải sealed holdout mới hoặc independent human gold.

## 3. Kết quả thực Qwen3-4B-Instruct-2507 (A10)

| Chỉ số | Thực tế |
|---|---:|
| Input synthetic | 8 |
| JSON parse được | **7/8** |
| Hợp đồng exact source excerpt/offset đầy đủ | **0/8** |
| Thời gian tải model trong job | 30,254 s |
| Tổng thời gian sinh 8 response | 64,507 s |
| Trung vị thời gian sinh/response | 7,941 s |
| Tổng thời gian gọi GPU job đo ở client (kể cả khởi tạo) | 105,096 s |
| Peak CUDA memory allocated | 8.168.526.336 bytes (~7,61 GiB) |

Nhiều output có `source_excerpt` không đúng **chuỗi con tại cặp chỉ số Unicode source_start/source_end đã công bố**; kiểm tra trả `fabricated excerpt` (đây là **mismatch giữa đoạn và chỉ số**, không tự động chứng minh từ ngữ trong đoạn không xuất hiện ở nơi khác trong câu). Một case trả văn bản không parse được JSON. Nhiều nội dung có thể vẫn có ích để con người nhìn tham khảo, nhưng **không qua hợp đồng provenance** và chưa được kiểm tra đầy đủ về bỏ sót/đảo nghĩa. Không thay model output, không sửa offsets sau inference để tính PASS.

**Verdict: `BLOCK_DECOMPOSITION_INTEGRATION`.** Chưa có căn cứ cho phép model tự phân tích mọi câu khách hàng. Hướng thay thế cần thí nghiệm mới: model chỉ chọn các đoạn nguyên văn; code không phải LLM xác định vị trí span được chứng minh, bắt buộc coverage đầy đủ và kiểm tra semantic fidelity bằng human. Không tái đánh giá 8 case đã mở như một holdout mới.

## 4. Kết quả thực mDeBERTa-v3-base-mnli-xnli (T4, FP32)

| Chỉ số | Thực tế |
|---|---:|
| NLI pairs | 12 (4 mỗi loại gold) |
| Valid approved KB version, SHA256, exact premise | **12/12** |
| Khớp nhãn thử nghiệm do developer đặt | **9/12**, 75% |
| Label order đọc trực tiếp từ `model.config.id2label` | 0 entailment, 1 neutral, 2 contradiction |
| Thời gian tải model | 6,486 s |
| Tổng thời gian gọi job (kể cả khởi tạo) | 18,168 s |
| Peak CUDA memory allocated | 1.175.723.008 bytes (~1,10 GiB) |

Ma trận (hàng developer gold, cột model prediction):

| Nhãn | Entailment | Neutral | Contradiction |
|---|---:|---:|---:|
| Entailment | 3 | 0 | 1 |
| Neutral | 0 | 3 | 1 |
| Contradiction | 0 | 1 | 3 |

Ba trường hợp sai nhãn developer:
- `NLI-TF-VI-N`: expected neutral, predicted contradiction. Một giả định về hoàn tiền vào tài khoản khác trong 2 giờ **không có dữ kiện hỗ trợ** từ chính sách.
- `NLI-NM-EN-E`: expected entailment, predicted contradiction, điểm contradiction **0,3940** so với neutral **0,3937** — sát nhau và không thể xem là kết luận chắc chắn.
- `NLI-NM-EN-C`: expected contradiction (trả hàng ngày 7 không được tự phê duyệt), predicted neutral.

Raw softmax không calibrated; điểm contradiction không tự động cấp quyền trả lời “không”, đặc biệt khi premise là policy excerpt và hypothesis có nhiều điều kiện. Số liệu 75% là **so với nhãn do người triển khai viết, chưa có adjudication độc lập**, cỡ mẫu rất nhỏ.

**Verdict: `BLOCK_NLI_INTEGRATION`**. Cần thêm test neutral-vs-explicit-negative/contradiction, consistency EN/VI, các ví dụ case-specific và độc lập kiểm duyệt.

## 5. Thời gian và chi phí giới hạn

- `modal run` ephemeral, không `modal deploy`. Image runtime mất **80,85 s** để build lần đầu; build image không phải thời gian GPU inference.
- Hai lượt remote invocation wall: **105,096 s A10** + **18,168 s T4** = **123,264 s**. Không bao gồm mọi bước chuẩn bị local/image-build.
- Giá GPU công bố https://modal.com/pricing ở thời điểm kiểm tra: A10 **$0,000306/s**, T4 **$0,000164/s**. Nếu nhân nguyên thời gian invocation wall với GPU rates thì kịch bản GPU-only **~$0,03514**. Đây là **ước lượng trên wall time, KHÔNG PHẢI hóa đơn GPU thực**; gồm scheduler/network/cold startup khác billable GPU seconds. Chi phí Modal có thể thêm CPU, RAM, image build, egress, lưu trữ, lần thử không thành công trước khi chạy và các khoản khác. Không tuyên bố chi phí cuối cùng hoặc giá tính trên mỗi claim.

## 6. Evidence, kiểm thử và rollback

- `modal_app/m2_claim_nli_poc.py`: hai job Modal riêng, không endpoint; giới hạn task, pinned model IDs/revisions, max token/context, 8/12 case, raw output.
- `script/evaluate_m2_new_model_poc.py`: kiểm tra output theo hợp đồng offline; **không sửa raw outputs**.
- `script/render_m2_new_model_poc_review.py`: render HTML tĩnh đọc riêng 8+12 kết quả.
- `script/validate_m2_external_review_export.py`: kiểm tra structural completeness và quoted text đúng bài KB/tenant/lang của 64 human review JSON.
- `test/test_m2_external_review_export.py`: **5/5 tests PASS**, toàn negative/incomplete giả lập; không tạo reviewer giả.

Chứng cứ trong `evidence-m2-new-modal-model-poc-20261029/`:
- `decomposition-live.json` SHA256 `7b0a598e210886d9c17d0d78009b534400f4a86ce1e05537b66c544d6b249328`
- `nli-live.json` SHA256 `93c84e2615e06d80687c56facdbe84e788da98902fc6d9b626d7082d9ffd4bdb`
- `poc-evaluation.json` SHA256 `7a33d722c555cc2a95fbd68895d57df672a4978835737f8323c3015fa2b0d970`
- `poc-review-static.html` SHA256 `7c47f6863919c17427822a6abf893941698117c01926c293acdb7793e1b8cbff`
- `modal-run.log`, `preflight.json`, `full-rails-tests.log`, `external-review-validator-tests.log`.

**Rails regression: 78 tests / 4.424 assertions / 0 failures/errors/skips.** External reviewer export unit tests: **5 PASS**. Trạng thái human độc lập: **NOT_RUN**; không giả chữ ký, không tự xác nhận tài liệu. Git commit/push: không thực hiện. Database approval/embedding không được sửa.

## 7. Next step

1. Cho người khác đánh giá 64 claim qua `evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`. Bản export sẽ được `script/validate_m2_external_review_export.py` đối chiếu cấu trúc và exact KB quote (câu trích phải ít nhất 20 ký tự và là chuỗi con thực của bài KB approved). Validator **không xác thực danh tính reviewer**; cần quy trình ký duyệt riêng.
2. Thiết kế source-span architecture **deterministic**: Qwen chỉ xuất chính xác excerpt và intent, program xác định vị trí trong query; nếu có nhiều match/missing span -> abstain. Thử trên **tập dev mới**; giữ tất cả raw rejects.
3. Dùng model NLI chỉ như đề xuất kiểm tra có điều kiện, không được suy ra policy entitlement trực tiếp từ score; cần reviewer label ba nhóm affirm/explicit-negative/not-documented.
4. Sau hiệu chỉnh trên tập dev mới, tạo sealed holdout độc lập mới, có chỉ tiêu recall >=80% từng EN/VI và không chấp nhận unsafe claim trên hard negatives. Chưa được công bố production acceptance.
5. Tiếp tục giữ Rails preview **relevance-only** và interlock scope sealed80 blocked; giữ hai model 4B/4B cũ. Mọi lần chạy GPU mới chỉ sau khi thiết kế phương pháp kiểm thử riêng và giới hạn tài nguyên.

**Đánh giá cuối:** Feasibility GPU PASS (mô hình chạy và trả output thật); **quality/safety acceptance FAIL**. Không release.
