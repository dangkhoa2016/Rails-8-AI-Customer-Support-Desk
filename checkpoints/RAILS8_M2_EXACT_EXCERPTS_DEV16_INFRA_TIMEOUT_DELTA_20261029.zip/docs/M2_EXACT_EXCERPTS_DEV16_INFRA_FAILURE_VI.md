# M2 — Deterministic Exact-Excerpt Recovery: Development 16 (VI)

**Ngày:** 2026-10-29 (Asia/Ho_Chi_Minh)  
**Trạng thái:** `OFFLINE_IMPLEMENTATION_TESTED / GPU_DEV16_INFRASTRUCTURE_TIMEOUT / MODEL_QUALITY_NOT_EVALUATED / NOT_RELEASE`.

## 1. Điểm xuất phát và phạm vi

Dự án Rails 8 AI Customer Support Desk vẫn có hai doanh nghiệp giả lập TeamFlow Cloud và NovaMart Store. M0 business policy v1.0.0, DB 100 KnowledgeArticle / 212 versions / 12 approved / 84 embeddings, và hai endpoint Modal **Qwen3-Embedding-4B + Qwen3-Reranker-4B** đã nghiệm thu được giữ nguyên. Giao diện Cloudflare preview chỉ dùng relevance-only. Optional scope verifier vẫn bị khóa (`KnowledgeScopePreviewGate.eligible? == false`) sau sealed80 FAIL. Không tự phản hồi khách hàng, không AI business writes, không phê duyệt hoàn tiền/đổi trả/kích hoạt gói.

POC độc lập trước sử dụng `Qwen/Qwen3-4B-Instruct-2507` revision `cdbee75f17c01a7cc42f958dc650907174af0554` trên Modal A10, có 7/8 JSON hợp lệ nhưng **0/8 đạt kiểm tra source excerpt và offset**; model NLI mDeBERTa T4 khớp 9/12 nhãn developer. Không diễn giải các số liệu này như production acceptance.

## 2. Forensics của 8 output cũ (read-only, sau khi đã xem kết quả)

Khi chỉ xét 16 excerpt do Qwen xuất trong 7 JSON parse được:
- **14/16** excerpt xuất hiện nguyên văn **duy nhất** trong câu hỏi nguồn.
- **0/14** có vị trí bắt đầu do model khai báo đúng vị trí tìm bằng Python.
- 2 excerpt còn lại không xác nhận được là exact unique substring.

Nguồn: `evidence-m2-exact-excerpts-dev16-20261029/old8-source-excerpt-forensics.json`.  
SHA256: `4da563c146afa5d6b3c0f0acd4fbcd7d9ad9c3684a781f62e0de410dbfb0d3ec`.

Đây là **post-hoc diagnostics trên bộ đã mở**, không phải kiểm thử mới. Dữ liệu gợi ý việc tách tác vụ **model chọn excerpt, code tính offsets** có thể giải quyết một nhóm lỗi, nhưng chưa chứng minh chọn đủ ý, nhận dạng intent, không đảo cực tính hoặc policy entailment.

## 3. Triển khai bộ phục hồi span theo code, không cho model tự tính offset

Code: `script/m2_deterministic_exact_spans.py`.

- Model chỉ được xuất `claims` và `unresolved`; mỗi claim có `id`, `excerpt` nguyên văn liên tục, `intent` và `needs_case_data`. Không cho xuất `source_start`, `source_end` hoặc `hypothesis` nhằm tránh tráo nghĩa khi paraphrase.
- Python sử dụng so khớp **chính xác Unicode, không fuzzy matching** để xác định duy nhất vị trí; từ chối excerpt thiếu, lặp lại nhiều vị trí, chồng lấn, sai schema, ID/thứ tự không hợp lệ, vượt giới hạn và nội dung có dấu hiệu PII.
- Mọi chữ/số trong câu hỏi gốc phải nằm trong span claim hoặc span `unresolved`. Thiếu bất kỳ đoạn có chữ/số nào sẽ `SpanRejected` (fail closed).
- Trả trạng thái `source_integrity_verified: true` nhưng **`semantic_fidelity_verified: false`**, `business_actions_authorized: false` và `human_review_required: true`. Dữ liệu candidate không được tích hợp vào Rails controllers.

**Giới hạn quan trọng:** Việc bao phủ đủ ký tự **không chứng minh** một câu hỏi nhiều ý đã được chia đúng. Model có thể chọn một span dài che cả nhiều ý. Validator không tự chứng minh sự đúng đắn về semantics hoặc entailment.

## 4. Development set mới khóa trước GPU

`review/m2_exact_excerpt_development16_20261029.json`  
SHA256: `380de3f24ddc765cb7e3545b2d03dd8f66535918c79fd85614bcddedcfac5f11`.

Có **16 câu synthetic**, mỗi TeamFlow VI / TeamFlow EN / NovaMart VI / NovaMart EN **4 câu**, tối thiểu hai intent độc lập theo đánh giá developer. Gồm yêu cầu hứa giờ, trả/hoàn tiền, quyền gói, partial shipment và nội dung text yêu cầu bỏ qua an toàn để kiểm tra khả năng không thực thi lệnh trong query. Không có dữ liệu khách hàng thật. Đây chỉ là development set, không phải sealed holdout, các nhãn chưa được người độc lập xác minh.

`modal_app/m2_exact_excerpts_dev16_poc.py`: Modal ephemeral app `rails8-support-desk-m2-exact-excerpts-dev16-onetime`, GPU **A10**, max_containers=1, 1 run, model pinned đúng revision, seed **20261029**, timeout function **480 giây** và timeout CLI hữu hạn; không endpoint HTTP.

`script/evaluate_m2_exact_excerpts_dev16.py`: đánh giá độc lập (sau khi có GPU outputs) cho JSON parse, exact source-span, số intents tối thiểu, coverage không unresolved và chênh lệch tenant/locale. `script/render_m2_exact_excerpts_dev16.py`: HTML tĩnh cho đủ case, giữ nguyên raw outputs và rejects.

## 5. Kết quả kiểm thử thực tế

| Bài kiểm tra | Kết quả |
|---|---|
| Deterministic exact-span unit tests | **15/15 PASS** |
| Hợp đồng model offline đã có | **10/10 PASS** |
| Validator export cho human independent reviewer | **5/5 PASS** |
| Full Rails suite | **78 tests / 4.424 assertions / 0 failures, errors, skips** |
| Bộ 16 câu development, dữ liệu và SHA256 trước GPU | **PASS** |
| GPU generation Qwen dev16 | **NOT_EVALUATED** — Modal timeout |
| Tỷ lệ chính xác decomposition trên 16 câu | **KHÔNG CÓ**, không được công bố |

Modal function lỗi `FunctionTimeoutError`: **đúng timeout 480 giây**, client-observed function wall **483,891 giây**. Container log cho thấy `Fetching 3 files` tới bước **2/3** trong lúc lấy checkpoint shard và không có thông báo hoàn tất load/generation trước khi timeout. Đây là **quan sát về hạ tầng**, không đủ để quy kết nguyên nhân chắc chắn (HF network, container I/O, cache hay runtime). **Không có `exact-excerpt-live.json`**, do đó không có kết quả để chấm; tuyệt đối không tính là 0% quality. Lần chạy không được tự động retry và không sửa manifest/số liệu.

Modal app POC đã **stopped**; hai service 4B cũ vẫn **deployed**. DB trước/sau không đổi: **100 / 212 / 12 / 84**. Scope flag vẫn BLOCK. Không Rails migration/DB writes, không tắt Cloudflare preview cũ, không Git commit/push trong phiên này.

## 6. Bằng chứng và rollback

Thư mục `evidence-m2-exact-excerpts-dev16-20261029/`:
- `preflight.json` — manifest, revision pin, seed và concurrency trước GPU.
- `gpu-failure.json` — exception type `FunctionTimeoutError` và wall.
- `modal-local-run.log` — full local CLI trace.
- `modal-remote-model-download.log` — log container tải checkpoint.
- `old8-source-excerpt-forensics.json` — đối chiếu post-hoc 14/16 và offsets.
- `dev16-status.json` — trạng thái máy đọc được, xác nhận inference **NOT_EVALUATED**, DB và app state.
- `exact-span-unit-tests.log`, `prior-contract-and-review-export-tests.log`, `full-rails-tests.log`, `modal-apps-after-poc.log`.

Code và docs này là **delta** đặt sau checkpoint các giai đoạn M2 trước; không chứa DB dump, model weights, private .env hay credential. Không được dùng bundle POC thay bản sao lưu application.

## 7. Bước tiếp theo

1. Trước khi retry GPU: cache model **Qwen3-4B-Instruct-2507 đúng SHA pin** vào Modal Volume riêng; xác nhận đã tải **đủ file và hash** bằng một preflight riêng, không dùng download checkpoint ngay trong GPU function. Chỉ thử GPU sau khi cache readiness PASS để tránh trả tiền GPU trong lúc chờ download.
2. Dùng runtime GPU **read-only** mount Volume và thực thi đúng bộ development16 đã khóa, vẫn lưu raw outputs kể cả fail; nếu thay đổi prompt/source contract phải tạo phiên bản rõ ràng, không gộp kết quả hai cấu hình.
3. Sau khi có dữ liệu development thực, nhờ người khác đánh giá independent 64 claim bằng `evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`, cùng việc xây **new untouched sealed holdout** và tiêu chí chất lượng riêng VI/EN.
4. Không bật scope gate cũ hoặc claim-level tự động. Quyết định release vẫn **BLOCKED**.

**Điểm tiếp tục chính xác:** model-volume prefetch/checksum on CPU, then pinned A10 development16 rerun in an *isolated*, capped new execution; do not claim quality based on failed run. Independent human64 remains PENDING.
