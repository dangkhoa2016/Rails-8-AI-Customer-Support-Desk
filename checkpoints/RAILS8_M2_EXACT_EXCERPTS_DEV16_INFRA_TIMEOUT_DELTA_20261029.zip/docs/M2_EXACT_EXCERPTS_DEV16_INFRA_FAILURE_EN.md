# M2 — Deterministic Exact-Excerpt Recovery: Development 16 (EN)

**Date:** October 29, 2026 (Asia/Ho_Chi_Minh)  
**Status:** `OFFLINE_IMPLEMENTATION_TESTED / GPU_DEV16_INFRASTRUCTURE_TIMEOUT / MODEL_QUALITY_NOT_EVALUATED / NOT_RELEASE`.

## 1. Baseline and preservation constraints

Rails 8 AI Customer Support Desk retains synthetic tenants TeamFlow Cloud and NovaMart Store, approved M0 policy v1.0.0, and the baseline PostgreSQL counts **100 articles / 212 versions / 12 approved / 84 embeddings**. The previously deployed pinned **Qwen3-Embedding-4B** and **Qwen3-Reranker-4B** Modal apps are unchanged. The Cloudflare private preview remains relevance-only, with optional M2 scope gate blocked (`KnowledgeScopePreviewGate.eligible? == false`) after sealed80 failed. All AI outputs remain human-assist-only and are prohibited from autonomous customer replies or business writes.

The prior isolated GPU POC ran `Qwen/Qwen3-4B-Instruct-2507` at immutable revision `cdbee75f17c01a7cc42f958dc650907174af0554` on A10 and produced 7/8 parseable JSON objects but **0/8 exact excerpt/offset contract passes**. The separate mDeBERTa NLI POC matched 9/12 developer labels. These are research findings, not production certification.

## 2. Post-hoc forensics of the prior eight Qwen outputs

A read-only review of the 16 source excerpts in seven parsed model outputs found:
- **14/16** excerpt strings existed as **unique verbatim substrings** of their original questions.
- **0/14** had model-proposed start offsets matching Python's deterministic offset recovery.
- Two excerpts did not satisfy exact unique source matching.

Evidence: `evidence-m2-exact-excerpts-dev16-20261029/old8-source-excerpt-forensics.json`, SHA256 `4da563c146afa5d6b3c0f0acd4fbcd7d9ad9c3684a781f62e0de410dbfb0d3ec`.

This is **post-hoc analysis on already-open examples, not an additional test or holdout**. It motivates delegating **selection of an exact excerpt** to the model while leaving **Unicode span calculation and integrity checks** to deterministic host code. It does not establish semantic completeness, intent separation, negation preservation or policy entailment.

## 3. New deterministic span resolver

Implementation: `script/m2_deterministic_exact_spans.py`.

- Model-generated JSON may contain only `claims` and `unresolved`. Claims must provide `id`, verbatim contiguous `excerpt`, `intent`, and boolean `needs_case_data`. Model-provided offsets or generated hypotheses are **not accepted**.
- Python computes unique locations by exact Unicode substring search. The resolver fails closed for absent, duplicated/ambiguous, overlapping or excessively large excerpts; unexpected keys, invalid IDs, unsafe tenant/locale, privacy-like input or missing letter/digit source coverage.
- Each original letter or digit must be attributed to one claim or explicitly unresolved span; missing content rejects the entire model output. It does not silently normalize, fuzzy-match or repair text after inference.
- A passing result explicitly declares `source_integrity_verified: true`, **`semantic_fidelity_verified: false`**, `business_actions_authorized: false`, and `human_review_required: true`.

**Critical distinction:** Source-character coverage does not prove that the model selected the correct number of independent intents; it could cover two requests with one overly broad span. The resolver also does not establish that retrieved policies entail the selected request. No Rails controller/preview integration was added.

## 4. Frozen new development set

`review/m2_exact_excerpt_development16_20261029.json` — SHA256 `380de3f24ddc765cb7e3545b2d03dd8f66535918c79fd85614bcddedcfac5f11`.

Sixteen new synthetic composite questions: four for each TeamFlow VI, TeamFlow EN, NovaMart VI and NovaMart EN group. Developer-authored minimum expected independent intents: two per question. Cases include entitlement mismatches, billing/refund boundaries, unauthorized promised deadlines, split shipments, returns and prompt-injection-like user text. No real customer or PII context.

This is a **development set, NOT a sealed untouched holdout** and has no independent human gold annotations.

New one-shot Modal app `rails8-support-desk-m2-exact-excerpts-dev16-onetime` in `modal_app/m2_exact_excerpts_dev16_poc.py`: pinned A10 Qwen model, seed **20261029**, maximum one container, one expected invocation, **480-second GPU function timeout**, plus bounded Colab CLI timeout; no HTTP/public endpoint.

`script/evaluate_m2_exact_excerpts_dev16.py` is ready to check 16 GPU outputs for JSON parsing, exact source integrity, minimum intent count, unresolved coverage and tenant/locale breakdown. `script/render_m2_exact_excerpts_dev16.py` is ready to create an offline HTML audit preserving all raw rejections.

## 5. Observed execution and tests

| Check | Actual result |
|---|---|
| Exact-span resolver offline unit suite | **15 / 15 PASS** |
| Existing future-model contracts | **10 / 10 PASS** |
| Independent-review-export validator tests | **5 / 5 PASS** |
| Full Rails regression | **78 tests / 4,424 assertions / 0 failures, errors, skips** |
| New dev16 synthetic questions, balanced strata and frozen manifest | **PASS** |
| Qwen GPU generation for 16 cases | **NOT EVALUATED — timed out before outputs** |
| 16-case model quality / accepted percentage | **NO VALID MEASUREMENT** |

The remote one-shot Modal job raised **`FunctionTimeoutError` at 480 seconds**; locally observed function wall was **483.891 seconds**. Remote logs reached `Fetching 3 files: 67%` (2 of 3 checkpoint shards) and did **not show checkpoint-load completion or model generation** before expiry. This is observed infrastructure failure; the exact underlying root cause (HF network, caching, I/O, runtime) has **not** been independently established.

The job generated **no** `exact-excerpt-live.json`, thus **zero scored cases** and no asserted 0% model accuracy. We did not retry automatically, change the manifest or fit thresholds. The ephemeral app has **stopped**; the two existing production-like Qwen4B Modal apps remain **deployed**.

Post-run DB counts are unchanged at **100 / 212 / 12 / 84**. The scope feature remains blocked, and no Rails migration, approval change, business write, customer-facing feature, or Git commit/push occurred.

## 6. Provenance, evidence and rollback

Directory: `evidence-m2-exact-excerpts-dev16-20261029/`.

- `preflight.json` — pre-inference manifest hash, model revision, seed, one GPU instance.
- `gpu-failure.json` — actual `FunctionTimeoutError` and elapsed duration.
- `modal-local-run.log` — CLI exception trace and execution records.
- `modal-remote-model-download.log` — remote checkpoint download progress.
- `old8-source-excerpt-forensics.json` — post-hoc 14/16 exact quote finding and incorrect model offsets.
- `dev16-status.json` — machine-readable NOT_EVALUATED status, DB baseline, app lifecycle.
- `exact-span-unit-tests.log`, `prior-contract-and-review-export-tests.log`, `full-rails-tests.log`, `modal-apps-after-poc.log`.

This is an additive delta on top of prior M2 checkpoints, not an application or DB backup. It excludes model weights, tokens, secrets, private environment files and DB dumps.

## 7. Next execution gate

1. **Before another GPU run**, prefetch the exact pinned `Qwen3-4B-Instruct-2507` revision to a **separate Modal Volume** using a bounded non-GPU download/verification job. Verify all shards and file hashes, mark the cache complete only on success, and do not charge an A10 while the model downloads.
2. Mount the verified cache read-only in a subsequent isolated capped A10 job. Retry the frozen dev16 only under explicit versioned execution provenance; preserve this timed-out attempt separately and never overwrite failure evidence.
3. Obtain real, independent adjudication for the existing 64-claim worksheet (`evidence-m2-claim64-provisional-audit-20261029/independent-reviewer-workbook.html`). New, untouched holdout cases and human approval are required before considering any staff-facing integration.
4. Keep the old scope feature blocked and do not allow automatic customer responses or business writes.

**Exact continuation point:** verified non-GPU pinned model cache preflight, followed by isolated A10 dev16; external human64 signoff remains pending. GPU quality is **NOT_EVALUATED**, not failed or passed.
