# M3 — Rails/PostgreSQL Runtime Acceptance and Private HTTPS Demo

Date: 2026-10-29 (Asia/Ho_Chi_Minh). Colab host: `d912002e2a9f`; Desktop Commander device `d2536713-6975-49cb-8955-969067f3726f`.

## Preserved authority

- The 20 M0 synthetic policies v1.0.0, 12 previously approved KB v2 versions, and 64/64 `APPROVED_FOR_SYNTHETIC_DEMO` claims remain unchanged. Two independent reviewers are **not required for synthetic sample display**; no new independent semantic gold or fake signatures were created.
- `KnowledgeScopePreviewGate.eligible? == false`; sealed80 remains BLOCKED (3 false positives, supported recall 0.70). AI remains assist-only; no autonomous customer replies or business writes.
- The other 88 KB draft articles were not promoted to approved.

## Fresh synthetic database recovery

- Ruby 3.3.13, Rails 8.0.5.1, PostgreSQL 16.15, pgvector 0.6.0. Neither application database existed before recovery. Created isolated fresh development/test DBs without `db:drop` or `db:reset`.
- Restored M1 once from deterministic source SHA256 `6a266e42c0099c18d8560ed88e835f8873b62c35811dac28e350667ce3d68680`; read-only M1 verifier PASS with 100 customers, 80 TeamFlow invoices and 120 NovaMart orders.
- Restored only the previously approved M2 content: 100 KB articles, 212 versions, 1,484 chunks and 12 approved v2 versions. All twelve bodies matched frozen approved snapshot SHA256 `12cb87609c5de1c082e692648e55615785b31f5faf84c280bfaaa1fd0a15695f`. This reconstitutes historical demo-owner approval in the fresh DB, **not a new independent content review**.
- **The 84 historical embeddings were not restored.** The fresh database has 0 vectors; no repeat GPU benchmark/inference was run. The previous Modal app deployment does not establish current end-to-end AI Search readiness.
- The old M2 verifier expects exactly 200 baseline versions and therefore fails on the later 212-version state; a separate frozen v2 snapshot validator PASS was used without changing historical verifier code.

## M3 PostgreSQL results

- Dataset seed `20261029`, SHA256 `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd`.
- First successful guarded transactional import: **240 tickets, 440 messages, 240 synthetic seed audit events**. Earlier autoload failures were fail-closed (0 tickets added); failure evidence preserved.
- Second import: **zero new tickets/messages/audits**, 240 tickets + 440 messages matched — idempotence PASS.
- Each tenant has 120 tickets, 60 VI + 60 EN; every lifecycle status has 20 tickets per tenant. Offline and runtime tenancy/chronology checks PASS.

## Rails and HTTP acceptance

- **84 Rails tests, 4,480 assertions, zero failures/errors/skips**, including 6 M3 integration tests. Offline Python regression tests 10/10 PASS.
- Rails is bound to `127.0.0.1:3068` behind a private password-form gate and signed session cookie. An ephemeral Cloudflare Quick Tunnel admits only its exact active hostname.
- Both local and external HTTPS smoke verified authentic TeamFlow/NovaMart demo account sessions, ticket index HTTP 200, ten filtered VI/open tickets, detail HTTP 200, and no cross-tenant tickets.
- External unauthenticated tickets redirect 303; login form 200; POST ticket creation and KB approval return 405; wrong hostname returns 403. The private public preview is read-only for business changes.
- No passwords, cookies, Modal credentials or ephemeral Quick Tunnel URLs are in tracked source/evidence. The Colab owner can read the local private password from `/root/.config/rails8-support-desk-modal/rails-private-preview.env` (0600).

## Backups

- Pre-M3 private development DB dump at `/tmp/rails8-support-desk-before-m3-20261029.dump`, SHA `e89b629394ddf684c46b7d5e9d8fc8bf2e932163c1c9dc2a5356a29d563ceb5d`.
- Post-M3 dump at `/tmp/RAILS8_M3_SYNTHETIC_POSTGRESQL_DEMO_20261029.dump`, 310,667 bytes; SHA256 `8a85bfc16d27fc4cd0fc50d07c1c693c43707ed1a3fd9da743142f6edbb1a4fc`.
- Modal profile `bsmith888`, environment `rails-8-ai-customer-support-desk`, Evidence Volume `rails8-support-desk-evidence`; private dump and checksum under `20261029/m3-postgresql-live-private/`. Download-back byte equality and `pg_restore --list` verified PASS. Never restore into an unknown live database without preflight.
- New runtime source/evidence checkpoint is additive and does not overwrite the historical M3 offline ZIP.

## Remaining work

Restore the frozen 84 M2 embeddings and private Modal proxy credentials if relevant, then repeat relevance-only search acceptance; never bypass the sealed80 answerability gate. Add a separate 120-case evaluation dataset, improve ticket language diversity, and address production RBAC/privacy/monitoring/queues/rate limits/cost. Recheck DB state after any Colab reboot. No Git commit/push was performed.

Vietnamese companion: `docs/M3_POSTGRESQL_RAILS_LIVE_ACCEPTANCE_VI.md`.
