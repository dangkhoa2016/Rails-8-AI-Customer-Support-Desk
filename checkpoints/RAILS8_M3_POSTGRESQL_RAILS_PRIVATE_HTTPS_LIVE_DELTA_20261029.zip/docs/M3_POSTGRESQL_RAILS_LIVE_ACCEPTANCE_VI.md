# M3 — Nghiệm thu Rails/PostgreSQL runtime và private HTTPS demo

Ngày: 2026-10-29 (Asia/Ho_Chi_Minh). Thiết bị Colab: `d912002e2a9f`; Desktop Commander `d2536713-6975-49cb-8955-969067f3726f`.

## Quyền hạn và quyết định giữ nguyên

- 20 synthetic policies v1.0.0 M0, 12 KB versions v2 đã duyệt và 64/64 claims `APPROVED_FOR_SYNTHETIC_DEMO` giữ nguyên. Không yêu cầu hai reviewer độc lập để hiển thị dữ liệu mẫu, không tự tạo semantic gold hoặc chữ ký giả.
- `KnowledgeScopePreviewGate.eligible? == false`, sealed80 BLOCKED (3 FP, supported recall 0.70). AI assist-only, không tự viết nghiệp vụ hoặc gửi câu trả lời đến khách.
- Bộ 88 KB draft khác không được tự động promote.

## Khôi phục môi trường mới và dữ liệu synthetic

- Ruby 3.3.13, Rails 8.0.5.1, PostgreSQL 16.15, pgvector 0.6.0; DB development/test ban đầu **không tồn tại**. Đã tạo database mới, không dùng `db:drop` hoặc `db:reset`.
- Nạp M1 một lần từ file deterministic với SHA `6a266e42c0099c18d8560ed88e835f8873b62c35811dac28e350667ce3d68680`. M1 read-only verifier PASS: 100 customers, 80 TeamFlow invoices, 120 NovaMart orders.
- Phục hồi M2 từ nguồn đã khóa, không tạo nội dung KB mới: 100 articles / 212 versions / 1.484 chunks / 12 approved v2. Tất cả 12 nội dung v2 khớp chính xác snapshot `12cb87609c5de1c082e692648e55615785b31f5faf84c280bfaaa1fd0a15695f`. Đây là **phục hồi quyết định owner approval cũ** trong DB development mới, không phải độc lập phê duyệt lại.
- **Không phục hồi 84 vector embeddings** của DB cũ; database mới có 0 vectors. Không chạy lại GPU; embedding/reranker còn deployed trên Modal nhưng chưa có M2 AI Search live acceptance mới.
- Legacy M2 verifier chỉ chấp nhận baseline 200 versions, do đó FAIL khi có 12 v2. Bộ kiểm snapshot-v2 riêng PASS; giữ nguyên verifier lịch sử.

## M3 PostgreSQL

- Dataset seed `20261029`, SHA256 `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd`.
- Import lần đầu: **240 tickets + 440 messages + 240 synthetic seed audit events**, transaction thành công. Hai lỗi autoload trước đó đã fail-closed với 0 ticket ghi; giữ logs lỗi.
- Import lần hai: **0 tickets / 0 messages / 0 audits mới**, 240 tickets và 440 messages đối chiếu khớp — idempotence PASS.
- Mỗi tenant 120 tickets, 60 VI + 60 EN; mỗi status 20; lọc tenant/cross-customer và chronology được kiểm tra offline và runtime.

## Rails / HTTP nghiệm thu

- **84 Rails tests / 4.480 assertions / 0 failures, 0 errors, 0 skips**. Trong đó có 6 M3 integration tests. Python offline suite 10/10 PASS.
- Rails chạy loopback `127.0.0.1:3068`, private preview password + HMAC cookie; Cloudflare Quick Tunnel **tạm thời**, chỉ exact hostname của phiên hiện tại.
- Local HTTP và HTTPS qua tunnel: TeamFlow/NovaMart đều đăng nhập thành công, ticket index 200, filtered open+VI đúng 10 tickets, detail 200, không lộ cross-tenant.
- External HTTPS: login page 200; chưa xác thực sang tickets 303; POST tạo ticket và POST duyệt KB = 405; host không hợp lệ = 403. Tunnel cho phép xem/tìm kiếm theo gate nhưng **không cho business mutations**.
- Không lưu password, session cookie, Modal token, hoặc URL Cloudflare tạm trong Git/checkpoint. Chủ Colab có thể tự xem mật khẩu tại `/root/.config/rails8-support-desk-modal/rails-private-preview.env` (mode 0600).

## Backup

- Trước M3: private `/tmp/rails8-support-desk-before-m3-20261029.dump`, SHA `e89b629394ddf684c46b7d5e9d8fc8bf2e932163c1c9dc2a5356a29d563ceb5d`.
- Sau M3: private `/tmp/RAILS8_M3_SYNTHETIC_POSTGRESQL_DEMO_20261029.dump`, 310.667 bytes; SHA `8a85bfc16d27fc4cd0fc50d07c1c693c43707ed1a3fd9da743142f6edbb1a4fc`.
- Modal profile `bsmith888`, env `rails-8-ai-customer-support-desk`, volume `rails8-support-desk-evidence`. Private DB dump + checksum ở `20261029/m3-postgresql-live-private/`. Tải ngược byte-identical + `pg_restore --list` PASS. Không dùng dump cũ để ghi đè DB đang hoạt động.
- Checkpoint mã/evidence runtime bổ sung độc lập, không overwrite checkpoint M3 offline trước đó.

## Những việc còn lại

- M2 embedding restore / Modal proxy configuration, live relevance-only GPU test; sealed80 và answerability vẫn BLOCKED.
- 120 evaluation cases độc lập, cải thiện tính tự nhiên/đa dạng ticket, production RBAC/auth/PII/monitoring/queues/rate limit/cost.
- Nếu reboot: cần kiểm tra lại trạng thái trước khi khôi phục; không chạy unguarded seed. Private tunnel URL luôn thay đổi.
- Không commit/push Git trong lượt này.

Tài liệu tương ứng: `docs/M3_POSTGRESQL_RAILS_LIVE_ACCEPTANCE_EN.md`.
