# Rails 8 AI Customer Support Desk

**Current checkpoint (2026-10-29): Rails 8 and PostgreSQL runtime acceptance completed on synthetic Colab development/test databases. M0/M1 were not rebuilt. M2 has 12 editorially approved bilingual v2 versions, 84 approved chunks, and a source-validated Qwen3-Embedding-4B + Qwen3-Reranker-4B integration. Modal GPU inference and actual embeddings remain NOT_RUN.**

## Included in this stage

- One Rails 8 app with PostgreSQL and server-rendered ERB views, separate EN/VI localizations, and no frontend build tooling.
- Two synthetic tenants: `TeamFlow Cloud` (`b2b_saas`) and `NovaMart Store` (`ecommerce`).
- **Development/test-only** passwordless synthetic account selector. Membership-verified session selects a tenant; neither model output nor request parameters can override it. This is **not production authentication**.
- Tenant-scoped dashboard, customers, TeamFlow invoices, NovaMart orders and partial shipments, with read-only authorized lookups.
- Manual ticket intake, conversation history, internal notes, explicit agent-approved public replies, audit records, idempotency, constrained state transitions.
- Seven Rails migrations (original M1/M2 plus two embedding schema migrations), imported M1 business/core models, deterministic M1 business records and relational fixtures, seed importer, validation scripts and regression tests.

**Not yet delivered/accepted:** Actual Modal 4B/4B GPU execution, 84 real embedding vectors, bilingual semantic/rerank benchmarks, full editorial coverage, 240 M3 synthetic tickets, 120 final evaluation cases, production authentication, email delivery, or AI answer generation. Real PostgreSQL lexical baseline over 12 curated questions is 0/12 at Recall@8; this is not a model benchmark.

## Run with existing Ruby 3.3+ and PostgreSQL

```bash
cd Rails-8-AI-Customer-Support-Desk
bundle install
# Configure a disposable local PostgreSQL demo role/database through PGHOST/PGUSER/PGPASSWORD/PGDATABASE.
export RAILS_ENV=development M1_SYNTHETIC_DEMO=YES
bin/rails db:create db:migrate
bin/rails runner db/seeds/m1_full_business_records.rb
bin/rails runner script/verify_m1_database.rb
bin/rails server -b 127.0.0.1 -p 3000
```

Visit `http://127.0.0.1:3000/demo/sign_in`, select a synthetic TeamFlow/NovaMart agent, and inspect the workflows. Sessions and records are separated by tenant. **Do not use the demo login or synthetic database on a public production site.**

## Full acceptance on Kaggle/Colab

With notebook Internet enabled, extract the app and run as the notebook root user:

```bash
bash script/notebook_setup.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bin/rails server -b 127.0.0.1 -p 3000
```

The notebook setup installs runtime dependencies, uses mise to install Ruby 3.3 and creates a locally stored `.env.notebook` for a disposable PostgreSQL account. The full acceptance script collects commands, UTC timestamps, stdout/stderr, exit codes and SHA256 in `evidence-run/`. It contains no `db:drop` or `db:reset` and refuses non-development mode. **Do not expose the passwordless demo through a public Quick Tunnel.** Only consider public exposure after proper authentication/authorization hardening.

Alternative local Docker setup (not run in this workspace): `docker compose up --build`. The fixed Compose database password is for isolated localhost development only.

## Provenance and limitations

- Canonical M0-approved policy is `docs/RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json`, version `1.0.0`.
- The synthetic M1 dataset lives in `data/m1_business_records.json`; seed `20261028`, reference time `2026-10-28T00:00:00+07:00`.
- Evidence-backed read-only lookups and database-level composite FKs are intended to prevent tenant leakage, pending runtime tests.
- Public replies are stored after an explicit human approval action. There is **no actual external email or Modal AI endpoint**.
- Original M0 documents, policy approval logs and immutable source snapshot are available under `docs/`.

**`PASS_SOURCE_ONLY` and `PASS_OFFLINE_ONLY` must never be represented as PostgreSQL or AI acceptance.**

## M2 — Bilingual Knowledge Base (added 2026-10-28)

The historical M2 baseline contained 100 bilingual articles / 200 v1 drafts / 1,400 chunks. As of October 29, 2026, **12 reviewed v2 versions have been approved by delegated synthetic demo owners**, producing **212 versions and 1,484 chunks** overall; exactly **84 chunks are approved/active**. PostgreSQL pgvector is installed with native `vector(2560)` storage and security regression tests PASS. Modal Qwen3-Embedding-4B and Qwen3-Reranker-4B service sources are prepared but are not deployed and have not produced real embeddings.

- Current dual-4B setup and state: `docs/M2_DUAL_QWEN3_4B_IMPLEMENTATION_EN.md`
- M2 implementation and acceptance: `docs/M2_IMPLEMENTATION_GUIDE_EN.md`
- Standalone editorial preview: `preview/m2_knowledge/index.html`
- Deterministic full-text data: `data/m2/knowledge_drafts.json`
- Kaggle/Colab after M1: `bash script/run_full_m2.sh`

Previous offline evidence does not constitute AI acceptance. Runtime PostgreSQL acceptance is recorded separately; do not rerun M1/M2 importers unnecessarily on the currently approved database.

### PostgreSQL authentication repair on Kaggle/Colab

If setup reports `FATAL: password authentication failed for user "support_desk"`, the old setup inherited application PostgreSQL variables while running admin commands. Do not reset or drop the database, and do not reinstall Ruby/gems. From the application root run:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

The repair uses a clean Unix-socket `postgres` admin connection, sets the local demo role password without logging it, then verifies TCP authentication as `support_desk`. Intended only for disposable synthetic Kaggle/Colab notebooks; never for production or real databases.
