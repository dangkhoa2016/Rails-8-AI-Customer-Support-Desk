# M2 — Qwen3 4B Embedding + Reranker (VI)

**Checkpoint:** 2026-10-29 · Dự án Rails 8 AI Customer Support Desk.

## Trạng thái được kiểm chứng

- M0 v1.0.0 và M1 giữ nguyên.
- Người dùng xác nhận nội dung 12 bản VI/EN v2 trong preview. Đã thực hiện approval được ủy quyền bằng demo owner đúng tenant, qua `KnowledgePublication.approve!` và 12 audit events. Audit ghi `approval_origin=user_chat_confirmation_2026_10_29`, `audit_actor_kind=synthetic_demo_tenant_owner`: không mạo nhận người dùng đăng nhập trực tiếp.
- PostgreSQL development: 100 articles, 200 v1 drafts, 12 v2 approved; 84 chunks của các bản approved (TeamFlow 28, NovaMart 56). Không có embedding thực.
- Đã chạy migration mới `20261029020000_use_qwen3_embedding_4b_native_dimensions.rb`, chuyển embedding sang `vector(2560)`, development/test đều PASS. Migration từ chối thay chiều nếu đã có embeddings. Giữ migration v1 trong lịch sử.
- Tests Rails dùng vector và điểm rerank GIẢ LẬP, không phải kết quả AI. Static import Modal SDK PASS, inference GPU/latency/chi phí thật vẫn `NOT_RUN`.

## Bộ đôi model được chọn

| Bước | Repo chính thức | Revision pin | Cấu hình |
|---|---|---|---|
| Embed | `Qwen/Qwen3-Embedding-4B` | `5cf2132abc99cad020ac570b19d031efec650f2b` | 2560 chiều, cosine exact, A10, max 2K tokens |
| Rerank | `Qwen/Qwen3-Reranker-4B` | `22e683669bc0f0bd69640a1354a6d0aebcfeede5` | CrossEncoder raw logits, A10 riêng, max 2K tokens |

Hai revision kiểm tra bằng `git ls-remote` ngày 2026-10-29; chưa có runtime download SHA evidence. Không dùng model 0.6B nữa. Mặc dù Qwen hỗ trợ 32K context, hiện pilot giới hạn 2048 tokens để hạn chế VRAM; không tuyên bố benchmark context tối đa. Chưa bật HNSW vì vector 2560 vượt giới hạn index kiểu vector HNSW thông thường; exact là baseline.

## Mô hình dữ liệu và security

1. `KnowledgeEmbeddingIngestion` chỉ gửi chunks đã approved/còn hiệu lực/đúng tenant và SHA256 khớp tới embedding service.
2. `KnowledgeSemanticRetrieval` lọc tenant, audience/role, VI/EN, policy version, hiệu lực và source digest trong SQL **trước** khi đưa candidates sang reranker.
3. `KnowledgeRerankedRetrieval` gửi tối đa 12 đoạn đã lọc đến reranker, điểm raw logit cao hơn đứng trước; citation và cosine score được giữ lại. Truy vấn cần `query_privacy_reviewed: true`, không gửi ticket/customer PII ra ngoài.
4. Modal endpoint chỉ nhận request có bearer secret, kiểm tra input SHA256, trả về model revision và score type. Không bật AI business writes.
5. Dữ liệu KB đã approved mới có quyền retrieval; 200 v1 drafts không được gửi đến model.

## Chuẩn bị và triển khai Modal (chưa deploy)

**Cần người dùng đăng nhập Modal trên máy đang chạy Desktop Commander**, ví dụ `modal token new` với SDK từ `/tmp/rails8-modal-check-uv/bin/modal`. Không chia sẻ token vào chat hoặc đưa token vào git. Tạo Modal Secret `rails8-support-desk-ai` trong dashboard với `EMBED_API_TOKEN` và `RERANK_API_TOKEN` (hai chuỗi ngẫu nhiên dài trên 20 ký tự). Hai token dùng cho endpoint bảo vệ ở mức ứng dụng.

Sau khi xác thực, deploy từng dịch vụ:

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
/tmp/rails8-modal-check-uv/bin/modal deploy modal_app/qwen3_embedding_service.py
/tmp/rails8-modal-check-uv/bin/modal deploy modal_app/qwen3_reranker_service.py
```

Lấy **URL chính xác từ kết quả deploy**, không tự đoán địa chỉ. Cấu hình riêng trong môi trường Rails không được commit: `MODAL_EMBEDDING_URL`, `MODAL_EMBEDDING_TOKEN`, `MODAL_RERANK_URL`, `MODAL_RERANK_TOKEN`.

**Chạy dry-run không cần Modal:**
```bash
set -a; source .env.notebook; set +a
bin/rails runner script/m2_dual_4b_pilot.rb
```

**Chạy thật sau khi Modal có auth/secret:**
```bash
M2_GPU_RUN=YES bin/rails runner script/m2_dual_4b_pilot.rb
```

Script sẽ xử lý tối đa 8 chunks mỗi lô, chỉ 84 chunks đã duyệt, sau đó benchmark 12 câu VI/EN. Evidence chỉ ghi case ID, hash câu hỏi, latency, citations, Recall@5/MRR@5; không cần xuất nội dung khách. Không chạy lệnh live khi chưa có tài khoản và dự toán chi phí GPU.

## Baseline và acceptance

- Real PostgreSQL lexical baseline trên 12 câu hỏi: Recall@8 = **0/12**, MRR@8=0. Đây chỉ là tập 12 câu hỏi, chưa có ý nghĩa thống kê rộng.
- Chưa có Recall/MRR của embedding 4B và reranker 4B; các test vector giả không thay thế benchmark GPU.
- Chỉ hoàn thành M2 AI pilot khi có: inference GPU thật, 84 vectors 2560 chiều, ingestion idempotency, ranking VI/EN, tenant/ACL/draft gates PASS, revision/cost/timing evidence.
- Pricing tham khảo trên Modal ngày 2026-10-29: GPU A10 khoảng 0.000306 USD/giây cho **mỗi** GPU đang chạy; chưa bao gồm CPU/RAM/lưu trữ và startup. Hai dịch vụ được cấu hình scale-to-zero, max một container mỗi dịch vụ.

## Files

`modal_app/qwen3_embedding_service.py`, `modal_app/qwen3_reranker_service.py`, `app/services/modal_reranker_client.rb`, `app/services/knowledge_reranked_retrieval.rb`, `script/m2_dual_4b_pilot.rb`, `script/m2_lexical_baseline.rb`, `review/m2_dual_qwen3_4b_pilot_queries.json`.

**Quan trọng:** Colab hiện chưa xác thực Modal (token info exit 1). Không tuyên bố triển khai service hoặc tạo vector trên Modal.
