# M2 — Default synthetic sample acceptance for demo (EN)

**Owner decision, October 29, 2026:** The two modeled businesses and their examples are **synthetic sample data**. All 64 atomic claims in the current evaluation queue are **accepted by default for sample presentation and exploration**; two independent human reviewer sign-offs are no longer required to display these synthetic examples.

**Acceptance label:** `APPROVED_FOR_SYNTHETIC_DEMO`. This is **approval to use sample content**, NOT proof that any factual assertion or model-generated answer is correct.

## Scope

- 64/64 synthetic question/claim records, spanning TeamFlow Cloud and NovaMart Store in EN and VI (16 each of four strata), are accepted as demonstration content.
- The existing 12/12 approved KB v2 articles in the retrieval research subset remain the approved synthetic knowledge sources.
- Other synthetic seed records can be displayed as sample data. This decision does **not** silently convert the other 88 KB draft articles into **approved retrieval KB versions**. That requires a separate authorized content workflow, tenant and locale checks, and embeddings.
- The policies are fictional examples. No real-world validity, accuracy, legal correctness, or applicability to any real company is implied.

The manifest is `review/m2_claim64_synthetic_demo_approval_20261029.json`. It records every claim ID and unchanged text, tenant and locale, sample-only acceptance and SHA256 of the frozen original claim queue and approved KB snapshot. Neither the frozen review queue nor PostgreSQL records, KB approved statuses, historic GPU outputs or previous acceptance files are modified.

## Claims that are explicitly NOT made

- Accepting all 64 sample *questions* does **not** mean all are affirmative or safely answerable. A question about automatically refunding may need an explicit policy-negative response instead.
- `human_semantic_review=NOT_PERFORMED`; no counterfeit human reviewer judgments, gold labels or signatures are created.
- `policy_answerability=UNKNOWN_NOT_APPROVED`; sample acceptance does not certify policy entailment or customer-case details.
- `KnowledgeScopePreviewGate.eligible? == false` still holds after unsafe false positives in sealed80. Do not treat a demo-only acceptance manifest as an override.
- AI remains assist-only, with human-approved business actions. No autonomous refund, billing, entitlement, shipping, customer updates or unverified service promises.
- No production-readiness, real-world policy verification, or sealed accuracy benchmark is claimed.

## Demo presentation

Two new read-only HTML pages:
- `evidence-m2-claim64-independent-review-v2-20261029/sample-approval.vi.html`
- `evidence-m2-claim64-independent-review-v2-20261029/sample-approval.en.html`

Each displays 64/64 accepted synthetic claims and the existing 12/12 approved KB v2 sources, with tenant and language filters. The older optional human review workbooks remain available via `index.vi.html` and `index.en.html`; they are no longer prerequisites for sample presentation.

The password-protected Cloudflare private preview home page `/` now routes to the Vietnamese sample overview. Both sample pages are accessible only through their explicit allowlist paths; the tunnel URL is temporary.

## Code and verification

The additive source manifest and pages were generated with:

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
python3 script/build_m2_synthetic_sample_approval.py
python3 test/test_m2_synthetic_sample_approval.py
NODE_PATH=/mnt/workspace/.npm-cache/_npx/4b4c857f6efdfb61/node_modules node test/smoke_m2_synthetic_sample_approval.cjs
```

The manifest was generated once from frozen inputs and will not be overwritten by the generator. The contract passed **11/11 unit tests**. Chromium headless validated both locales, all 64 items and 12 KB sources, tenant/locale filters and zero external requests.

The two existing deployed Modal embedding/reranker apps and their data are unchanged; no new model inference, Git commit or push was performed. All historic evidence and provenance remain available.

## Updated project continuation

**Independent double-human annotation is no longer a blocker for a synthetic demonstration.** It is still needed for claims of independently validated answer accuracy or production answerability. Development can continue with the safe Rails relevance-only demo, synthetic M3 ticket generation, and UX while the existing unsafe answerability scope remains fail-closed.
