# M2 — Independent human review workflow for 64 claims (EN)

**Owner decision update, October 29, 2026:** All 64 synthetic claims are `APPROVED_FOR_SYNTHETIC_DEMO`; independent dual-human review is no longer required to display sample data. The procedure below remains optional for semantic verification or production claims. See `docs/M2_SYNTHETIC_SAMPLE_DEFAULT_APPROVAL_EN.md`. AI answerability remains BLOCKED.

**Historical status:** REVIEW_WORKBOOK_READY / HUMAN_ADJUDICATION_NOT_RUN / NOT_RELEASE.

## 1. Sources and scope

Rails 8 AI Customer Support Desk models two synthetic businesses, TeamFlow Cloud and NovaMart Store. M0's 20 business policies at version 1.0.0 remain approved. The frozen reviewer inputs consist of 64 atomic claims from 32 composite questions and 12 approved v2 KB articles. Each KB item is bound to a tenant, locale, approved article version and exact body SHA256. No source data, previous approval, or blocked M2 scope gate is modified.

The previous partition-aware GPU experiment established only structural validity on a development corpus. It did NOT establish correct policy entailment, negation preservation, semantic answerability or production accuracy. AI is forbidden to make business writes, promise outcomes, approve refunds, activate plans, ship replacements or send autonomous customer replies.

## 2. Separate Vietnamese and English workbooks

Within evidence-m2-claim64-independent-review-v2-20261029:
- index.vi.html
- index.en.html

The generator is script/render_m2_independent_review_v2.py. The frozen input queue is evidence-m2-claim32x2-20261029/claim-level-blind-human-validation.json. Approved source evidence is evidence-m2-claim64-provisional-audit-20261029/approved-kb-v2-readonly-snapshot.json.

Each version presents all 64 claims, their composite question, and the 12 approved KB articles. The user interface languages are separate; each claim retains its original source locale. Neither workbook includes developer gold, AI predictions, post-hoc assistant labels or another reviewer's decisions. Reviewers can filter, read approved KB excerpts, record exact citations and rationale, export and re-import local draft JSON, and export a completed self-attested JSON only when valid.

**There is no autosave.** No browser storage, external requests, AI inference, backend uploads or customer records are used. The user must export local drafts before closing or restarting. Import validates all three frozen source hashes, unique 64 IDs and exact tenant/locale mapping before restoring entries.

## 3. Reviewer decision rules

- affirmative_policy: the approved policy supports an affirmative or conditional answer. Cite an approved article within the same tenant and language and quote at least 20 exact characters.
- explicit_negative_policy: an approved article expressly supports a negative answer. Do not confuse it with undocumented or absent evidence. Exact citation is required.
- not_documented: the approved KB does not support a safe policy answer. Do not claim a supporting approved article; write at least 20 characters explaining what was checked.
- uncertain_needs_second_reviewer: human arbitration is needed. Explain uncertainty in at least 20 characters; it cannot count as completed final review.

The UI enables COMPLETE_SELF_ATTESTED_UNVERIFIED only if 64/64 decisions are locally valid, no unresolved decisions remain, a reviewer ID is present and the reviewer checks the self-attestation box. This status does not verify a real person's identity, independence or release authority.

## 4. Two independent human reviewers

Reviewer A and B work separately and should not share decisions until both have completed their own signed-off exports. Keep their original JSON files separate. After real reviewer files are collected:

    python3 script/validate_m2_external_review_export.py /path/reviewer-a.json
    python3 script/validate_m2_external_review_export.py /path/reviewer-b.json
    python3 script/compare_m2_dual_external_reviews.py /path/reviewer-a.json /path/reviewer-b.json --output /path/dual-comparison.json

The validator checks all claims and exact approved-KB evidence. The comparison tool detects label and cited-article disagreements, reports per-tenant/per-language agreement, and provides Cohen's kappa for diagnostics only. Even complete agreement is not proof of policy correctness. Human arbitration, independent authorship verification, owner signoff and a newly untouched sealed holdout remain mandatory before any release.

Do not generate purported human reviewer exports with AI. Synthetic fixtures used by unit tests are not reviewer decisions.

## 5. Recovery after Colab restart

The new device is d912002e2a9f, device ID d2536713-6975-49cb-8955-969067f3726f. The Rails project and previously completed M2 checkpoint survived, but the prior v2 workbook files had not yet been saved into a checkpoint. Both workbooks and the dual-review comparison tool were reconstructed on the new device. Chromium headless was used to test both pages: 64 cards, 12 KB items, draft import/resume, final guard and zero external requests PASS. The dual-review comparison passed 8/8 synthetic unit tests.

Old Colab private-preview password and Modal CLI credentials were absent following the restart. Any renewed Quick Tunnel must be protected by a strong secret and a strict allowlist limited to the two static approved workbooks. Never commit ephemeral tunnel URLs, preview passwords or secrets to Git.

## 6. Exact next step

Collect two genuine independently completed reviewer JSON files; validate, compare and ask real humans to arbitrate disagreements. HUMAN_SEMANTIC_ACCEPTANCE remains NOT_RUN, and the M2 claim-level release gate remains BLOCKED. Never use repeated GPU runs as a substitute for human adjudication.
