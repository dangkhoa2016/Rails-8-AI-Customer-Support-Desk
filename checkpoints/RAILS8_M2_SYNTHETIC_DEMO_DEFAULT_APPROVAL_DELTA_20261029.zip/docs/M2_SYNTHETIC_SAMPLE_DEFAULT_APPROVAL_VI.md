# M2 — Phê duyệt mặc định dữ liệu giả lập cho demo (VI)

**Quyết định ngày 29/10/2026:** Chủ dự án chọn sử dụng dữ liệu của hai doanh nghiệp giả lập như **dữ liệu mẫu**. Tất cả 64 claim trong bộ evaluation hiện tại được **mặc định chấp nhận để sử dụng và trình bày trong demo**, không cần hai người reviewer độc lập như đối với nghiệp vụ thực tế.

**Nhãn chính thức cho dữ liệu mẫu:** `APPROVED_FOR_SYNTHETIC_DEMO`. **Đây là phê duyệt về mục đích sử dụng mẫu, không phải phê duyệt sự thật/khả năng AI trả lời.**

## Phạm vi cụ thể

- 64/64 câu hỏi/claim synthetic (4 nhóm TeamFlow Cloud × VI/EN và NovaMart Store × VI/EN, mỗi nhóm 16 claim): chấp nhận làm nội dung demo.
- 12/12 bài KB v2 đã được approved trước đó (thuộc tập nghiên cứu có embeddings): tiếp tục được phép làm nguồn tài liệu giả lập cho demo.
- Các record synthetic seed khác của dự án được sử dụng như dữ liệu giả lập. Không tự biến 88 bài KB draft khác thành **approved KB phiên bản có thể dùng cho retrieval**; muốn làm việc đó cần một tác vụ quản trị KB rõ ràng và kiểm tra tenant/locale/embedding.
- Không xác nhận các policy mô phỏng này chính xác, có hiệu lực pháp lý hoặc phản ánh bất kỳ công ty có thật nào.

Dữ liệu mới nằm tại `review/m2_claim64_synthetic_demo_approval_20261029.json`. File chứa 64 approval records có claim ID, text nguyên gốc, tenant, locale, phạm vi demo, SHA256 hàng đợi frozen và snapshot KB approved. **Không thay đổi byte nào của hàng đợi 64 claim gốc, KB snapshot, dữ liệu PostgreSQL hay log GPU đã nghiệm thu.**

## Những điều không được ngầm suy ra

- Chấp nhận 64 câu hỏi mẫu **không đồng nghĩa** cả 64 câu đều có câu trả lời khẳng định. Ví dụ câu hỏi về tự hoàn tiền có thể được đáp lại bằng chính sách từ chối.
- `human_semantic_review=NOT_PERFORMED`: không tạo reviewer IDs, chữ ký, human gold hoặc đánh giá độc lập giả.
- `policy_answerability=UNKNOWN_NOT_APPROVED`: một sample được chấp nhận không chứng minh policy đúng cho câu hỏi đó hoặc có đầy đủ case facts.
- `KnowledgeScopePreviewGate.eligible? == false`: vẫn khóa do sealed80 có unsafe false positives. Không thay `M2_ANSWERABILITY_SCOPE_ENABLE` thành cơ chế bypass.
- AI assist-only, human approval; **không tự động thực hiện refund, billing, entitlement, shipping, customer writes**. Không tự tạo customer-facing answer với lời hứa hoặc quyết định tài chính.
- Không gọi đây là production, benchmark đạt chuẩn hay chính sách ngoài đời thực được xác minh.

## Giao diện demo

Hai trang HTML mới, chỉ đọc và không gửi dữ liệu:

- `evidence-m2-claim64-independent-review-v2-20261029/sample-approval.vi.html`
- `evidence-m2-claim64-independent-review-v2-20261029/sample-approval.en.html`

Mỗi trang hiển thị 64/64 claim đã chấp nhận làm mẫu và 12/12 bài KB v2 hiện có, lọc theo tenant và locale. Các workbook `index.vi.html`/`index.en.html` trước đó vẫn tồn tại dưới vai trò **tùy chọn**, không còn là điều kiện cho demo.

Qua Cloudflare private preview, đường dẫn gốc `/` mở trang tổng quan demo tiếng Việt; các đường dẫn `/sample-approval.vi.html`/`/sample-approval.en.html` hiển thị từng ngôn ngữ. Truy cập vẫn phải có mật khẩu, không có API ghi dữ liệu. URL tunnel mang tính tạm thời.

## Mã nguồn và kiểm tra

Tạo manifest và hai trang HTML mới (chỉ làm trên bản chưa tạo; không overwrite):

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
python3 script/build_m2_synthetic_sample_approval.py
python3 test/test_m2_synthetic_sample_approval.py
NODE_PATH=/mnt/workspace/.npm-cache/_npx/4b4c857f6efdfb61/node_modules node test/smoke_m2_synthetic_sample_approval.cjs
```

Đã qua 11/11 unit tests và Chromium headless smoke VI/EN (đủ 64 claims, 12 bài KB, lọc chính xác và không network). Hai dịch vụ Modal embedding/reranker được giữ nguyên, không chạy model mới và không Git commit/push. Giữ nguyên provenance của mọi evidence lịch sử.

## Ý nghĩa đối với kế hoạch dự án

**Mốc kiểm duyệt hai người không còn là blocker cho việc dùng dữ liệu synthetic làm demo.** Chỉ cần human semantic review độc lập nếu sau này muốn công bố claim-level accuracy, triển khai AI answerability hoặc production cho nghiệp vụ thật. Hướng phát triển gần nhất là hoàn thiện Rails demo relevance-only, M3 ticket synthetic và UX, không đợi hai JSON review không cần thiết.
