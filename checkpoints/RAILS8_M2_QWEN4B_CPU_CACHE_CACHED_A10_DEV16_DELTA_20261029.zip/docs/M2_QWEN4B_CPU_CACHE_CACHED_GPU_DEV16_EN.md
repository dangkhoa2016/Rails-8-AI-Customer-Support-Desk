# Rails 8 AI Customer Support Desk — CPU-Pinned Cache and Read-Only A10 Dev16 GPU Evidence (EN)

**Executed:** October 29, 2026 (Asia/Ho_Chi_Minh).  
**Status:** `MODEL_CPU_CACHE_VERIFIED / A10_INFERENCE_COMPLETED / STRUCTURAL_QUALITY_FAILED / NOT_RELEASE`.  
**Evidence:** Actual Desktop Commander, Colab and Modal logs, frozen input data and immutable hashes. No independent human review is claimed.

## 1. Baseline and exact continuation point

The previous `RAILS8_M2_EXACT_EXCERPTS_DEV16_INFRA_TIMEOUT_DELTA_20261029.zip` recorded an **A10 function timeout after 480 seconds**, while loading model shards from Hugging Face. It produced no Qwen replies, so the 16-case quality benchmark was **NOT_EVALUATED**, not a 0% accuracy result.

This iteration aimed to remove GPU-time model downloading: fetch the exact pinned Qwen model into a separate Modal Volume using CPU only, check all official hashes, then rerun the **unchanged** frozen development16 manifest, generation prompt and seed from a read-only local model directory. No customer data, business writes, changes to KB approvals or Rails controllers, new endpoint deployments, or Git commits.

The project remains synthetic multi-tenant TeamFlow Cloud / NovaMart Store. Existing Qwen3-Embedding-4B and Qwen3-Reranker-4B Modal services and private Cloudflare relevance-only preview are preserved. The failed sealed80 M2 answerability scope verifier remains **disabled**.

## 2. CPU-only model acquisition and provenance

**Model:** `Qwen/Qwen3-4B-Instruct-2507`  
**Immutable revision:** `cdbee75f17c01a7cc42f958dc650907174af0554`  
**License on model card:** Apache-2.0.  
**Source:** Hugging Face `HfApi.model_info(revision=SHA, files_metadata=True)`.

The pre-download metadata in `review/m2_qwen4b_cpu_cache_official_metadata_20261029.json` freezes **12 required files**, including **three safetensors shards**, tokenizer and configs, README and LICENSE. Combined exact file sizes total **8,060,915,998 bytes**. Metadata SHA256:

`20c5b62b395b966d02d8f1448a0ce04d0d2557b98a0727cc1517934df3d509af`

A dedicated Modal Volume, **`rails8-support-desk-qwen3-instruct-4b-pinned`**, stores the model in `model/`. Existing model-serving Volumes remain untouched.

### Preserved failed attempt and corrected verification

The first CPU fetch falsely rejected the first safetensors shard because the validator checked **both** its published LFS content SHA256 **and** the Git blob SHA1 of its Git LFS *pointer file*. They identify different byte sequences and cannot both match the downloaded weights. This was an implementation mistake, **not evidence of model corruption**. Attempt0 produced no READY marker and no GPU invocation.

The corrected `modal_app/m2_qwen4b_cpu_cache.py` verifies **file size + content SHA256** for LFS files, and **file size + Git blob SHA1** for ordinary Git files. Six new offline regression tests in `test/test_m2_qwen4b_cpu_cache_verifier.py` all **PASS**, including the original LFS-pointer bug.

Retry1 succeeded: all **12/12 files** downloaded on Modal **CPU**, individually verified and Volume-committed; a final independent pass verified their complete byte contents before writing and committing `model/cache-ready.json`.

- `READY_ALL_12_OFFICIAL_FILES_HASH_VERIFIED`.
- 12 files / 8,060,915,998 bytes.
- `cache-ready.json` SHA256: **`ac0aef9c427dc08cbcf1c24eb788044ad10df24ffd499e8b001afac35149fcec`**.
- Downloaded the READY marker back using `modal volume get` and verified its exact SHA256.
- Preserved both CPU attempt logs and every per-file verification receipt; no failures were discarded.

## 3. One-shot offline A10 inference with read-only cache

A distinct ephemeral app at `modal_app/m2_exact_excerpts_dev16_cached_poc.py` mounts the verified Volume **read-only**, sets `HF_HUB_OFFLINE=1` and `TRANSFORMERS_OFFLINE=1`, and loads the tokenizer/model from a local path using `local_files_only=True`. It checks the pinned revision and READY marker, and rehashes all **12** model files inside the GPU job before inference. It has no HTTP endpoint and is now **stopped**.

The script-level check established that the prior timed-out attempt and this version share the same **system prompt, user prompt assembly, generation and decoding code**. The sole relevant operational change is loading from verified local model bytes, plus source verification. Input dataset and deterministic seed are unchanged:

- Manifest: `review/m2_exact_excerpt_development16_20261029.json`.
- Frozen SHA256: **`380de3f24ddc765cb7e3545b2d03dd8f66535918c79fd85614bcddedcfac5f11`**.
- 16 synthetic composite questions, balanced four each across TeamFlow VI, TeamFlow EN, NovaMart VI and NovaMart EN.
- Model revision as above; seed **20261029**, 1 A10, max one concurrent GPU container.

**Measured performance:** all 16 questions generated; remote job wall **99.347 s**, of which GPU-side full-cache SHA256 check **10.904 s**, model load **2.181 s**, summed generation **77.397 s**. Peak torch CUDA allocated memory **8,168,527,360 bytes (~7.61 GiB)**. These are observed wall/allocated values, **not actual Modal billed usage**.

Immutable raw output: `evidence-m2-exact-excerpts-dev16-cached-20261029/exact-excerpt-live.json`, SHA256:

`d79f43493b3d7f32a58c608b94224c1f3c00643e5ef4bc36de6830523cc178e7`

## 4. Strict quality evaluation — blocked

The unmodified `script/m2_deterministic_exact_spans.py` requires exact, unique Unicode source excerpts, disjoint claims/unresolved segments, complete letter/digit coverage, bounded structure and tenant/locale integrity. Its outputs state `semantic_fidelity_verified=false` and `human_review_required=true`; it cannot authorize policy answers or actions.

Using `script/evaluate_m2_exact_excerpts_dev16_cached.py` on the raw outputs and frozen developer-authored dataset:

| Check | Passed / total |
|---|---:|
| Real GPU output produced | 16/16 |
| JSON object parsed | **16/16** |
| Exact span and source coverage validation | **2/16** |
| Also recovered >=2 independent claims | **1/16** |
| Fully mapped without unresolved | **1/16** |

Of the fourteen rejected source-integrity cases, **11** assigned overlapping spans to both claims and unresolved segments, while **3** omitted source letters/digits. In another case, the model covered two separate user requests with one broad claim. **Source coverage alone does not prove correct semantic decomposition.**

No model output was silently repaired. An unsafe or contradictory overlap must fail closed; it is not appropriate to automatically remove `unresolved` merely to improve a test score. The 16 cases are **developer-written development data, NOT an independently verified sealed holdout**. These results support a **NOT_RELEASE** judgment, not a production accuracy estimate.

Evaluation JSON SHA256:

`a0a897812f57f6df3e84d3a38f1534451fb7efd9490c17c66d9a79c4da86b938`

Offline self-contained static review page, all 16 raw outputs and reasons:

`evidence-m2-exact-excerpts-dev16-cached-20261029/dev16-static-review.html` — SHA256

`c627b3ec0440c260bc3d4f3e3486a397c55dea4c13a9d1f8464ca250ee057010`

## 5. Regression, invariants and boundaries

- **6/6** CPU cache content hash/Git LFS tests; **15/15** source-span unit tests; **10/10** model-contract tests; **5/5** external human-review export validator tests.
- Full Rails suite **78 tests / 4,424 assertions / 0 failures/errors/skips**.
- Database remains **100 KnowledgeArticles / 212 versions / 12 approved / 84 embeddings**; `KnowledgeScopePreviewGate.eligible? == false`.
- Rails listeners 3068/3069 remain running. Original two inference service apps **deployed**; research CPU and A10 ephemeral apps **stopped**.
- Existing private preview and prior accepted M0/M1/M2 stages remain untouched; no Git commit/push, no business write, no new customer-facing answers or release.
- Independent **64-claim human review remains PENDING**.

## 6. Source and evidence inventory

Source: `modal_app/m2_qwen4b_cpu_cache.py`, `test/test_m2_qwen4b_cpu_cache_verifier.py`, `review/m2_qwen4b_cpu_cache_official_metadata_20261029.json`, `modal_app/m2_exact_excerpts_dev16_cached_poc.py`, `script/evaluate_m2_exact_excerpts_dev16_cached.py`, `script/render_m2_exact_excerpts_dev16_cached.py`.

CPU evidence: `evidence-m2-qwen4b-cpu-cache-20261029/`, including failed attempt0, corrected retry1, 12 file attestations, READY receipt and six unit tests.

GPU and results: `evidence-m2-exact-excerpts-dev16-cached-20261029/`, including frozen preflight, actual raw model output, evaluation, HTML review, diagnostics, full regression, app lifecycle and model performance.

The additive checkpoint ZIP excludes **8+ GB of model weights**, which remain on the dedicated Modal Volume. It also excludes credentials, .env files, customer/DB dumps, and private authentication tokens.

## 7. Recommendation / exact continuation point

**Infrastructure problem is resolved, but semantic structural quality is not.** The next step should be to design a stricter *partition-aware* output contract that forbids overlapping claim/unresolved regions and validates that each independent request is represented, with external human annotation. Use a **new** development set for iteration, not a re-labelled copy of this now-open dev16 evaluation. Preserve every raw rejection.

The 64-claim independent human review workbook still requires a real external reviewer. Only after source-integrity/decomposition metrics and an independently annotated, newly sealed holdout meet agreed criteria should staff-facing integration be considered.

Do **not** enable the previously failed M2 scope gate, autonomous replies or business writes.

**Conclusion:** CPU model cache **PASS**; real A10 inference **PASS**; claim decomposition acceptance **FAIL**; **`M2_CLAIM_LEVEL_NOT_RELEASE`**.
