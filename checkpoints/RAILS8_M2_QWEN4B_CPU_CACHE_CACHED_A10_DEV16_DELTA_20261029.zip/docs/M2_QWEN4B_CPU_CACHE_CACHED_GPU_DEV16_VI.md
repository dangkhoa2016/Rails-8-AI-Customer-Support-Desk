# Rails 8 AI Customer Support Desk — M2 CPU-Pinned Cache + Read-Only A10 Dev16 GPU Evidence (VI)

**Ngày:** 2026-10-29, múi giờ Asia/Ho_Chi_Minh.  
**Trạng thái:** `MODEL_CPU_CACHE_VERIFIED / A10_INFERENCE_COMPLETED / STRUCTURAL_QUALITY_FAILED / NOT_RELEASE`.  
**Nguồn đánh giá:** output thực từ Desktop Commander/Colab/Modal; tài liệu chỉ ghi nhận điều đã quan sát. Không có independent human approval.

## 1. Điểm tiếp tục, mục tiêu và các điều kiện được giữ nguyên

Từ checkpoint `RAILS8_M2_EXACT_EXCERPTS_DEV16_INFRA_TIMEOUT_DELTA_20261029.zip`, vấn đề chặn triển khai là Modal A10 timeout **480 giây** khi tải shard 3/3 của `Qwen/Qwen3-4B-Instruct-2507` từ Hugging Face. Vì chưa có output inference, kết quả phiên đó là **NOT_EVALUATED**, không phải model quality 0%.

Mục tiêu phiên hiện tại: cache model pinned bằng CPU vào Volume độc lập, xác minh nguồn và checkpoint, chạy lại **cùng một manifest development16/prompt/seed/code generation** nhưng **từ cache read-only** để kiểm tra lỗi hạ tầng và chất lượng cấu trúc. Không sử dụng dữ liệu khách hàng thật; không AI business write; không sửa hai endpoint embedding/reranker đã deploy; không bật scope gate; không chỉnh DB hoặc phê duyệt KB.

## 2. Cache model bằng CPU

Model `Qwen/Qwen3-4B-Instruct-2507`, revision **`cdbee75f17c01a7cc42f958dc650907174af0554`**, license **Apache-2.0**. Truy vấn Hugging Face `HfApi.model_info(revision=sha, files_metadata=True)` tại revision pinned để đóng băng metadata **12 file**, gồm **3 shard safetensors** và tokenizer/config/README/LICENSE.

Manifest: `review/m2_qwen4b_cpu_cache_official_metadata_20261029.json`  
SHA256: **`20c5b62b395b966d02d8f1448a0ce04d0d2557b98a0727cc1517934df3d509af`**.  
Tổng kích thước nội dung 12 file: **8.060.915.998 bytes**.

Volume riêng `rails8-support-desk-qwen3-instruct-4b-pinned`, model path `model/`. Không dùng/ghi đè Volume chứa hai model đang deployed, không tạo HTTP endpoint. Mỗi file được tải và xác minh bằng Modal CPU, rồi `volume.commit()` riêng; metadata được pin trước.

### Lỗi prefetch đầu tiên, đã bảo toàn và khắc phục

Attempt 0 dừng khi file safetensors được kiểm bằng **cả SHA256 LFS và Git blob SHA1**: trường Git blob SHA1 trên metadata của tệp LFS xác định **Git LFS pointer**, không phải SHA1 của nội dung binary weights. Đây là lỗi validator do triển khai, **không phải bằng chứng checksum weights bị hỏng**; attempt 0 không tạo dấu READY và không gọi GPU.

Đã sửa `modal_app/m2_qwen4b_cpu_cache.py`: đối với LFS xác minh **byte size + official SHA256**, đối với tệp Git thường xác minh **byte size + Git object SHA1**. Kiểm thử `test/test_m2_qwen4b_cpu_cache_verifier.py`: **6/6 PASS**, gồm kiểm tra phân biệt LFS-pointer và content hash, fake hash, wrong size, missing file.

Retry1 tải và xác minh **12/12 file** trên CPU, sau đó `finalize` đọc lại toàn bộ file, xác nhận hash, commit `model/cache-ready.json` vào Volume:

- Trạng thái `READY_ALL_12_OFFICIAL_FILES_HASH_VERIFIED`.
- `total_bytes=8060915998`, `file_count=12`.
- SHA256 của `cache-ready.json`: **`ac0aef9c427dc08cbcf1c24eb788044ad10df24ffd499e8b001afac35149fcec`**.
- Đã dùng `modal volume get` tải ngược `cache-ready.json`; SHA256 byte-to-byte khớp.
- Giữ riêng log attempt 0, retry1 và 12 receipt trong `cpu-prefetch-events-retry1.jsonl`. Không xóa dữ liệu thất bại để tô đẹp kết quả.

## 3. GPU chạy lại từ cache (offline, read-only)

Script mới **`modal_app/m2_exact_excerpts_dev16_cached_poc.py`** là một app ephemeral riêng, không deploy API, GPU **A10**, 1 container, timeout function **480 giây**, seed **20261029**, revision model pinned như trên.

Trước inference, GPU mount Volume bằng `with_mount_options(read_only=True)`, yêu cầu đúng READY marker, đúng revision/source-manifest và **kiểm tra lại SHA256 của đủ 12 file**; đặt `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`, tải model/tokenizer từ directory cục bộ với `local_files_only=True`. Không thực hiện HF checkpoint download trong GPU job.

Đã so sánh source cũ và source mới bằng code: **system prompt, mô tả yêu cầu trong user prompt, vòng lặp generation và decoding không thay đổi**. Input là đúng manifest 16 câu **`review/m2_exact_excerpt_development16_20261029.json`** (SHA256 **`380de3f24ddc765cb7e3545b2d03dd8f66535918c79fd85614bcddedcfac5f11`**), mỗi tenant/ngôn ngữ 4 câu.

**Kết quả GPU thực:**
- Hoàn tất **16/16** câu; parseable JSON object **16/16**.
- Remote invocation wall **99,347 giây**; trong đó kiểm tra hash trên GPU **10,904 giây**, load model **2,181 giây**; tổng thời gian sinh token **77,397 giây**. Đây không phải billed GPU seconds hay hóa đơn Modal.
- GPU max allocated **8.168.527.360 bytes** (xấp xỉ 7,61 GiB).
- GPU app `rails8-support-desk-m2-exact-excerpts-dev16-cached-onetime` sau job **stopped**, không có endpoint phục vụ.

Raw output không thay đổi: `evidence-m2-exact-excerpts-dev16-cached-20261029/exact-excerpt-live.json`.  
SHA256: **`d79f43493b3d7f32a58c608b94224c1f3c00643e5ef4bc36de6830523cc178e7`**.

## 4. Kết quả chất lượng — bị chặn

Bộ kiểm tra `script/m2_deterministic_exact_spans.py` không sửa âm thầm, không fuzzy match, không tin offset từ LLM. Nó kiểm tra mỗi excerpt phải đúng một chuỗi con Unicode gốc duy nhất, không chồng lấn, mọi ký tự chữ/số được bao phủ bởi claims hoặc unresolved; metadata tenant/locale hợp lệ. Điều này chỉ bảo đảm source provenance, không chứng minh ngữ nghĩa/entailment.

Đã chạy `script/evaluate_m2_exact_excerpts_dev16_cached.py` với 16 bản raw và manifest frozen:

| Tiêu chí | PASS / tổng |
|---|---:|
| Inference A10 trả kết quả | 16/16 |
| JSON parse thành công | **16/16** |
| Toàn bộ source spans hợp lệ | **2/16** |
| Đạt thêm số intent tối thiểu theo developer (>=2) | **1/16** |
| Đạt cả các tiêu chí và không unresolved | **1/16** |

Với 14 trường hợp không qua source integrity:
- **11** claim/unresolved chọn các vùng **chồng lấn**; phải từ chối, không tự hợp nhất.
- **3** bỏ sót phần chứa chữ/số trong câu nguồn; phải từ chối.
- Hai case source integrity PASS gồm một case TeamFlow VI với 3 claim đầy đủ và một case NovaMart EN chỉ có 1 claim ôm cả câu nhiều ý, do đó **không đạt tiêu chí tách ý**.

**Đây là developer development set, không có independent gold và không phải sealed holdout**. Kết quả đủ kết luận **`NOT_RELEASE`** cho tính năng claim-level, không đủ để ước lượng production accuracy hay an toàn thực tế.

Evaluation JSON: `evidence-m2-exact-excerpts-dev16-cached-20261029/dev16-evaluation.json`.  
SHA256: **`a0a897812f57f6df3e84d3a38f1534451fb7efd9490c17c66d9a79c4da86b938`**.

Static HTML (16 raw cases, nguồn và lý do từ chối, chạy offline): `evidence-m2-exact-excerpts-dev16-cached-20261029/dev16-static-review.html`.  
SHA256: **`c627b3ec0440c260bc3d4f3e3486a397c55dea4c13a9d1f8464ca250ee057010`**.

Không dùng 16 câu này để sửa prompt và gọi đó là holdout mới; nếu muốn cải thiện mô hình cần bộ development mới và độc lập review.

## 5. Regressions, bất biến và bảo mật

- **6/6** unit tests phân biệt LFS/Git checksum; **15/15** exact span tests; **10/10** model contract tests; **5/5** human-review-export validator tests.
- Full Rails suite: **78 tests / 4.424 assertions / 0 failures/errors/skips**.
- PostgreSQL trước/sau: **100 articles / 212 versions / 12 approved / 84 embeddings**; `KnowledgeScopePreviewGate.eligible? == false`.
- Hai Rails ports 3068/3069 vẫn hoạt động. Modal apps Qwen3-Embedding-4B và Qwen3-Reranker-4B **deployed**, các app nghiên cứu CPU/GPU đã **stopped**.
- Không business writes, không tự phê duyệt, không bật scope, không deploy endpoint mới; không Git commit/push. Không đưa token/.env hoặc model weights vào delta ZIP.
- Reviewer độc lập đối với **64 claim** vẫn `PENDING`; workbook trước đó không đổi.

## 6. Các file triển khai và evidence

Source và metadata: `modal_app/m2_qwen4b_cpu_cache.py`, `test/test_m2_qwen4b_cpu_cache_verifier.py`, `review/m2_qwen4b_cpu_cache_official_metadata_20261029.json`, `modal_app/m2_exact_excerpts_dev16_cached_poc.py`, `script/evaluate_m2_exact_excerpts_dev16_cached.py`, `script/render_m2_exact_excerpts_dev16_cached.py`.

CPU evidence tại `evidence-m2-qwen4b-cpu-cache-20261029/`: attempt0/retry1 logs, events JSONL, failure JSON, READY JSON và tests. Cached GPU evidence tại `evidence-m2-exact-excerpts-dev16-cached-20261029/`: raw JSON, evaluation JSON, static HTML, status JSON, preflight, GPU log, regressions và app state. Delta ZIP **không** chứa 8 GB model; weights vẫn ở Volume riêng.

## 7. Đề xuất tiếp theo / chưa thực hiện

1. Không vội chỉnh prompt trên 16 case đã mở. Thiết kế **partition-aware claim extraction**: chỉ định đoạn không chồng lấn, phân biệt đúng `untrusted_text`/phần chưa rõ, và kiểm tra độc lập ranh giới multi-intent, ngoài coverage chữ.
2. Tạo **development mới** và độc lập human-gold cho các case VI/EN, đặc biệt explicit-negative, unsupported-neutral và prompt-injection trước khi thử lại GPU. Giữ nguyên raw rejects và ghi provenance.
3. Người đánh giá thật cần hoàn tất workbook 64 claim, lưu chữ ký/quy trình phê duyệt. Validator JSON không thay thế việc xác thực danh tính hoặc đánh giá ngữ nghĩa.
4. Tạo **sealed holdout hoàn toàn mới** chỉ sau khi code/gate/prompt được khóa. Không bật `M2_ANSWERABILITY_SCOPE_ENABLE`, không sản xuất câu trả lời khách hàng tự động hay business writes.

**Kết luận:** CPU cache + A10 inference **PASS về hạ tầng**, nhưng cấu trúc tách ý **FAIL acceptance**; **`M2_CLAIM_LEVEL_NOT_RELEASE`**.
