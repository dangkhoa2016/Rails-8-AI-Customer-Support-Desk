# Hotwire M4 — Triển khai Rails 8 AI Customer Support Desk

Ngày kiểm chứng: 2026-10-30. Phạm vi: hai tenant tổng hợp TeamFlow Cloud/NovaMart Store, role Viewer/Agent/Owner. Chỉ bổ sung lớp tương tác; không chỉnh sửa policy M0, dữ liệu M1–M3, embeddings, hay cấu hình Modal inference.

## Công nghệ thực tế

- Rails 8.0.5.1 + `turbo-rails` 2.0.23, `stimulus-rails` 1.3.4, `importmap-rails` 2.2.3 và `propshaft` 1.3.2.
- Sử dụng Importmap, không cần node bundler, Vite hoặc Webpack. `bundle install` và `bin/rails assets:precompile` đã được thực thi thành công.
- `app/javascript/application.js` tải Turbo Drive và Stimulus. `controllers/submit_state_controller.js` hiển thị trạng thái `aria-busy` khi gửi form.

## Những màn hình đã nâng cấp

1. **Turbo Drive:** điều hướng top menu và liên kết trang tiếp tục dùng Rails ERB nhưng Turbo thay `body` mà không tải lại toàn bộ document.
2. **Turbo Frames:** `tickets_listing` bao quanh form bộ lọc và bảng ticket; `customers_listing` bao quanh tìm theo mã/tên và phân trang 20 bản ghi/trang; `kb_search_results` bao quanh tìm kiếm KB. Mỗi GET frame có `data-turbo-action=advance` để cập nhật URL/history; liên kết mở ticket/customer detail thoát frame bằng `data-turbo-frame=_top`.
3. **Turbo Streams:** đổi trạng thái ticket thay thế `ticket_summary`, `ticket_status_controls`, và vùng thông báo; ghi chú nội bộ / phản hồi đã được human-confirmed thay thế `ticket_conversation`, `ticket_reply_form`, và thông báo. Form được reset với idempotency key mới. Các request HTML thường giữ fallback HTTP 303.
4. **Stimulus:** form có controller `submit-state` để bật/tắt `aria-busy` khi Turbo bắt đầu/kết thúc submit. Không giữ nội dung support trong localStorage hoặc browser cache.

## Quy tắc an toàn giữ nguyên

- Meta `turbo-cache-control=no-cache` và `turbo-prefetch=false` để không cache/prefetch bản xem chứa thông tin tenant.
- Form đăng nhập và đăng xuất `data-turbo=false`; đăng xuất `reset_session` vẫn làm tải document mới có chủ đích.
- Viewers vẫn không thể gửi thay đổi; tenant của mỗi ticket và message được kiểm tra ở server. Public reply vẫn yêu cầu `review_confirmed=1` và audit. Owner KB approval vẫn là human-only.
- Cloudflare Quick Tunnel vẫn **read-only**: các POST/PATCH nghiệp vụ vẫn chặn 405. Vì vậy các Turbo Streams ghi ticket phải test qua Rails test DB, không bật ghi công khai.
- Gate answerability sealed80 **BLOCKED**, không thực hiện GPU/Modal inference mới, không broadcast qua ActionCable.
- `config/cable.yml` chỉ nhằm cấu hình test adapter cho Rails; chưa triển khai WebSocket realtime production.

## Kiểm chứng & giới hạn

- `bin/rails test`: **103 tests / 4.814 assertions / 0 failures / 0 errors / 0 skips** (đính kèm `evidence/rails-regression-final.log`).
- `test/integration/hotwire_integration_test.rb`: **8 tests / 116 assertions PASS**, gồm Turbo Drive, Frames, lọc, phân trang, Stream mutations, human approval, phân quyền, tenant isolation.
- Kiểm chứng HTTP cho `application.js`, `turbo.min.js`, `stimulus.min.js`, `submit_state_controller.js`: HTTP 200.
- HTTPS smoke Private Demo: 6 demo accounts + VI/EN, đổi tài khoản, active nav/cursor PASS; **5 JS assets và 3 Turbo Frames qua HTTPS PASS**; 4 tuyến Turbo Stream business writes qua tunnel vẫn 405.
- **Chromium Playwright thực tế PASS** bằng `test/browser_hotwire_private_demo.cjs`: Turbo và Stimulus tải thật, chuyển sang Tickets, bộ lọc, chi tiết ticket, phân trang Customers, tìm KB không full reload; sign-out chuyển document có chủ đích; đổi sang NovaMart Viewer không rò tenant; 0 lỗi JavaScript. Không tuyên bố cải thiện tốc độ/độ trễ khi chưa đo.
- Không commit hoặc push Git. Các checkpoint trước đây vẫn giữ nguyên.

## Lệnh khôi phục trong Colab mới

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
source /content/rails8_restore_env_20261030.sh # chỉ tồn tại trong Colab runtime đã được thiết lập
bundle install
bin/rails assets:precompile
RAILS_ENV=test bin/rails test
```

Trước khi triển khai máy khác, cần cấu hình `mise`, PostgreSQL/pgvector, `.env.notebook` và private preview riêng. Không copy mật khẩu từ backup. Với môi trường development, không giữ lại `public/assets/.manifest.json` sau khi sửa JS, vì Rails sẽ phục vụ bản asset cũ.
