# Hotwire M4 — Rails 8 AI Customer Support Desk implementation

Validation date: 2026-10-30. Scope: two synthetic tenants (TeamFlow Cloud / NovaMart Store) and three demo roles (Viewer, Agent, Owner). This is a UI layer enhancement: approved M0 policies, M1–M3 data, embeddings and Modal inference configuration are unchanged.

## Stack

- Rails 8.0.5.1; `turbo-rails` 2.0.23, `stimulus-rails` 1.3.4, `importmap-rails` 2.2.3, `propshaft` 1.3.2.
- Importmap-based delivery without a JavaScript bundler or build tools. `bundle install` and `bin/rails assets:precompile` have passed.
- `app/javascript/application.js` imports Turbo Drive and Stimulus. `submit_state_controller.js` manages `aria-busy` during Turbo form submission.

## Implemented flows

1. **Turbo Drive** intercepts ordinary in-app navigation and replaces page content without traditional full-document reload.
2. **Turbo Frames**: `tickets_listing` wraps filtering and list, `customers_listing` wraps scoped customer key/name search and 20-item pagination, and `kb_search_results` wraps the KB query/results section. GET frame navigation uses `data-turbo-action=advance` for browser history. Detail links target `_top`.
3. **Turbo Streams**: ticket status changes replace `ticket_summary` and `ticket_status_controls` plus notices. Human-authored internal notes and approved public replies replace `ticket_conversation`, `ticket_reply_form` and notices, resetting the idempotency token. Standard HTML POST/PATCH clients retain HTTP 303 redirects.
4. **Stimulus** form controller toggles `aria-busy` without persisting ticket content in client storage.

## Safety, compatibility and scope limits

- All pages send `turbo-cache-control=no-cache`, `turbo-prefetch=false` to avoid snapshot replay and prefetch of private tenant data.
- Both demo sign-in/sign-out forms use `data-turbo=false`; sign-out intentionally loads a new document after `reset_session`.
- Viewer write restrictions, tenant-scoped queries, human-approved public replies, audit records and owner-only KB publication remain server enforced.
- Public Cloudflare Quick Tunnel remains **read-only** and returns HTTP 405 for business writes. Mutation Streams are tested via isolated Rails test DB, not enabled on the public tunnel.
- The sealed80 answerability gate remains **BLOCKED**. No new Modal GPU inference or ActionCable broadcasts.
- `config/cable.yml` configures Rails test adapter; production realtime WebSockets are not in scope.

## Validation and remaining caveats

- Full Rails regression: **103 tests / 4,814 assertions / zero failures/errors/skips** (`evidence/rails-regression-final.log`).
- `test/integration/hotwire_integration_test.rb` passed **8 tests / 116 assertions** covering Turbo markup, Frames, search/pagination, Streams, authorization, human confirmation and tenant isolation.
- HTTP 200 confirmed for application.js, Turbo, Stimulus and the custom Stimulus controller.
- Private HTTPS role guide, cross-tenant account switching and active navigation smoke tests passed. **Five JS assets and three Turbo Frames over HTTPS PASS**; the Cloudflare write gate still returns 405 for Turbo business mutations.
- **Chromium Playwright browser test PASS** using `test/browser_hotwire_private_demo.cjs`: Turbo and Stimulus execute, Tickets navigation/filter/detail, Customers pagination and KB searches preserve the browser JS context; sign-out intentionally reloads the document; switching to NovaMart Viewer hides the former tenant and staff-only AI navigation; zero JS errors. No unmeasured speed/latency claim.
- Git remains uncommitted/unpushed. Previously approved backup artifacts are unchanged.

## Restoring in a new notebook

Install Ruby 3.3, Rails dependencies, PostgreSQL 16 and pgvector. Restore the saved Git worktree + custom PostgreSQL dump, create separate test DB, reconfigure private credentials outside the repo, then:

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
bundle install
bin/rails assets:precompile
RAILS_ENV=test bin/rails test
```

In development, remove the generated `public/assets/.manifest.json` after changing JavaScript, otherwise the precompiled JS can remain stale.
