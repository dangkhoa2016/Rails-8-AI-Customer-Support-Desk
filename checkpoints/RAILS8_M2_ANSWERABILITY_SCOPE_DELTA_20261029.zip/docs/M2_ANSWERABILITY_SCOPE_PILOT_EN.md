# M2 — Answerability / Scope-Contrast Pilot (EN)

**Reviewed:** 2026-10-29 (Asia/Ho_Chi_Minh)  
**Scope:** Internal synthetic-only assistant demo for TeamFlow Cloud and NovaMart Store.  
**Not:** A proven semantic entailment model, an autonomous customer chatbot, or a production release.

## Why relevance alone fails

Only six of the 100 KB articles have approved v2 text (12 localized versions, 84 embedded chunks). Each approved article distinguishes its permitted scope, evidence to verify, human review, and facts that must not be inferred. A question can mix a supported policy clause with a request that the KB **does not** answer. A high rerank score cannot prove that the full request is answerable.

For example, NM-KB-020 describes the courier handoff target and an estimated two-to-five-business-day window, not exact hourly delivery scheduling or courier replacement. NM-KB-014 covers standard delivery fees after discounts, not the use of loyalty rewards for free express shipping.

## Design

- Retain the pinned Qwen3-Embedding-4B / Qwen3-Reranker-4B models, Modal proxy authentication, pgvector and strict tenant/role/locale/approval/digest/date checks.
- Stage 1: original semantic retrieval/reranking and the earlier calibrated **7.421875** raw-logit relevance cutoff.
- Stage 2 (experimental): ONLY after relevant evidence qualifies, make at most **one more Reranker-4B call** with 8 human-written, same-article, same-locale synthetic questions: four explicitly supported by the KB and four plausible but unsupported. Compute maximum supported score minus maximum unsupported score.
- The **5.05078125** margin cutoff was derived from a separate 36-case diagnostic: max near-domain negative margin **3.6171875**, minimum positive margin **6.484375**. The subsequent 24-case multi-intent test did not determine the cutoff.
- Before GPU, check model pin, corpus fingerprint, previous relevance-policy SHA256, current tenant and scope manifest SHA256. Missing contracts, invalid scores and unauthorized data **fail closed**. Cross-tenant retrieval and business writes remain forbidden.
- On success, return qualified chunks only from the top article whose support scope was checked. A verified *answer* is never generated: all excerpts remain human-review evidence.

## Evidence

In the original 36 diagnostic cases, using the scope margin **alone** is inadequate: five of 14 unsupported questions had positive margins. It is therefore not an independent entailment verifier.

A new labeled **24-question VI/EN multi-intent challenge** (18 unsupported, 6 supported), frozen before inference, produced:

| Measure | Relevance only | Combined gate |
|---|---:|---:|
| True positive | 5 | 5 |
| False negative | 1 | 1 |
| False positive | 2 | 0 |
| True negative | 16 | 18 |

Full per-case results contain query hashes, rerank scores, margins, and citations. **These numbers are a small synthetic pilot, not production accuracy or a guarantee of zero future false positives.** Claim-level support and complete intent parsing remain unsolved.

## Files

- `review/m2_answerability_scope_probes_20261029.json`
- `review/m2_answerability_multi_intent_lockbox_20261029.json`
- `review/m2_answerability_scope_policy_pilot_20261029.json`
- `app/services/knowledge_answerability_scope_verifier.rb`
- `app/services/knowledge_reranked_retrieval.rb`
- `app/controllers/knowledge_ai_search_controller.rb`
- `script/m2_answerability_scope_probe_pilot.rb`
- `script/m2_answerability_scope_lockbox.rb`
- `script/build_m2_answerability_scope_policy.py`
- `script/verify_m2_answerability_live_scope.rb`
- `evidence-m2-answerability-20261029/`

Set `M2_ANSWERABILITY_SCOPE_ENABLE=YES` to enable in the development UI. Disabled by default pending explicit runtime acceptance. With the gate enabled, suggestions still require human validation. No answer generation, billing/returns/plan write operations, or editorial approval.

## Open risks

1. Increase the independently sealed evaluation sample size, especially combined-intent questions whose unsupported clauses do not resemble existing negative probes.
2. Evaluate independent query decomposition and claim-level evidence support; the reranker is **not** a logical entailment model.
3. Report per-tenant/per-locale false positives, false abstentions, warm/cold latency and GPU cost.
4. Extend approved KB only with human approval; rebuild both scope contracts and calibration when the approved corpus or model changes.
5. Production customer authentication, distributed rate limits, privacy/DLP and auditing remain open. Cloudflare Quick Tunnel is a password-gated synthetic preview, not production infrastructure.

No DB reseed/reset, KB approval, re-embedding, model redeployment, or Git commit/push was performed.

## Real GPU and Rails acceptance (additional)

**Five synthetic live requests** were executed through Rails → Embedding-4B → pgvector → Reranker-4B → scope verifier:
- AX10 NovaMart EN (loyalty/express shipping): **zero qualified evidence**, PASS.
- AX11 NovaMart VI (exact delivery time/change courier): **zero qualified evidence**, PASS.
- AX19 TeamFlow VI (paid invoice/activation event): **TF-KB-012** Top-1 with three citations, PASS.
- AX21 NovaMart VI (post-discount standard shipping fee): **NM-KB-014** Top-1 with three citations, PASS.
- Original wrong-tenant SaaS activation question in NovaMart VI: **zero qualified evidence**, PASS.

Evidence: `evidence-m2-answerability-20261029/live-scope-acceptance.json`. Original DB before/after unchanged: 100 articles, 212 versions, 12 approved, 84 embeddings. Single sequential client, no random sampling. First request cold 39.717 seconds; remaining warm requests 1.474–2.365 seconds. Warm times do not imply a guaranteed SLA.

**Full Rails regression:** 74 tests / 4,405 assertions / zero failures, errors or skips. Scope feature flag remains **OFF by default** in the current preview; UI behavior with the flag enabled was unit/integration tested, but Cloudflare browser end-to-end testing of the new flag has not been completed.
