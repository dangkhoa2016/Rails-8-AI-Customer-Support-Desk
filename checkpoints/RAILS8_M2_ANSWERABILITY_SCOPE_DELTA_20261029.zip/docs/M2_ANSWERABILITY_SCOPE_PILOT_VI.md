# M2 — Answerability / Scope-Contrast Pilot (VI)

**Ngày kiểm tra:** 2026-10-29 (Asia/Ho_Chi_Minh)  
**Phạm vi:** Chỉ dữ liệu synthetic TeamFlow Cloud và NovaMart Store, internal assistant pilot.  
**Không phải:** Entailment verifier được chứng minh, chatbot trả lời tự động, hoặc production authorization.

## Phát hiện từ các bài KB đã duyệt

Chỉ 6 trong 100 bài KnowledgeArticle có v2 approved (12 bản VI/EN, 84 vector). Mỗi bài có phần phạm vi, chính sách có hiệu lực, chứng cứ phải đối chiếu và nội dung không được tự kết luận. Câu hỏi có thể chứa đồng thời **một ý nằm trong chính sách** và **một yêu cầu chưa có tài liệu hướng dẫn**. Khi đó, điểm relevance cao của một đoạn chưa chứng minh rằng toàn bộ yêu cầu có câu trả lời.

Ví dụ synthetic: KB NM-KB-020 giải thích mục tiêu bàn giao và ước lượng giao 2–5 ngày làm việc, **không** xác nhận lịch giao chính xác lúc 19 giờ hoặc quy trình đổi hãng vận chuyển. KB NM-KB-014 quy định phí giao thường theo giá trị sau giảm giá, **không** cho phép suy diễn quyền dùng điểm thưởng để miễn phí giao nhanh.

## Thiết kế triển khai

- Giữ nguyên Qwen3-Embedding-4B / Qwen3-Reranker-4B pinned, Modal Proxy Authentication, PostgreSQL pgvector, tenant/role/approved/locale/digest/date scoping.
- Bước 1: semantic candidate retrieval và rerank đã có; relevance gate phiên trước đặt ngưỡng raw logit **7.421875**, hiệu chỉnh trên bộ dữ liệu có nhãn.
- Bước 2 (thử nghiệm): *chỉ khi có ranked evidence vượt relevance*, dùng tối đa **1 lượt rerank bổ sung** với **8 câu synthetic** cùng ngôn ngữ và cùng bài KB Top-1, trong đó 4 câu kiểm tra nội dung được hỗ trợ và 4 câu gần chủ đề nhưng không đủ bằng chứng. So sánh best supported score với best unsupported score; margin ngưỡng **5.05078125**.
- Ngưỡng scope được tính bằng trung điểm giữa max near-domain negative margin **3.6171875** và min positive margin **6.484375** trong tập 36 case discovery. Không chọn ngưỡng bằng điểm số của tập 24 câu multi-intent lockbox.
- Nếu thiếu scope contract cho bài KB, dữ liệu fingerprint thay đổi, không đúng model revision, lỗi response, cross-tenant hoặc kết quả không đủ điều kiện thì **fail closed**, không gửi nội dung KB ngoài ACL hay tự tìm tenant khác. Không thực hiện business writes.
- Nếu qua hai gate, chỉ hiển thị các chunk đã qualified của **chính bài KB được đối chiếu phạm vi**. Tài liệu vẫn là evidence proposal, nhân viên phải xác minh câu trả lời cuối.

## Kết quả benchmark

Tập 36 discovery dùng để thử độ phân tách của scope probes: 22 supported và 14 unsupported (lọc ưu tiên các câu gần domain). Probe đứng riêng **không an toàn** vì vẫn có 5/14 negative với margin dương; không nên dùng margin đơn lẻ như kiểm chứng entailment.

Tạo tập **24 câu VI/EN mới có nhãn trước inference** (18 unsupported/mixed-intent, 6 supported), không dùng để hiệu chỉnh margin. So sánh:

| Chỉ số | Chỉ relevance | Hai bước |
|---|---:|---:|
| True positive | 5 | 5 |
| False negative | 1 | 1 |
| False positive | 2 | 0 |
| True negative | 16 | 18 |

Các kết quả có SHA256 câu hỏi, score, margin và citation trong evidence JSONL. **Đây là thử nghiệm nhỏ, không bảo đảm future FPR=0.** Phân loại hoàn chỉnh nhiều ý hoặc đối chiếu từng mệnh đề vẫn là bài toán chưa giải quyết.

## Các file liên quan

- `review/m2_answerability_scope_probes_20261029.json`
- `review/m2_answerability_multi_intent_lockbox_20261029.json`
- `review/m2_answerability_scope_policy_pilot_20261029.json`
- `app/services/knowledge_answerability_scope_verifier.rb`
- `app/services/knowledge_reranked_retrieval.rb`
- `app/controllers/knowledge_ai_search_controller.rb`
- `script/m2_answerability_scope_probe_pilot.rb`
- `script/m2_answerability_scope_lockbox.rb`
- `script/build_m2_answerability_scope_policy.py`
- `script/verify_m2_answerability_live_scope.rb`
- `evidence-m2-answerability-20261029/`

`M2_ANSWERABILITY_SCOPE_ENABLE=YES` bật gate trên giao diện dev. Mặc định OFF cho đến khi xác minh acceptance; nội dung nào được gate đề xuất vẫn có trạng thái cần người kiểm chứng. Không tự sinh câu trả lời cuối, cập nhật billing/return/plan hay KB editorial.

## Việc chưa nghiệm thu

1. Thêm sealed evaluation lớn và đa dạng hơn, phân loại đầy đủ câu multi-intent, đặc biệt không có negative mẫu gần giống.
2. Kiểm tra query decomposition độc lập và claim-level support; không khẳng định mô hình reranker đã học được logical entailment.
3. Định lượng precision/recall, false abstention và GPU request cost thực tế theo tenant/ngôn ngữ, cũng như cold start.
4. Khi thêm approved KB hoặc thay đổi weights/model/policy, tạo phiên bản scope contract và bộ đánh giá mới thay vì sử dụng ngưỡng cũ.
5. Bảo vệ production authentication, rate limits, audit và strict privacy chưa hoàn thiện; Cloudflare Quick Tunnel chỉ là synthetic demo.

Không reset/reseed database, không approve KB, không re-embed, không tái triển khai Modal, không commit/push Git.

## Acceptance thực trên GPU + Rails (bổ sung)

Đã chạy **5 truy vấn synthetic** qua full pipeline Rails → Embedding-4B → pgvector → Reranker-4B → scope verifier:
- AX10 NovaMart EN (loyalty/express shipping): **0 bằng chứng**, PASS.
- AX11 NovaMart VI (giờ giao chính xác/đổi hãng): **0 bằng chứng**, PASS.
- AX19 TeamFlow VI (invoice paid/activation event): **TF-KB-012** Top-1, 3 citations, PASS.
- AX21 NovaMart VI (phí giao thường theo sau giảm giá): **NM-KB-014** Top-1, 3 citations, PASS.
- Câu SaaS activation sai tenant NovaMart VI trong handoff: **0 bằng chứng**, PASS.

Nguồn `evidence-m2-answerability-20261029/live-scope-acceptance.json`. DB trước/sau không đổi: 100 articles, 212 versions, 12 approved, 84 embeddings. Một luồng tuần tự, không sampling. First request cold 39.717 giây; bốn request còn lại warm 1.474–2.365 giây. Không dùng con số warm làm cam kết SLA.

**Rails regression cuối:** 74 tests / 4.405 assertions / 0 failures / 0 errors / 0 skips. Scope flag vẫn **OFF mặc định** trên preview hiện tại; đã test khi bật qua env riêng và ghi rõ trạng thái trong giao diện. Kết quả chưa có kiểm thử Cloudflare browser end-to-end của flag mới.
