Rails.application.configure do
  config.enable_reloading = true
  config.eager_load = false
  config.consider_all_requests_local = true
  config.action_controller.perform_caching = false
  config.active_support.deprecation = :log
  config.active_record.verbose_query_logs = true
  config.action_mailer.default_url_options = { host: 'localhost', port: 3000 }
  config.hosts << /.*\.trycloudflare\.com/ if ENV['ALLOW_QUICK_TUNNEL'] == 'YES'
  # Opt-in private demo gate for viewing via an authenticated Colab notebook.
  # Never enables Cloudflare access or weakens synthetic demo sign-in restrictions.
  if ENV['RAILS_PRIVATE_PREVIEW'] == 'YES'
    require 'rack/auth/basic'
    require 'digest'
    preview_password = ENV.fetch('RAILS_PRIVATE_PREVIEW_PASSWORD')
    raise 'Private preview password is too short' if preview_password.bytesize < 30
    expected_digest = Digest::SHA256.hexdigest(preview_password)
    config.middleware.insert_before 0, Rack::Auth::Basic, 'Support Desk Private Preview' do |username, password|
      username == 'support-preview' &&
        ActiveSupport::SecurityUtils.secure_compare(Digest::SHA256.hexdigest(password.to_s), expected_digest)
    end
    # Colab port proxy hostname for port 3068 only, not arbitrary public domains.
    config.hosts << /\A[a-z0-9-]+-3068-colab\.googleusercontent\.com\z/
  end
end
