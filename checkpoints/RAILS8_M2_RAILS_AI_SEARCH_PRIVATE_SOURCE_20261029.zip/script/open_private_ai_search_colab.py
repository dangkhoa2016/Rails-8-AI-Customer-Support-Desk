"""Open the LOCAL Rails AI Search through YOUR active Colab notebook only.

Run from a cell in the same attached Colab runtime:
  %run /content/Rails-8-AI-Customer-Support-Desk/script/open_private_ai_search_colab.py

Do not share the resulting URL or notebook output. The Rails server must
already run on 127.0.0.1:3068 with its separate Basic Auth preview gate.
"""
from google.colab import output
import urllib.request
import urllib.error

url = "http://127.0.0.1:3068/demo/sign_in"
try:
    urllib.request.urlopen(url, timeout=5)
except urllib.error.HTTPError as exc:
    if exc.code != 401:
        raise RuntimeError(f"Unexpected localhost server HTTP status: {exc.code}")
    print("Private Rails preview gate: HTTP 401 without password (expected).")
else:
    raise RuntimeError("Refusing to open Colab preview: Rails has no Basic Auth gate.")

print("Browser Basic Auth username: support-preview")
print("Retrieve the password privately from ~/.config/rails8-support-desk-modal/rails-private-preview.env")
print("Do not share the notebook proxy URL or password. Clear notebook outputs afterwards.")
output.serve_kernel_port_as_window(3068, path="/demo/sign_in")
