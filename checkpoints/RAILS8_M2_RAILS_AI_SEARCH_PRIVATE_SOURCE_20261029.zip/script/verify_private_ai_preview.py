#!/usr/bin/env python3
"""Check the localhost-only private-preview gate and Rails UI without GPU calls."""
import datetime
import json
from pathlib import Path

import requests
from bs4 import BeautifulSoup

BASE = "http://127.0.0.1:3068"
CREDENTIAL_FILE = Path.home() / ".config/rails8-support-desk-modal/rails-private-preview.env"
PASSWORD = next(line.partition("=")[2] for line in CREDENTIAL_FILE.read_text().splitlines()
                if line.startswith("RAILS_PRIVATE_PREVIEW_PASSWORD="))
assert len(PASSWORD) >= 30
checks = []

def check(label, actual, expected):
    assert actual == expected, (label, actual, expected)
    checks.append({"check": label, "http_status": actual})

def csrf_from(html, action):
    doc = BeautifulSoup(html, "html.parser")
    input_tag = doc.select_one(f"form[action='{action}'] input[name='authenticity_token']")
    assert input_tag and input_tag.get("value")
    return input_tag["value"]

check("no Basic Auth", requests.get(BASE+"/demo/sign_in", timeout=10).status_code, 401)
check("incorrect Basic Auth", requests.get(BASE+"/demo/sign_in",
       auth=("support-preview", "not-the-password"), timeout=10).status_code, 401)

for tenant, label, locale in [
    ("teamflow", "TeamFlow Cloud / Synthetic TF agent (agent)", "vi"),
    ("novamart", "NovaMart Store / Synthetic NM agent (agent)", "en")
]:
    client = requests.Session()
    client.auth = ("support-preview", PASSWORD)
    login = client.get(BASE+"/demo/sign_in", timeout=10)
    check(tenant+" gate valid", login.status_code, 200)
    dom = BeautifulSoup(login.text, "html.parser")
    identity = [x for x in dom.select("select[name=membership_id] option")
                if x.get_text(" ",strip=True) == label]
    assert len(identity) == 1
    result = client.post(BASE+"/demo/sign_in",
        data={"membership_id": identity[0]["value"], "locale": locale,
              "authenticity_token": csrf_from(login.text,"/demo/sign_in")},
        allow_redirects=False,timeout=15)
    check(tenant+" login", result.status_code, 302)
    panel = client.get(BASE+"/kb/ai-search?locale="+locale,timeout=15)
    check(tenant+" AI Search enabled", panel.status_code,200)
    tree = BeautifulSoup(panel.text,"html.parser")
    button=tree.select_one("form[action='/kb/ai-search'] input[type=submit]")
    assert button is not None and not button.has_attr("disabled")
    assert "no-store" in panel.headers.get("Cache-Control","")
    bad = client.post(BASE+"/kb/ai-search",
        data={"authenticity_token":csrf_from(panel.text,"/kb/ai-search"),
              "privacy_confirmed":"1", "query":"Email person@example.com about this synthetic issue"},
        timeout=15)
    check(tenant+" PII blocked before GPU",bad.status_code,422)

report = {"status":"PASS_PRIVATE_PREVIEW_GATE_RAILS_UI_NO_GPU",
          "captured_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "origin":BASE,
          "checks":checks,
          "preview_password_exposed":False,
          "gpu_calls":0}
out = Path("/content/Rails-8-AI-Customer-Support-Desk/evidence-m2-rails-ui-live-20261029")
out.mkdir(parents=True,exist_ok=True)
(out/"preview-gate-acceptance.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"status":report["status"],"count":len(checks),
                  "statuses":[(x["check"],x["http_status"]) for x in checks],
                  "gpu_calls":report["gpu_calls"]},indent=2))
