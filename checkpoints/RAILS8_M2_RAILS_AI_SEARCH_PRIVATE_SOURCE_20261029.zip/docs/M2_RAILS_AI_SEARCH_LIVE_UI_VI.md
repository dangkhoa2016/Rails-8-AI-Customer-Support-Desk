# M2 — Rails AI Search: kiểm thử live qua Colab (VI)

Ngày 2026-10-29. Dự án `/content/Rails-8-AI-Customer-Support-Desk`, Desktop Commander device `306682c8dabe`, Rails 8 + PostgreSQL. Modal profile `bsmith888`, environment `rails-8-ai-customer-support-desk`. Không reset database, không chạy lại M0/M1 hoặc 84-vector ingestion.

## Đã chạy thực tế

- Rails dev server lắng nghe **chỉ** `127.0.0.1:3068`, không dùng Cloudflare tunnel. `M2_SEMANTIC_UI_ENABLE=YES` và hai bộ Modal proxy/bearer credentials (lưu ngoài repository).
- Kiểm thử từ HTML form Rails (POST + CSRF) → **Qwen3-Embedding-4B (2560 chiều)** → PostgreSQL exact cosine với tenant/ACL/locale/approval filters → **Qwen3-Reranker-4B** → Top-5 citations; hai model chạy thật trên Modal A10G.
- 2/2 trường hợp PASS Top-1:
  - TeamFlow Cloud synthetic agent, VI: `TF-KB-012`, 5 chunks, **43.692 ms** request đầu (có thể bao gồm scale-to-zero/cold start).
  - NovaMart Store synthetic agent, EN: `NM-KB-014`, 5 chunks, **1.578 ms** (warm).
- Evidence: `evidence-m2-rails-ui-live-20261029/rails-ui-live-results.json`; chỉ lưu mã article, citations, query SHA256, latency và locale, không lưu credential.
- Rails regression: **40 tests / 475 assertions**, zero failures/errors/skips. Database: 100 articles, 12 approved v2, 84 embeddings; giữ nguyên.
- Script `script/verify_m2_rails_ui_live.py` đã sửa để chọn CSRF token **theo form `/kb/ai-search`**, không lấy nhầm token của form sign-out. Không tắt CSRF.

## Cách mở UI trong phiên Colab của chính bạn

Ứng dụng dùng **demo login không mật khẩu** cho tenant synthetic nên KHÔNG mở trên Cloudflare Quick Tunnel. Tôi đã bổ sung lớp **HTTP Basic Auth bắt buộc** cho private preview, ngoài demo login. Password được sinh ngẫu nhiên và lưu ngoài repo trong `~/.config/rails8-support-desk-modal/rails-private-preview.env`, permission 0600. Rails chỉ nhận Colab-proxy hostname riêng cho port 3068 và localhost khi bật gate.

Trong notebook Colab hiện đang kết nối runtime đó, chạy một cell:

```python
%run /content/Rails-8-AI-Customer-Support-Desk/script/open_private_ai_search_colab.py
```

Cell sẽ kiểm tra Rails có trả **HTTP 401** khi thiếu Basic Auth trước khi mở Colab port window. Khi trình duyệt yêu cầu đăng nhập Basic Auth:

- **Username:** `support-preview`
- **Password:** đọc riêng trong Colab terminal từ `~/.config/rails8-support-desk-modal/rails-private-preview.env` (trường `RAILS_PRIVATE_PREVIEW_PASSWORD`). **Không gửi giá trị vào chat, không commit, không chia sẻ proxy URL.** Nếu cần hiển thị trong notebook, xóa output sau khi copy.
- Tiếp tục chọn `TeamFlow Cloud / Synthetic TF agent` hoặc `NovaMart Store / Synthetic NM agent`, chọn VI/EN, nhấn sign in, sau đó chọn **AI Search**.

Nếu Colab proxy không hoạt động trong browser, không thay bằng public tunnel. Giữ Rails ở loopback và dùng port forwarding đã xác thực hoặc kiểm tra cơ chế proxy Colab.

### Câu hỏi demo

- VI (TeamFlow): *Hóa đơn đã thanh toán nhưng gói TeamFlow chưa kích hoạt, cần xác minh những gì?*
- EN (NovaMart): *Does an order of VND 499,999 qualify for free standard shipping?*

Không nhập dữ liệu khách thật/PII. Form yêu cầu xác nhận synthetic-only trước khi gọi Modal.

## Điều kiện vận hành và giới hạn

- Khi server hoặc Colab runtime dừng, UI dừng; Modal model endpoints chạy độc lập, có thể phát sinh chi phí khi truy cập được phép.
- Private Basic Auth hiện chỉ áp dụng khi dev server khởi chạy với `RAILS_PRIVATE_PREVIEW=YES`; server hiện đang chạy ở chế độ này. Đây là lớp bảo vệ bổ sung cho demo, **không thay thế production authentication**.
- Session request limit của UI không phải distributed rate limiter; thêm quota/cost guard và user authentication thật trước production.
- Browser access qua Colab proxy chưa được kiểm thử từ tab của người dùng trong phiên chat; chỉ xác minh qua localhost + Basic Auth. Không khẳng định proxy URL là private tuyệt đối nếu người dùng chia sẻ URL.
- Không push GitHub, không tạo approval mới hoặc viết dữ liệu nghiệp vụ. Không coi pilot nhỏ là benchmark production.
