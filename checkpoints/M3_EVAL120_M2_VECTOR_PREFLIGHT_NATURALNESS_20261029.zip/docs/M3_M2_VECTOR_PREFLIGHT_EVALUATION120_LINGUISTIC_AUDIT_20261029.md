# M3 follow-up — Historical M2 vector precheck and 120 evaluation candidates
Date: 2026-10-29

## Vietnamese

### Authority and status
- 64/64 claims are accepted for **synthetic demonstration**. Dual independent reviewers are not required for this demo.
- Keep M0 policies, M1 relational evidence, M2 approved 12 KB v2 and accepted M3 240 tickets unchanged.
- The **sealed80 answerability gate is BLOCKED** (3 FP; supported recall 0.70). AI remains assist-only and cannot make business writes or send automatic replies.

### Historical embeddings
- Verified frozen backup: `checkpoints/M2_DUAL_QWEN3_4B_REAL_EMBEDDINGS_DB_20261029.dump`
- Source dump SHA256: `9b6a218943b81d35ba61e60c92bfea6d171ca9c49517371e6ddedd18e6d0c4ae`, matching the historical M2 checkpoint.
- 84 vectors, Qwen/Qwen3-Embedding-4B revision `5cf2132abc99cad020ac570b19d031efec650f2b`, 2560 dimensions.
- Historical tenant IDs 3/4 **differ from current tenant IDs 1/2**. Direct ID-based restore is prohibited.
- Read-only dry-run `script/restore_m2_pinned_embeddings.rb` verified all 84 mapped to the 84 currently approved KB chunks using tenant slug, article key, locale, version, chunk index and content SHA256.
- **Actual DB restore NOT_RUN.** This script is preflight-only and intentionally performs no vector insert, even with an opt-in flag. Fresh DB still has zero verified recovered M2 vectors. Modal GPU inference was not run. Do not claim semantic search live until vectors and private proxy are revalidated.

### Separate 120 test cases
- Generator: `script/build_m3_evaluation_candidates.py`; dataset `data/m3_support_evaluation_candidates_120.json`.
- 120 unique authored bilingual questions over all 12 approved article versions, grouped into 48 policy-retrieval, 36 needs-case-evidence, 36 unsafe-or-unsupported-claim prompts.
- TeamFlow: 20 VI and 20 EN cases; NovaMart: 40 VI and 40 EN cases. This follows the number of approved article versions (4 TeamFlow vs 8 NovaMart), **not a tenant-balanced production benchmark**.
- Source snapshot SHA256: `12cb87609c5de1c082e692648e55615785b31f5faf84c280bfaaa1fd0a15695f`.
- Candidates are **NOT semantic gold**, do not have independent reviewer labels, model outputs, or benchmark scores. They are not permission to bypass answerability.
- Regression: `python3 test/test_m3_evaluation_candidates.py` — 6/6 PASS.

### Ticket language audit
- `script/audit_m3_ticket_naturalness.py` created `evidence-m3-synthetic-tickets-20261029/naturalness-audit.json`.
- Across 240 ticket customer messages, 222 distinct literal strings but only **22 distinct masked sentence patterns**. This reflects reference/status substitution rather than rich human-like language.
- Dataset `data/m3_synthetic_tickets.json` retains SHA256 `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd` and was not changed.
- Next step: create a separate proposed richer multi-turn ticket corpus with more voices, context variation and verified relationships; human spot-check before any import. Do not silently replace the accepted M3 baseline.

### Still pending
- Transactional vector recovery after a verified, auditable restore procedure; private Modal proxy configuration and actual relevance-only Rails search tests.
- Independent adjudication of candidate evaluation cases; calibration/acceptance metrics. This is not a production-level benchmark.
- Review and approve more natural ticket variants separately. No Git commit/push in this work stage.

## English

### Scope
The owner-approved 64 claims remain accepted as synthetic demo data only. The M0/M1/M2 baselines and 240 M3 tickets are unchanged. Sealed80 answerability is still **BLOCKED**; AI remains assist-only.

### M2 vector backup verification
The historical M2 dump (SHA256 `9b6a218943b81d35ba61e60c92bfea6d171ca9c49517371e6ddedd18e6d0c4ae`) contains 84 Qwen3-Embedding-4B vectors at 2560 dimensions, revision `5cf2132abc99cad020ac570b19d031efec650f2b`. Old tenant IDs 3/4 do not match current IDs 1/2. A **read-only** source-to-target mapping verified 84/84 approved KB chunks by tenant slug, article key, locale, chunk index and SHA256. **Restoration was NOT_RUN** and must not be represented as successful DB or live search acceptance.

### Evaluation dataset and quality caveat
The separate 120-question VI/EN corpus is drawn from 12 approved v2 KB snapshots: 48 policy retrieval, 36 requests lacking case evidence, and 36 unsafe/unsupported instructions. TeamFlow has 40 and NovaMart 80 questions, reflecting the 2-vs-4 approved article topics per tenant. The six independent offline tests PASS. These are *evaluation candidates only*, not reviewed ground-truth responses or measured AI results.

The unchanged M3 ticket dataset has 222 unique literal customer-intake messages but just 22 masked text templates. This is useful as synthetic functional demo data, not a representative conversation benchmark. Proposed language enrichment must be versioned separately and manually spot-checked.

### Next continuation point
Implement safe transactional 84-vector restore based on the verified identity mapping, validate backfilled pgvector dimensions and content SHA, then run private read-only Rails AI Search evaluation without enabling answerability. Separately adjudicate the 120 evaluation candidates, and draft richer multi-turn synthetic tickets without modifying the frozen M3 dataset.
