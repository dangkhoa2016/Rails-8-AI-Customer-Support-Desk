# M2 — Cloudflare Quick Tunnel for Rails AI Search (EN)

Date: October 29, 2026. Status: **running and independently tested**, not a future plan.

## Purpose

Allow the operator to open Rails AI Search from a normal browser, bypassing unreliable Google Colab iframe/proxy behavior without changing local DNS settings. This is a **temporary** Cloudflare Quick Tunnel, not production access. The generated URL is ephemeral and is not hard-coded in source.

## Deployment and safety boundaries

- Rails remains bound to `127.0.0.1:3068` with no open inbound port.
- Cloudflared v2026.10.5 maps a temporary `trycloudflare.com` HTTPS hostname to that private Rails service. Only the **exact** generated hostname is permitted, configured outside the repository in `~/.config/rails8-support-desk-modal/rails-preview-tunnel.env`. The legacy wildcard Cloudflare host allowlist was removed.
- Tunnel lifetime is capped at **7,200 seconds (two hours)** with `timeout`, or ends earlier when Colab stops. The unrelated static KB preview tunnel on port 8786 is unaffected.
- Access requires a strong password at `/__private_preview/sign_in`; preview cookies are HMAC-signed, time-limited, HttpOnly and Secure on HTTPS. The password stays in a private local file outside source control.
- For tunnel traffic, only synthetic demo sign-in/out and POST AI Search may write to server routes. Ticket creation, KB approval and all other mutations return HTTP **405**, irrespective of selected demo role.
- A single-process, **40-POST global search budget** limits potential GPU use through this temporary tunnel. It is not production-grade distributed rate limiting; restarting Rails resets this count.
- Both Modal Qwen3-Embedding-4B and Qwen3-Reranker-4B endpoints retain their independent proxy- and bearer-token protections. No real customer data is authorized.

## Actual verification

- Public HTTPS password form GET **200**; protected resources without a session redirect **303** to the password gate.
- Wrong password rejected; correct password grants signed cookie; synthetic TeamFlow agent signs in and AI Search loads **200**.
- KB approval and ticket creation are blocked with **405**, email/PII query rejected with **422**.
- **One real synthetic Vietnamese test through the public Cloudflare URL → Rails → Embedding-4B → PostgreSQL → Reranker-4B** ranked `TF-KB-012` at Top-1, returned 5 snippets, and completed in about **38.72 seconds** end-to-end (may include GPU cold start).
- Full Rails regression **45 tests, 553 assertions, zero failures/errors/skips**.
- Database preserved: **100 articles / 12 approved KB versions / 84 real embeddings**.
- Test artifacts are in `evidence-m2-cloudflare-preview-20261029/`; they exclude credentials, cookies and full question contents.

## Open and test

1. Open the HTTPS Quick Tunnel URL supplied in this conversation. No Colab iframe or DNS edits are required.
2. Enter the **existing preview password only**; no username. Read `RAILS_PRIVATE_PREVIEW_PASSWORD` privately from the protected Colab environment file.
3. Sign in as a synthetic TeamFlow/NovaMart agent and select **AI Search**.
4. Use synthetic questions only, attest the question contains no PII, and search.
5. Stop the Cloudflare Tunnel when you are finished; the URL will cease working.

**Not production:** The URL is reachable from the Internet, even though content is password-gated. Never share the secret or enter real customer data. Quick Tunnels have no uptime SLA.
