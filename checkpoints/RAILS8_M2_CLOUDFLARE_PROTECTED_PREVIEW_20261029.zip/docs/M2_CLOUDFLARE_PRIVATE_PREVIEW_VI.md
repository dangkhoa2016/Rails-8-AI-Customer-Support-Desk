# M2 — Cloudflare Quick Tunnel cho Rails AI Search (VI)

Ngày: 2026-10-29. Trạng thái: **đã chạy và kiểm chứng trực tiếp**, không phải kế hoạch.

## Mục đích

Cho người vận hành thử Rails AI Search từ trình duyệt thông thường, không phụ thuộc Google Colab iframe/proxy, Secure DNS hoặc cài thêm công cụ trên máy cá nhân. Sử dụng Cloudflare Quick Tunnel **tạm thời**, hostname thay đổi mỗi lần khởi động và **không dùng cho production**. Mã nguồn không ghi cứng URL tạm thời.

## Triển khai

- Rails lắng nghe duy nhất tại `127.0.0.1:3068`, không mở cổng inbound.
- Cloudflared v2026.10.5 chuyển tiếp `https://<temporary>.trycloudflare.com` đến Rails localhost. Chỉ kết nối tới hostname chính xác đã lưu ở `~/.config/rails8-support-desk-modal/rails-preview-tunnel.env`; không sử dụng wildcard host.
- Cloudflare tunnel tự tắt sau tối đa 7.200 giây (2 giờ) nhờ `timeout`, hoặc sớm hơn nếu Colab dừng. Tunnel static KB (port 8786) là dịch vụ độc lập, không được sửa.
- Trang mật khẩu `/__private_preview/sign_in` chặn toàn bộ ứng dụng khi chưa xác thực, HMAC signed cookie 1 giờ, httpOnly, secure trên HTTPS. Mật khẩu ở `~/.config/rails8-support-desk-modal/rails-private-preview.env` (không xuất mật khẩu ra tài liệu).
- Với host tunnel: chặn toàn bộ HTTP write ngoại trừ đăng nhập demo, đăng xuất và POST AI Search. **Duyệt KB / tạo ticket / cập nhật dữ liệu nghiệp vụ bị HTTP 405**, bất kể vai trò được chọn trên trang demo.
- Giới hạn tổng số POST AI Search qua tunnel **40 yêu cầu trong tiến trình Rails**, nhằm đặt trần cho chi phí GPU ở bản preview. Đây là giới hạn cục bộ, không phải hệ thống rate limiting phân tán production; restart Rails sẽ reset bộ đếm.
- Hai endpoint Modal Qwen3-Embedding-4B / Qwen3-Reranker-4B vẫn yêu cầu cả Modal Proxy Token và application bearer token. Dữ liệu customer thực tuyệt đối không gửi sang Modal.

## Kiểm chứng thực tế

- Public HTTPS gate GET `200`; chưa có session truy cập `/tickets` bị redirect `303` đến gate.
- Sai mật khẩu bị từ chối; mật khẩu đúng nhận cookie; đăng nhập demo agent TeamFlow và mở AI Search `200`.
- Request phê duyệt KB và tạo ticket bị `405`; truy vấn chứa email bị `422`.
- **Một câu VI synthetic đã chạy thật qua URL Cloudflare → Rails → Embedding-4B → pgvector → Reranker-4B**: đúng `TF-KB-012` Top-1, 5 chunks, request end-to-end khoảng **38,72 giây** (có thể gồm cold start).
- Regression Rails **45 tests, 553 assertions, 0 failures/errors/skips**.
- DB giữ nguyên: **100 KB articles / 12 approved versions / 84 real embeddings**.
- Evidence ở `evidence-m2-cloudflare-preview-20261029/`, không lưu password, app token, cookie hoặc câu hỏi raw.

## Hướng dẫn sử dụng

1. Mở URL HTTPS Quick Tunnel vừa được gửi trong cuộc trò chuyện. Không cần cài DNS hay chạy Colab iframe.
2. Nhập **mật khẩu preview đã có** (chỉ mật khẩu, không có username). Lấy từ `RAILS_PRIVATE_PREVIEW_PASSWORD` ở file private trên Colab.
3. Chọn `TeamFlow Cloud / Synthetic TF agent` hoặc `NovaMart Store / Synthetic NM agent`, đăng nhập và chọn `AI Search`.
4. Nhập một câu hỏi giả lập và tick xác nhận không có PII rồi Search.
5. Khi không dùng nữa, dừng tiến trình Cloudflare Tunnel. URL sẽ không còn hoạt động.

**Giới hạn:** URL tunnel vẫn là một địa chỉ Internet. Không chia sẻ mật khẩu, không gửi dữ liệu khách thật, không gọi đây là authentication production. Cloudflare Quick Tunnel không có SLA.
