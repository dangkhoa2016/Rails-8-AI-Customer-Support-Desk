Rails.application.configure do
  config.enable_reloading = true
  config.eager_load = false
  config.consider_all_requests_local = true
  config.action_controller.perform_caching = false
  config.active_support.deprecation = :log
  config.active_record.verbose_query_logs = true
  config.action_mailer.default_url_options = { host: 'localhost', port: 3000 }
  config.hosts << /.*\.trycloudflare\.com/ if ENV['ALLOW_QUICK_TUNNEL'] == 'YES'
  # Opt-in private demo gate for viewing via an authenticated Colab notebook.
  # Never enables Cloudflare access or weakens synthetic demo sign-in restrictions.
  if ENV['RAILS_PRIVATE_PREVIEW'] == 'YES'
    require Rails.root.join('lib/private_colab_preview_gate')
    password = ENV.fetch('RAILS_PRIVATE_PREVIEW_PASSWORD')
    raise 'Private preview password is too short' if password.bytesize < 30
    config.middleware.insert_before 0, PrivateColabPreviewGate, password: password
    # Colab port proxy hostname for port 3068 only, not arbitrary public domains.
    config.hosts << /\A[a-z0-9-]+-3068-colab\.googleusercontent\.com\z/
    # New Colab HTTPS port proxy: 3068-<session>.<region>.prod.r.colab.dev.
    # Anchor to THIS PORT and the Colab-specific domain; never allow arbitrary hosts.
    config.hosts << /\A3068-[a-z0-9-]+\.[a-z0-9-]+\.prod\.r\.colab\.dev\z/
  end
end
