# M2 — Sửa truy cập Colab iframe (2026-10-29)

## Nguyên nhân

URL Google Colab sinh ra từ `serve_kernel_port_as_window(3068)` có dạng `https://3068-<session>.<region>.prod.r.colab.dev`. Google Colab đã deprecate chức năng mở cửa sổ ngoài vì hạn chế bảo mật trình duyệt. Cấu hình Rails cũ chỉ nhận hostname `googleusercontent.com`, không khớp Colab `prod.r.colab.dev`. Ngoài ra Chrome thường chặn hộp thoại HTTP Basic Auth trong iframe khác origin.

## Thay đổi hoàn tất

- Rails development `127.0.0.1:3068` với `M2_SEMANTIC_UI_ENABLE=YES`, không mở Cloudflare Tunnel.
- `config/environments/development.rb` chấp nhận **chỉ** host Colab port `3068` thuộc `prod.r.colab.dev` hoặc host Colab legacy, không mở wildcard tùy ý.
- Đổi từ HTTP Basic Auth prompt sang **trang nhập mật khẩu preview** (`/__private_preview/sign_in`), phù hợp với iframe. Mật khẩu mạnh **không đổi**, vẫn lấy từ file ngoài repository `~/.config/rails8-support-desk-modal/rails-private-preview.env`, permission 0600.
- Cookie đăng nhập preview được HMAC SHA256 xác thực, có hạn 1 giờ, HttpOnly. Cookie dành cho Colab HTTPS có `Secure; SameSite=None; Partitioned`. Token CSRF và cookie session dùng **mục đích chữ ký khác nhau**, không được sử dụng lẫn nhau. Có giới hạn đăng nhập sai, kiểm tra Origin và Host.
- Phiên Rails synthetic demo trên Colab dùng `Partitioned` session cookie để hỗ trợ iframe. Bỏ `X-Frame-Options: SAMEORIGIN` **chỉ trong chế độ private preview**, thay bằng CSP `frame-ancestors` cho các origin Colab.
- `script/open_private_ai_search_colab.py` chuyển sang `output.serve_kernel_port_as_iframe(3068, path='/__private_preview/sign_in', height='950')`.

## Nghiệm thu trực tiếp

- Trang preview GET localhost `200`; app không có cookie → redirect `303` đến preview gate.
- Mật khẩu không hợp lệ không cấp cookie; mật khẩu đúng → `303` và cookie hợp lệ, mở được Rails.
- TeamFlow Cloud VI và NovaMart Store EN: đăng nhập preview, chọn synthetic agent, mở AI Search `200`, reject PII-email `422`, **0 GPU calls** trong vòng kiểm tra gate.
- Rails full regression **43 tests, 502 assertions, 0 failures, 0 errors, 0 skips**. Trong đó có test không chấp nhận dùng hidden CSRF nonce làm cookie phiên.
- Database giữ nguyên **100 articles / 12 approved KB versions / 84 embeddings**.
- **Chưa xác minh từ browser của người dùng**: cookie/trình duyệt Colab có thể chịu cấu hình chặn third-party cookies. Không tuyên bố iframe đã hiển thị thành công trên thiết bị người dùng.

## Hướng dẫn mở từ notebook hiện tại

Chạy cell:

```python
%run /content/Rails-8-AI-Customer-Support-Desk/script/open_private_ai_search_colab.py
```

Khi xuất hiện **khung đăng nhập Private Colab preview**, nhập **chỉ mật khẩu**, không nhập username. Lấy riêng giá trị `RAILS_PRIVATE_PREVIEW_PASSWORD` ở `~/.config/rails8-support-desk-modal/rails-private-preview.env` trên Colab; không dán vào chat hoặc notebook output công khai.

Sau đó chọn `TeamFlow Cloud / Synthetic TF agent` hoặc `NovaMart Store / Synthetic NM agent`, chọn VI/EN, rồi vào **AI Search**.

Nếu khung vẫn trắng hoặc hiện 403: kiểm tra browser cho phép cookie của Colab (`colab.research.google.com` và các subdomain Colab đang dùng), cho phép site data/third-party cookies cho Colab nếu trình duyệt hỗ trợ, rồi chạy lại cell. Không chuyển sang public Cloudflare tunnel, không tắt preview password.

## Tiếp tục

Giữ Rails loopback only. Chưa bật authentication production, rate limit phân tán hoặc DLP; tuyệt đối không dùng dữ liệu khách thật. M0/M1, embeddings, approval, 4B model deployments không bị thay đổi.
