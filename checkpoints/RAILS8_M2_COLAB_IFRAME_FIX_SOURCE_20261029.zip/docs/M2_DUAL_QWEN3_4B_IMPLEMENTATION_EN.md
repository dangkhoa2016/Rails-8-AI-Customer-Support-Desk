> **Historical setup plan:** GPU deployment and 84-vector ingestion subsequently completed on 2026-10-29. See `M2_DUAL_QWEN3_4B_LIVE_ACCEPTANCE_EN.md` for current results and actual Hugging Face-pinned source after Kaggle large-shard error.

# M2 — Qwen3 4B Embedding + Reranker (EN)

**Checkpoint:** October 29, 2026 · Rails 8 AI Customer Support Desk.

## Verified state

- Approved M0 policy v1.0.0 and M1 business records remain unchanged.
- The user reviewed and accepted 12 bilingual v2 drafts in the preview. The approval was executed by delegation using each tenant's **synthetic demo owner membership**, through `KnowledgePublication.approve!` and 12 audit records. Audits explicitly include `approval_origin=user_chat_confirmation_2026_10_29` and `audit_actor_kind=synthetic_demo_tenant_owner`. The user is not falsely represented as directly signing in.
- Development DB: 100 articles, 200 v1 drafts, 12 v2 approved, 84 active approved chunks (TeamFlow 28, NovaMart 56). **No actual embeddings yet.**
- Migration `20261029020000_use_qwen3_embedding_4b_native_dimensions.rb` changes empty embedding storage to `vector(2560)`. Both development/test migrations passed. It refuses to change dimensions if any embeddings are present; original migration history stays intact.
- Rails security tests use synthetic vectors and rerank logits. Modal SDK source import passed; actual GPU inference, model runtime and billed GPU cost remain **NOT_RUN**.

## Selected models and pinned revisions

| Stage | Official model | Pinned revision | Configuration |
|---|---|---|---|
| Embedding | `Qwen/Qwen3-Embedding-4B` | `5cf2132abc99cad020ac570b19d031efec650f2b` | 2560-dimensional cosine exact, dedicated A10, 2048-token pilot cap |
| Reranking | `Qwen/Qwen3-Reranker-4B` | `22e683669bc0f0bd69640a1354a6d0aebcfeede5` | CrossEncoder raw logits, separate A10, 2048-token pilot cap |

Revisions were verified by remote `git ls-remote` on October 29, 2026; they are **candidate runtime pins**, not downloaded model validation evidence. The former 0.6B proposal has been superseded. Although both models support ~32K context, the pilot intentionally caps tokens to reduce GPU memory exposure. The pgvector exact search baseline is preferred for just 84 vectors; a 2560-dimensional vector exceeds conventional `vector` HNSW indexing limits.

## Retrieval and authorization

1. `KnowledgeEmbeddingIngestion` sends only SHA-matching approved/active tenant-scoped KB chunks to the embedding endpoint.
2. `KnowledgeSemanticRetrieval` filters tenant, role/audience, locale, policy revision, current validity and content SHA **inside PostgreSQL before reranking**.
3. `KnowledgeRerankedRetrieval` forwards only up to 12 filtered candidates to the reranker. It preserves citations and cosine distance while sorting by the reranker's descending raw logit score. It requires `query_privacy_reviewed: true`; do not send raw customer tickets/PII.
4. Modal endpoints enforce bearer secrets and return model ID, revision, and input digests. No AI business mutations.
5. Original 200 v1 drafts remain ineligible for retrieval.

## Deploying on Modal (NOT YET EXECUTED)

The current Colab Desktop Commander device is not authenticated to Modal. The user must authorize the account on that device, e.g. with `/tmp/rails8-modal-check-uv/bin/modal token new`. Do **not** paste credentials into chat, shell history or Git. Create Modal dashboard Secret `rails8-support-desk-ai` containing two independent random endpoint tokens `EMBED_API_TOKEN` and `RERANK_API_TOKEN` (20+ characters).

Once authenticated:
```bash
cd /content/Rails-8-AI-Customer-Support-Desk
/tmp/rails8-modal-check-uv/bin/modal deploy modal_app/qwen3_embedding_service.py
/tmp/rails8-modal-check-uv/bin/modal deploy modal_app/qwen3_reranker_service.py
```

Copy the **actual returned deployment URLs** into the protected Rails environment as `MODAL_EMBEDDING_URL` and `MODAL_RERANK_URL`. Set `MODAL_EMBEDDING_TOKEN` and `MODAL_RERANK_TOKEN` to the corresponding secret values. Do not guess URLs or commit tokens.

Read-only offline dry-run:
```bash
set -a; source .env.notebook; set +a
bin/rails runner script/m2_dual_4b_pilot.rb
```

Real pilot once both endpoints are deployed and funded:
```bash
M2_GPU_RUN=YES bin/rails runner script/m2_dual_4b_pilot.rb
```

It processes batches of up to 8 authorized chunks (84 in total), then benchmarks 12 bilingual synthetic queries. Outputs contain case IDs, query SHA256s, timings, citation IDs and Recall@5/MRR@5. Confirm GPU costs before opting in.

## Measured results and remaining gates

- **Real PostgreSQL lexical baseline:** Recall@8 = 0/12, MRR@8 = 0 for the curated small pilot set. This is not statistically representative of the larger dataset.
- **Qwen3-Embedding-4B + Reranker-4B inference results:** NOT_RUN. Fake-vector security tests do not establish model relevance or runtime performance.
- Pilot acceptance requires actual Modal model execution, 84 ingested 2560-dimensional vectors, idempotent ingestion, VI/EN ranking results, isolation and citation evidence, pinned runtime revision, latency and billed-cost evidence.
- As of October 29, 2026, Modal lists A10 GPU compute around USD 0.000306 per GPU-second (not including CPU/RAM/storage or model startup). Functions scale to zero and cap at one container each.

## Key files

`modal_app/qwen3_embedding_service.py`, `modal_app/qwen3_reranker_service.py`, `app/services/modal_reranker_client.rb`, `app/services/knowledge_reranked_retrieval.rb`, `script/m2_dual_4b_pilot.rb`, `script/m2_lexical_baseline.rb`, `review/m2_dual_qwen3_4b_pilot_queries.json`.

**Current blocker:** Modal token info returns exit 1. No GPU deployment or actual model embeddings have been produced on this device.
