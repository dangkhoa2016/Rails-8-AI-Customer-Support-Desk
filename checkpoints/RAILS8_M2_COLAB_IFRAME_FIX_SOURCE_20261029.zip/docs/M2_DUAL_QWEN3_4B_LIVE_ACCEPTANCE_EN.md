# M2 Live AI Acceptance — Qwen3-Embedding-4B + Qwen3-Reranker-4B

**Date:** October 29, 2026 (UTC evidence). **Modal profile:** `bsmith888`. **Environment:** `rails-8-ai-customer-support-desk`. **Colab project:** `/content/Rails-8-AI-Customer-Support-Desk`.

## Verified system state

- M0 and M1 preserved unchanged, with no business record reseeding or DB reset.
- Exactly 12 approved bilingual v2 KB versions (six articles) and 200 remaining draft v1 versions; **84 real 2,560-dimensional embedding vectors** stored in PostgreSQL/pgvector.
- TeamFlow Cloud has 28 vectors; NovaMart Store has 56.
- Embedding-4B and Reranker-4B are separately deployed as Modal A10G Web Functions, max one container per function; model weights persist on Modal Volume `rails8-qwen3-4b-models`. Model endpoint application secrets are in `rails8-support-desk-ai`, not source control.
- Both models **actually executed GPU inference**, not synthetic test-only predictions.

## Kaggle mirrors examined and upstream fallback

The owner provided local Kaggle credentials in `~/.kaggle/access_token`. The token was used only for Kaggle metadata access on Colab and **was not uploaded to Modal**.

| Model | Public Kaggle variation | Version and size | Actually loaded runtime origin |
|---|---|---|---|
| Qwen3-Embedding-4B | `dangkhoa2016/qwen-qwen3-embedding-4b/transformers/default/1` | 975642, ~8.06 GB | Official HF `Qwen/Qwen3-Embedding-4B@5cf2132abc99cad020ac570b19d031efec650f2b` |
| Qwen3-Reranker-4B | `dangkhoa2016/qwen-qwen3-reranker-4b/transformers/default/1` | 975637, ~8.06 GB | Official HF `Qwen/Qwen3-Reranker-4B@22e683669bc0f0bd69640a1354a6d0aebcfeede5` |

The Kaggle metadata matches the pinned upstream model revisions and contains complete Safetensors/config/tokenizer files. Public download of small config files succeeded without credentials, but the large-shard Kaggle API returned `1994`. The cache was completed from official Hugging Face at the exact pinned revisions using a CPU Modal function, with per-file SHA256 evidence. **Do not claim the runtime model bytes were sourced wholly from Kaggle.**

- Embedding model evidence: `evidence-m2-dual-qwen3-4b-runtime/embedding-model-manifest.json`, SHA256 `6f9dd9c01b6e19906af92e3759751787e402f73cd5ae9aa76eacf23c90e739fc`, 14 files / 8,059,521,975 bytes.
- Reranker evidence: `evidence-m2-dual-qwen3-4b-runtime/reranker-model-manifest.json`, SHA256 `42e6addea0b2a0c3170b8851d65a9ece83708bbfc6b55a307c51a915c1de47b6`, 17 files / 8,059,548,421 bytes.
- 8B variants require more resources; GGUF variants require a different runtime and cross-encoder scoring path. Neither was used or benchmarked in this pilot.

## Real Modal GPU smoke tests

- Embedding-4B: output dimensions **2560**, vector norm ~1.00035, first end-to-end request **22.31 s**.
- Reranker-4B: raw logits `[6.4609375, -4.078125]` for relevant/unrelated synthetic snippets; first end-to-end request **22.24 s**.
- Detailed synthetic prompt SHA256s in `evidence-m2-dual-qwen3-4b-runtime/{embedding,reranker}-smoke.json`.

## Bilingual evaluation

- Curated dataset: `review/m2_dual_qwen3_4b_pilot_queries.json` with 12 independently authored synthetic VI/EN questions for six approved articles. No customer data.
- Actual PostgreSQL lexical baseline: Recall@8 **0/12**, MRR@8 **0.0**; this is a naive whole-query search, **not** an optimized lexical or hybrid search baseline.
- Live Embed-4B → pgvector exact cosine → Reranker-4B: **Top1 12/12**, Recall@5 **1.0**, MRR@5 **1.0**. Median query latency **1,478 ms**, minimum 1,410 ms, maximum 1,795 ms. Full ingestion + 12-query wall time **31.82 s** excluding model downloads and cold-start smoke tests.
- Generalization to all 100 KB articles, real tickets, or statistically reliable production accuracy: **NOT ESTABLISHED**.

## Authorization, repeatability and billing

- Rails regression: **34 tests, 402 assertions, zero failures/errors/skips**.
- Real DB acceptance via `script/verify_m2_dual_4b_live.rb` passed tenant, ACL/role, locale, approved-only status, digest and revision checks, and 84 vectors.
- Idempotency: rerunning the ingestion selector with a no-call test client produced **0 additional vectors and 0 GPU calls**.
- Web Functions validate application-layer bearer tokens and mount a private Modal Secret; **Modal dashboard still labels them `Unauthenticated` at the proxy layer**. Add Modal proxy auth/rate limiting before production access to avoid unwanted GPU cold starts from rejected requests. Do not expose the passwordless demo Rails app.
- Modal environment billing snapshot taken October 29, 2026 at **04:02:14 UTC**: **USD 0.34852788 metered cost** so far, including image deployments, downloads, GPU inference and network egress. This is a point-in-time environment summary, not per-query price or final invoice.

## Relevant source and evidence

- `modal_app/qwen3_embedding_service.py`, `modal_app/qwen3_reranker_service.py`, `modal_app/cache_models_hf_fallback.py`.
- `app/services/modal_embedding_client.rb`, `modal_reranker_client.rb`, `knowledge_embedding_ingestion.rb`, `knowledge_semantic_retrieval.rb`, `knowledge_reranked_retrieval.rb`.
- `script/m2_modal_4b_smoke.rb`, `script/m2_dual_4b_pilot.rb`, `script/verify_m2_dual_4b_live.rb`.
- `evidence-m2-dual-qwen3-4b-live/pilot-results.json`, `evidence-m2-dual-qwen3-4b-runtime/`.

**Milestone:** The M2 4B+4B pilot is genuinely deployed and measured, but full M2 editorial coverage and M3 tickets/evaluation are not complete. Next actions include broader independent retrieval evaluation, proxy-level authentication and reliable production monitoring. Keep seeds, checksums, environment/GPU, parallelism, input hashes and raw execution evidence for review.
