> **UPDATE 2026-10-29 — Colab iframe:** The Basic Auth/port-window instructions below are superseded. See `M2_COLAB_IFRAME_ACCESS_FIX_EN.md`. The current preview uses a dedicated password form and `serve_kernel_port_as_iframe`, with no `support-preview` username.

# M2 — Rails AI Search: live Colab verification (EN)

Date: October 29, 2026. Project `/content/Rails-8-AI-Customer-Support-Desk`, Desktop Commander `306682c8dabe`, Rails 8 + PostgreSQL. Modal account `bsmith888`, environment `rails-8-ai-customer-support-desk`. M0/M1 and 84 existing embeddings were not re-imported.

## Actually verified

- Development Rails server is bound **only to `127.0.0.1:3068`**, with `M2_SEMANTIC_UI_ENABLE=YES`. No Cloudflare tunnel was opened.
- Full real path: browser-style Rails HTML form POST + CSRF → **Qwen3-Embedding-4B**, 2560-dimensional query → tenant/ACL/approved/locale-filtered PostgreSQL cosine exact search → **Qwen3-Reranker-4B** → Top-5 with citations. Both model calls executed on Modal A10G GPUs with app-bearer and Modal-proxy authentication.
- 2/2 synthetic queries retrieved the correct article at Top-1:
  - TeamFlow synthetic agent, Vietnamese: `TF-KB-012`, five chunks, **43,692 ms** including possible GPU cold startup.
  - NovaMart synthetic agent, English: `NM-KB-014`, five chunks, **1,578 ms** warm.
- Evidence `evidence-m2-rails-ui-live-20261029/rails-ui-live-results.json` records only article IDs, query SHA256, citation IDs, locale and timing, not credentials.
- Full Rails security regression: **40 tests, 475 assertions, zero failures/errors/skips**. Database preserved at 100 articles, 12 approved KB versions, 84 embeddings.
- The HTTP browser test script now selects the CSRF token from the **correct search form**, instead of the separate sign-out form; Rails CSRF security has not been weakened.

## Open the UI from your own active Colab notebook

Do **not** expose the passwordless synthetic Rails sign-in using Cloudflare Quick Tunnel. A separate strong **HTTP Basic Auth gate** is now enabled for private preview with a random credential stored outside the repo in `~/.config/rails8-support-desk-modal/rails-private-preview.env` (mode 0600). The server is loopback-only and accepts only local or port-3068 Colab-proxy hostnames when the gate is enabled.

In a cell of the attached Colab notebook:

```python
%run /content/Rails-8-AI-Customer-Support-Desk/script/open_private_ai_search_colab.py
```

The cell checks that an unauthenticated request receives **HTTP 401**, then opens the Colab port window. In the browser's Basic Auth prompt, enter:

- **Username:** `support-preview`
- **Password:** read `RAILS_PRIVATE_PREVIEW_PASSWORD` from the private local file `~/.config/rails8-support-desk-modal/rails-private-preview.env` in your own Colab terminal. Never paste it into chat, commit it or share the proxy URL; clear the notebook output if you display the password.
- Sign in with `TeamFlow Cloud / Synthetic TF agent` or `NovaMart Store / Synthetic NM agent`, select VI/EN, then open **AI Search**.

Do not substitute a public tunnel if Colab's notebook proxy is unavailable; use an authenticated local port forwarding solution instead.

Sample synthetic questions: “Hóa đơn đã thanh toán nhưng gói TeamFlow chưa kích hoạt, cần xác minh những gì?” and “Does an order of VND 499,999 qualify for free standard shipping?”

## Boundaries

- Colab may reclaim the runtime; Model API endpoints continue independently and can incur GPU charges for allowed requests.
- The Basic Auth gate is only an additional development preview control; it is not production authentication.
- Session-based request limits are not distributed rate limiting; production needs identity, API quotas, cost controls and DLP.
- The Colab browser proxy itself has **not** been exercised by the user's browser in this session; local HTTP and Basic Auth positive/negative cases have been checked. Do not share any proxy URL.
- No Git push, business writes, M0/M1 regeneration, or changes to editorial approvals.
