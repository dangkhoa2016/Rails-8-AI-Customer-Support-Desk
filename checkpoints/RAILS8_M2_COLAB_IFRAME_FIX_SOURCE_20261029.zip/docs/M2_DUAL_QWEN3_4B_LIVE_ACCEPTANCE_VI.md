# M2 Live AI Acceptance — Qwen3-Embedding-4B + Qwen3-Reranker-4B

**Ngày:** 2026-10-29 (UTC evidence). **Modal workspace/profile:** `bsmith888`. **Environment:** `rails-8-ai-customer-support-desk`. **Workspace Colab:** `/content/Rails-8-AI-Customer-Support-Desk`.

## Trạng thái thực tế

- M0/M1 giữ nguyên, không reseed, không reset DB.
- 12 phiên bản KB v2 VI/EN approved (6 bài), 200 phiên bản v1 vẫn draft; 84 chunks eligible và **84 embeddings thật** đã lưu PostgreSQL `vector(2560)`.
- TeamFlow Cloud: 28 vectors. NovaMart Store: 56 vectors.
- Embedding-4B/Reranker-4B đã triển khai dưới dạng **hai Modal A10G Web Functions**, mỗi function tối đa 1 container. `rails8-qwen3-4b-models` là Modal Volume lưu weights bền vững. Modal Secret `rails8-support-desk-ai` giữ riêng app bearer credentials, không commit token.
- Cả hai model **thực sự chạy inference trên Modal GPU**, không phải fake-vector tests.

## Kaggle sources đã kiểm chứng và upstream fallback

Người dùng cung cấp Kaggle token tại `~/.kaggle/access_token`. Token chỉ được dùng để xác minh metadata trên Colab; **không upload Kaggle token sang Modal**.

| Model | Kaggle variation (public) | Version / bytes | Runtime thực tế |
|---|---|---|---|
| Qwen3-Embedding-4B | `dangkhoa2016/qwen-qwen3-embedding-4b/transformers/default/1` | 975642 / ~8.06 GB | HF `Qwen/Qwen3-Embedding-4B@5cf2132abc99cad020ac570b19d031efec650f2b` |
| Qwen3-Reranker-4B | `dangkhoa2016/qwen-qwen3-reranker-4b/transformers/default/1` | 975637 / ~8.06 GB | HF `Qwen/Qwen3-Reranker-4B@22e683669bc0f0bd69640a1354a6d0aebcfeede5` |

Kaggle model metadata khớp revision upstream pin và có đủ config/Safetensors. Hai config nhỏ tải công khai không cần token. Cache Kaggle các shard lớn lỗi API `1994`, nên chuyển sang **tải upstream Hugging Face pin commit** trên CPU Modal; đã hoàn thành và ghi checksum SHA256 các file. Không mô tả nhầm runtime weights là được tải hoàn toàn từ Kaggle.

- Embedding manifest: `evidence-m2-dual-qwen3-4b-runtime/embedding-model-manifest.json` — SHA256 `6f9dd9c01b6e19906af92e3759751787e402f73cd5ae9aa76eacf23c90e739fc` (14 file).
- Reranker manifest: `evidence-m2-dual-qwen3-4b-runtime/reranker-model-manifest.json` — SHA256 `42e6addea0b2a0c3170b8851d65a9ece83708bbfc6b55a307c51a915c1de47b6` (17 file).
- Tổng bytes weights + tài liệu cấu hình: embedding 8,059,521,975; reranker 8,059,548,421.
- 8B có footprint lớn hơn, GGUF cần runtime & scoring path khác. Với pilot này dùng Transformers/SentenceTransformers 4B, không trộn định dạng, chưa đo so sánh 8B/GGUF.

## Inference smoke GPU thật

- Embedding 4B: 2.560 chiều, norm khoảng 1.00035, request đầu 22.31 giây end-to-end.
- Reranker 4B: raw logits `[6.4609375, -4.078125]`, request đầu 22.24 giây end-to-end, score đầu tương đối tốt hơn score sau.
- Log & SHA của prompt synthetic (không khách thật): `evidence-m2-dual-qwen3-4b-runtime/{embedding,reranker}-smoke.json`.

## Benchmark nhỏ VI/EN trên real models

- Dataset: `review/m2_dual_qwen3_4b_pilot_queries.json`, 12 câu synthetic được biên soạn độc lập, 6 bài v2 approved, 2 ngôn ngữ. Không sử dụng dữ liệu khách thật.
- Lexical PostgreSQL baseline (đo thật): Recall@8 `0/12`, MRR@8 `0.0`. Đây là tìm full câu bằng phép lexical hiện tại, **không phải một baseline lexical tối ưu**.
- Qwen 4B embed → PostgreSQL cosine exact → rerank: **Top1 12/12**, Recall@5 `1.0`, MRR@5 `1.0`; median latency query **1,478 ms**, min 1,410 ms, max 1,795 ms. Wall ingestion + 12 query 31.82 giây, không gồm download/model warm-up.
- Khả năng khái quát trên 100 KB, dữ liệu production hoặc độ tin cậy thống kê: **chưa được chứng minh**.

## Security và evidence

- Rails/PostgreSQL tests: **34 tests, 402 assertions, 0 failures, 0 errors, 0 skips**.
- Live DB validator: `script/verify_m2_dual_4b_live.rb`, PASS: tenant, role/audience, locale, approval, model revision, content SHA256, citation, 84 vectors.
- Idempotency: gọi lại importer bằng client giả `NoCallClient`, `embedded=0`, `eligible_remaining=0`; **không gọi GPU**, không tạo vector trùng.
- Hai endpoint dùng application-layer bearer token và Modal Secret. **Modal dashboard hiện hiển thị Web Functions ở trạng thái `Unauthenticated` tại proxy layer**; cần bổ sung Modal proxy auth/rate limiting trước khi public production (request không hợp lệ vẫn có thể khởi động GPU). Demo Rails login passwordless tuyệt đối không đưa ra Cloudflare tunnel.
- Modal billing snapshot (lấy ngày 2026-10-29T04:02:14Z): environment metered cost **USD 0.34852788** tính đến thời điểm đó, có cache/download/deploy/inference và egress; không phải giá riêng một query và có thể cập nhật muộn.
- Không có AI business writes, không tạo M3 tickets, không gửi email thực.

## Vị trí source/evidence

- GPU services: `modal_app/qwen3_embedding_service.py`, `modal_app/qwen3_reranker_service.py`.
- Download: `modal_app/cache_kaggle_4b.py` (Kaggle error log), `modal_app/cache_models_hf_fallback.py` (runtime source).
- Rails: `app/services/modal_embedding_client.rb`, `modal_reranker_client.rb`, `knowledge_embedding_ingestion.rb`, `knowledge_semantic_retrieval.rb`, `knowledge_reranked_retrieval.rb`.
- Pilot: `script/m2_dual_4b_pilot.rb`; smoke: `script/m2_modal_4b_smoke.rb`; acceptance: `script/verify_m2_dual_4b_live.rb`.
- JSON evidence: `evidence-m2-dual-qwen3-4b-live/pilot-results.json`, `evidence-m2-dual-qwen3-4b-runtime/`.

## Giới hạn tiếp tục

M2 **pilot 4B/4B đã chạy thật**, không đồng nghĩa M2 toàn dự án hoặc M3 đã hoàn thành. Cần thêm bộ test retrieval mở rộng, regression vận hành (rate limiting/unauthenticated GPU requests), benchmark định lượng, editorial approval các bài còn lại và M3 synthetic tickets/evaluation theo quota M0. Giữ nguồn gốc, seed, SHA, device ID, runtime/GPU/parallelism và log để người khác kiểm chứng.
