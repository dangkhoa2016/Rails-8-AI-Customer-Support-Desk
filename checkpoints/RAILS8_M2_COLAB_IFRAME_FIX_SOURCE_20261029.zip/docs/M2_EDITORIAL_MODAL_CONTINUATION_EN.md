> **Historical handoff (superseded 2026-10-29):** The earlier 0.6B proposal has been replaced by Qwen3-Embedding-4B + Qwen3-Reranker-4B. See `M2_DUAL_QWEN3_4B_IMPLEMENTATION_EN.md`.

# M2 Editorial and Semantic Retrieval — Continuation Guide

**Date:** October 29, 2026. M0/M1 remain unchanged. M2 Rails/PostgreSQL baseline previously passed. New semantic tests use deterministic FAKE vectors; no Modal inference has been executed.

## Editorial workflow

- Immutable source: `data/m2/knowledge_drafts.json` SHA256 `1207fc8aa4cc421febcc893838daf6b9c291fb4ac8724aeec1bb79794e906c33`.
- 100 article IDs, 200 distinct VI/EN versions, 1,400 chunks. All 200 remain **draft**; zero genuine editorial approvals.
- Run `python3 script/m2_editorial_triage.py` to generate `review/checkpoint_20261029/M2_EDITORIAL_REVIEW_QUEUE_200.csv` and summary JSON.
- Automated triage priorities: 112 HIGH (financial/shipping/returns/warranty/incident policy risks), 74 MEDIUM, 14 NORMAL. These are REVIEW PRIORITIES, not content correctness scores.
- 130 language versions have no direct policy reference (65 article IDs). A missing direct policy ID is not necessarily an error; verify product behavior against the approved blueprint or authorized records.
- All locale pairs, full-body SHA256 checks, and chunk reconstructions passed offline. No human semantic accuracy or translation-equivalence verification was performed.

Prioritize `TF-KB-012` (paid invoice / failed activation), `TF-KB-015` (manual refund), `NM-KB-014` (499,999 vs 500,000 VND shipping), `NM-KB-029` (seven-day returns), `NM-KB-030` (14-day defect reporting), and `NM-KB-020` (delivery ETA is not guaranteed).

Review both language versions at `preview/m2_knowledge/index.html`. Record human decisions and notes. Do not edit source statuses to simulate approval.

### Human-controlled approval

Only an authenticated, tenant-matched owner/admin can approve a draft in Rails. The approval form now requires editorial notes (15–2,000 characters) and an explicit review attestation. Approval writes actor/time, content SHA256 and attestation to audit. Draft, expired, future-dated, wrong-policy and cross-tenant chunks must never reach retrieval.

## pgvector design

- Colab PostgreSQL 16; `postgresql-16-pgvector` version 0.6.0 installed.
- New migration `20261029010000_create_knowledge_chunk_embeddings.rb` adds a tenant-scoped embedding table with a composite chunk foreign key. The 1,400 existing chunks are not rewritten.
- Schema: `vector(1024)` with organization, chunk ID, content SHA256, pinned model ID and model revision.
- Exact cosine search is the quality baseline. HNSW/ANN remains deferred until real vectors permit recall/latency comparison. Mandatory SQL filters: tenant, ACL, locale, approval, policy version, effective dates, digest.
- The application DB role cannot create the pgvector extension. PostgreSQL administrators must preinstall it in development and test databases. Never grant app-role superuser rights or drop/reset a working DB.
- Rails test schema auto-loading is disabled in the test environment to avoid destructive schema reload/extension privilege errors; apply test migrations explicitly after extension provisioning.

## Modal deployment — NOT RUN

- Candidate model: `Qwen/Qwen3-Embedding-0.6B`, 1,024 dimensions, multilingual.
- Reference commit from `git ls-remote` on 2026-10-29: `97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3`. This is a prospective pin, **not** a model that has been downloaded or benchmarked.
- Source: `modal_app/qwen3_embedding_service.py`; authenticated `POST /embed` with max 16 texts, returned ID/revision and per-input SHA256.
- Ruby client: `app/services/modal_embedding_client.rb`; ingestion: `app/services/knowledge_embedding_ingestion.rb`.
- Default ingestion is dry-run: `KB_ORGANIZATION_SLUG=teamflow-cloud bin/rails runner script/m2_embed_approved.rb`. With zero approved versions, eligible chunk count must remain zero and no HTTP requests should be sent.
- Real deployment requires user-authorized Modal credentials, GPU budget, a Modal secret `rails8-support-desk-embedding` with `EMBED_API_TOKEN` and pinned `EMBED_MODEL_REVISION`. Rails requires `MODAL_EMBEDDING_URL`, `MODAL_EMBEDDING_TOKEN`, `MODAL_EMBEDDING_MODEL_REVISION`.
- Enable actual ingestion only after human approval, with `M2_EMBED_INGEST=YES`. Do not send raw tickets or customer PII to Modal.

## Verified gates and limitations

- M1 integration regression: 10 tests / 106 assertions PASS.
- Editorial approval security: 8 tests / 85 assertions PASS after attestation requirement.
- Semantic PostgreSQL security: 6 tests / 22 assertions PASS using **synthetic vectors**, not model output.
- Modal SDK 1.6.3 source import and Python syntax passed, but GPU/model execution, remote endpoint, embedding quality, retrieval VI/EN accuracy, latency, and cost remain NOT RUN.
- Production auth and M3 remain out of scope. No automatic approval, public tunnel, or Git push.
