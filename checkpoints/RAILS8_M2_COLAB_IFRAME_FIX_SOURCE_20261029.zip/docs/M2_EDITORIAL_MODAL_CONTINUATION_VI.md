> **Tài liệu handoff lịch sử (thay thế ngày 2026-10-29):** Đề xuất 0.6B đã được thay bằng bộ đôi Qwen3-Embedding-4B + Qwen3-Reranker-4B. Xem `M2_DUAL_QWEN3_4B_IMPLEMENTATION_VI.md`.

# M2 Editorial & Semantic Retrieval — Hướng dẫn tiếp tục

**Ngày:** 2026-10-29. **M0/M1:** giữ nguyên. **M2:** Rails/PostgreSQL baseline PASS; phần semantic được bổ sung và chạy test với vector GIẢ LẬP, chưa chạy inference Modal.

## 1. Editorial review — chưa phê duyệt nội dung

- Nguồn bất biến: `data/m2/knowledge_drafts.json` (SHA256 `1207fc8aa4cc421febcc893838daf6b9c291fb4ac8724aeec1bb79794e906c33`).
- 100 article IDs, 200 phiên bản VI/EN, 1.400 chunks. 200 `draft`, 0 phiên bản được owner/admin approve.
- Lệnh sàng lọc: `python3 script/m2_editorial_triage.py`. Kết quả: `review/checkpoint_20261029/M2_EDITORIAL_REVIEW_QUEUE_200.csv` + JSON summary.
- 112 phiên bản được đặt HIGH (nội dung chính sách nhạy cảm về tiền, giao hàng, trả hàng, bảo hành, sự cố); 74 MEDIUM; 14 NORMAL. Đây là **ưu tiên rà soát**, không phải đánh giá đúng/sai.
- 130 phiên bản không có policy ID trực tiếp (65 bài gốc). Không mặc định sai: cần xác minh feature bằng blueprint/DB hoặc giữ hướng dẫn thận trọng.
- Kiểm tra offline 200 body hash, kết nối chunks, locale pairs: không phát hiện vấn đề integrity. Không chứng minh chất lượng ngữ nghĩa hoặc tương đương bản dịch.

**Thứ tự nên rà soát trước:** `TF-KB-012` (paid nhưng activation failed không có entitlement), `TF-KB-015` (refund 7 ngày cần người duyệt), `NM-KB-014` (499.999/500.000 VND), `NM-KB-029` (return 7 ngày), `NM-KB-030` (defect 14 ngày), `NM-KB-020` (ETA không bảo đảm). Kiểm tra giá và trạng thái từ policy v1.0.0 và read-only business records, không nhận dữ liệu tenant khác.

Mở `preview/m2_knowledge/index.html` để đọc cả VI/EN; điền quyết định và ghi chú trong review CSV; **không chỉnh `status` trong source JSON** để giả làm approval.

### Duyệt trên Rails

Chỉ tài khoản owner/admin của đúng tenant được mở trang draft và thực hiện approve. Form hiện yêu cầu ghi chú tối thiểu 15 ký tự và checkbox xác nhận người duyệt đã đọc nội dung, so policy và effective dates. Audit ghi actor, article, locale, content SHA256, ghi chú và attestation. Draft/agent-only/expired/future/khác tenant vẫn không được retrieval xuất hiện.

## 2. pgvector (PostgreSQL 16)

- Extension pgvector trong phiên Colab hiện tại: `vector 0.6.0` cài từ gói `postgresql-16-pgvector`.
- Mới thêm migration `20261029010000_create_knowledge_chunk_embeddings.rb`. Chỉ tạo bảng `knowledge_chunk_embeddings` và tenant composite FK, không thay các article/chunk M2.
- `vector(1024)` theo ứng viên Qwen3-Embedding-0.6B. Một vector gắn cùng `organization_id`, `knowledge_chunk_id`, `content_sha256`, `model_id`, `model_revision`.
- Semantic retrieval hiện xếp cosine **EXACT**, SQL lọc tenant, role/audience, locale, approved/current, policy_version, hiệu lực và hash trước khi trả citation. HNSW chưa tạo vì chưa có vector thực để đo exact-vs-ANN recall/latency.
- Trên Colab, `support_desk` không có quyền `CREATE EXTENSION vector`; người quản trị PostgreSQL cài extension **riêng trong DB development và test** trước migration. Không cấp SUPERUSER cho app role. Tuyệt đối không `db:drop`/`db:reset`.
- Đã tắt **chỉ** tự nạp schema trong môi trường test để Rails không purge test DB rồi chạy `CREATE EXTENSION` bằng role thiếu quyền. Khi setup mới, chạy migration test thủ công sau khi chuẩn bị extension.

## 3. Modal — chuẩn bị mã nguồn, chưa triển khai GPU

- Candidate: `Qwen/Qwen3-Embedding-0.6B` / 1024 chiều, pretrained multilingual.
- Candidate revision tham chiếu đã kiểm tra bằng `git ls-remote` ngày 2026-10-29: `97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3`. **Chưa download hay chạy model này**, không phải model digest runtime.
- Service source: `modal_app/qwen3_embedding_service.py`; HTTP `POST /embed` với bearer secret, max 16 văn bản/request, trả model ID/revision và SHA256 từng input; không log dữ liệu khách.
- Client Rails: `app/services/modal_embedding_client.rb`. Ingest: `app/services/knowledge_embedding_ingestion.rb`.
- Ingestion an toàn mặc định `DRY_RUN`: `KB_ORGANIZATION_SLUG=teamflow-cloud bin/rails runner script/m2_embed_approved.rb`. Với 0 approved, kết quả phải là 0 eligible chunks và không gửi request.
- Muốn deploy thật cần Modal account/token, secret `rails8-support-desk-embedding` chứa `EMBED_API_TOKEN` và `EMBED_MODEL_REVISION` pinned, xác nhận chi phí GPU. Rails cần `MODAL_EMBEDDING_URL`, `MODAL_EMBEDDING_TOKEN`, `MODAL_EMBEDDING_MODEL_REVISION`. Không ghi secrets vào Git/ZIP/log.
- Chỉ sau editorial approval có thể ingest với `M2_EMBED_INGEST=YES` và giới hạn tối đa 16 chunks/call. Không bao giờ gửi ticket raw chứa PII tới embedding endpoint.

## 4. Evidence và acceptance status

- Ruby/Rails M1 integration: 10 tests / 106 assertions PASS (regression).
- M2 editorial security: 8 tests / 85 assertions PASS sau khi thêm attestation.
- M2 semantic DB security: 6 tests / 22 assertions PASS, dùng synthetic vectors, **không** gọi Modal.
- Python static import Modal SDK 1.6.3 + syntax PASS; chưa GPU load, chưa benchmark.
- Chưa có approved KB thực, embeddings thực, retrieval VI/EN benchmark, inference latency/GPU/cost hoặc production authentication.
