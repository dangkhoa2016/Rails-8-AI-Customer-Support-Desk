# M2 — Colab iframe access fix (October 29, 2026)

## Root cause

Google Colab's `serve_kernel_port_as_window(3068)` generates a `https://3068-<session>.<region>.prod.r.colab.dev` URL; Colab now deprecates opening the proxy in a new tab due to browser security changes. Rails previously allowed only the legacy `googleusercontent.com` host. Also, Chromium usually blocks cross-origin HTTP Basic Auth dialogs in third-party iframes.

## Implemented changes

- Development Rails remains on **127.0.0.1:3068** with `M2_SEMANTIC_UI_ENABLE=YES`; no public Cloudflare tunnel.
- The private Rails host allowlist accepts only Colab proxy hostnames for **port 3068** on `prod.r.colab.dev` and the legacy Colab host format.
- Replaced the browser's HTTP Basic Auth challenge with a dedicated **private preview password form** at `/__private_preview/sign_in`. The previously generated strong password is unchanged and stays outside the repo in `~/.config/rails8-support-desk-modal/rails-private-preview.env` with mode 0600.
- One-hour HttpOnly signed session cookie uses HMAC SHA256. Colab HTTPS iframe cookies carry `Secure; SameSite=None; Partitioned`. Form CSRF nonces and authenticated cookies use distinct signed purposes to prevent confusing them. Login attempts, hostnames, and Origin are validated.
- Partitioned Rails demo session cookies support third-party iframe contexts. `X-Frame-Options: SAMEORIGIN` is removed **only in opted-in private preview**, replaced by Colab-specific CSP `frame-ancestors`.
- `script/open_private_ai_search_colab.py` now calls `output.serve_kernel_port_as_iframe(3068, path='/__private_preview/sign_in', height='950')`.

## Verified results

- GET protected app without cookie redirects **303** to password form; gate form returns **200**.
- Invalid password never grants a signed cookie; valid password redirects **303** and permits Rails.
- TeamFlow Cloud VI and NovaMart Store EN: private form login, synthetic agent login, AI Search GET **200**, email/PII query rejected **422**. **No GPU calls** were made in these access tests.
- Full Rails regression **43 tests, 502 assertions, zero failures/errors/skips**, including explicit proof that the hidden form CSRF token cannot be reused as a session cookie.
- Database unchanged: 100 articles, 12 approved KB versions and 84 embeddings.
- **Browser-side Colab iframe display is not yet verified**; third-party cookies and browser privacy settings may still affect the user's browser.

## Open from your active Colab notebook

Run:

```python
%run /content/Rails-8-AI-Customer-Support-Desk/script/open_private_ai_search_colab.py
```

The **Private Colab preview** form appears inside the notebook. Enter the existing **password only**—no username. Read the `RAILS_PRIVATE_PREVIEW_PASSWORD` value privately from the local protected file; do not paste it into chat or public outputs.

Then choose a synthetic TeamFlow or NovaMart agent, VI/EN, and open **AI Search**.

If the iframe is blank or shows 403, check site-specific Colab cookies / tracking prevention in your browser and re-run the cell. Do not enable a public tunnel or disable the password gate as a workaround.

## Boundaries

Rails remains loopback-only, synthetic-only and unfit for public production authentication or customer data. No business writes, M0/M1 restarts, KB approval changes or repeat embedding ingestion.
