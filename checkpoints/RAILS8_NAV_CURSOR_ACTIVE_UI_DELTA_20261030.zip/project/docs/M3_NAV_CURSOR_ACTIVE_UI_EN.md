# M3 — Button cursors and active navigation (2026-10-30)

## Scope
- Native `button`, Rails `input[type=submit]`, `input[type=button]`, `input[type=reset]`, and `.btn` links use `cursor:pointer`. Disabled buttons use `cursor:not-allowed`.
- The top navigation highlights the current section with a distinct background, border and inset accent. Exactly one active link receives `aria-current="page"`. Keyboard focus and hover states remain visible.
- Active-state mapping uses Rails `controller_name`, not locale or query-string matching: `dashboard` → Overview; `tickets`/`ticket_messages` → Tickets; `customers`/`business_records` → Customers; `knowledge_articles` → Knowledge Base; `knowledge_ai_search` → AI Search. Detail pages retain the parent section highlight.
- Existing role-based navigation remains in place: Viewer cannot see AI Search, while staff retains authorized links. No business writes or access rules were changed.

## Files
- `app/helpers/application_helper.rb`: `NAV_SECTIONS` and `nav_menu_link_to`.
- `app/views/layouts/application.html.erb`: active navigation and cursor CSS.
- `test/integration/navigation_ui_test.rb`: active sections, VI/EN, Viewer permissions, button selectors.
- `test/smoke_nav_active_css_private_https.py`: authenticated Cloudflare smoke; no business mutations.

## Acceptance
- New integration: **6 tests / 130 assertions / 0 failures**.
- Full Rails regression: **95 tests / 4,698 assertions / 0 failures / 0 errors / 0 skips**.
- HTTPS smoke: overview, ticket list/detail, customer list/detail, Knowledge Base and AI Search return 200 and show exactly one `aria-current=page` navigation item; pointer CSS is present.
- Unchanged DB: 2 organizations, 240 tickets, 440 messages, 1,484 KB chunks, 84 embeddings, 12 approved KB versions. The sealed80 answerability gate remains **BLOCKED**. No Modal inference, Git commit or push.

Test directly via the authenticated Private Demo. Quick Tunnel URLs may change after Colab restarts.
