# M3 — Nút bấm và trạng thái active của menu (2026-10-30)

## Phạm vi chỉnh sửa
- Nút HTML `button`, Rails `input[type=submit]`, `input[type=button]`, `input[type=reset]` và liên kết `.btn` dùng `cursor:pointer`; nút disabled dùng `cursor:not-allowed`.
- Menu top navigation tô nền, viền và đường nhấn nhẹ cho đúng mục đang mở. Thêm `aria-current="page"` chỉ trên mục active, đồng thời hỗ trợ hover và keyboard focus.
- Active dựa trên Rails `controller_name`, không phụ thuộc ngôn ngữ hoặc query params: `dashboard` → Tổng quan; `tickets`/`ticket_messages` → Tickets; `customers`/`business_records` → Customers; `knowledge_articles` → Knowledge Base; `knowledge_ai_search` → AI Search. Trang con vẫn giữ menu cấp cha.
- Giữ nguyên kiểm tra role: Viewer không nhìn thấy menu AI Search; Agent/Owner nhìn thấy theo quyền hiện có. Không mở endpoint hay business write.

## Mã nguồn
- `app/helpers/application_helper.rb`: `NAV_SECTIONS` và `nav_menu_link_to`.
- `app/views/layouts/application.html.erb`: CSS và liên kết nav dùng helper mới.
- `test/integration/navigation_ui_test.rb`: kiểm thử menu active, VI/EN, quyền Viewer, các selector của button.
- `test/smoke_nav_active_css_private_https.py`: HTTP smoke sau khi đăng nhập qua private Cloudflare; không sửa nghiệp vụ.

## Kết quả
- Integration mới: **6 tests / 130 assertions / 0 failures**.
- Rails regression: **95 tests / 4698 assertions / 0 failures / 0 errors / 0 skips**.
- HTTPS smoke: các trang overview, ticket list/detail, customer list/detail, Knowledge Base, AI Search đều trả 200 và có đúng một `aria-current=page`; CSS button pointer được xuất vào trang.
- Database bất biến: 2 tổ chức, 240 tickets, 440 messages, 1484 KB chunks, 84 embeddings, 12 KB approved. Gate sealed80 vẫn **BLOCKED**. Không gọi Modal GPU; không commit/push.

Kiểm tra hành vi trực tiếp trong Private Demo sau khi đăng nhập. Địa chỉ Quick Tunnel có thể thay đổi khi runtime Colab khởi động lại.
