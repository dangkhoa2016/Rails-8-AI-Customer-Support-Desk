# Rails 8 AI Customer Support Desk

**M3 live (2026-10-29):** Recovered the Rails 8/PostgreSQL development runtime on a fresh Colab database and imported 240 synthetic tickets, 440 messages, and 240 seed audit events. Second import added zero rows; **84 Rails tests / 4,480 assertions PASS** and private HTTPS Rails demo tenant checks PASS. The 12 approved KB v2 versions match their frozen source; **All 84 historical M2 vectors have now been restored to PostgreSQL with verified provenance (28 TeamFlow, 56 NovaMart)**. A new end-to-end Modal HTTP AI Search run remains **NOT_RUN** because private Colab credentials are unavailable; the answerability gate remains **BLOCKED**. See [earlier M3 Rails live acceptance](docs/M3_POSTGRESQL_RAILS_LIVE_ACCEPTANCE_EN.md) and [latest M2 embedding recovery](docs/M3_M2_84_EMBEDDINGS_RESTORED_EN.md). This is not a production service, repeat GPU run, or new review of the 64 sample claims.

**Current checkpoint (2026-10-29): Rails 8 and PostgreSQL runtime acceptance completed on synthetic Colab development/test databases. M0/M1 were not rebuilt. M2 has 12 editorially approved bilingual v2 versions, 84 approved chunks, and a source-validated Qwen3-Embedding-4B + Qwen3-Reranker-4B integration. Both pinned 4B models have now run on Modal A10G GPU; 84 actual pgvector embeddings and 12 real bilingual reranking queries have been measured.**

## Included in this stage

- One Rails 8 app with PostgreSQL and server-rendered ERB views, separate EN/VI localizations, and no frontend build tooling.
- Two synthetic tenants: `TeamFlow Cloud` (`b2b_saas`) and `NovaMart Store` (`ecommerce`).
- **Development/test-only** passwordless synthetic account selector. Membership-verified session selects a tenant; neither model output nor request parameters can override it. This is **not production authentication**.
- Tenant-scoped dashboard, customers, TeamFlow invoices, NovaMart orders and partial shipments, with read-only authorized lookups.
- Manual ticket intake, conversation history, internal notes, explicit agent-approved public replies, audit records, idempotency, constrained state transitions.
- Seven Rails migrations (original M1/M2 plus two embedding schema migrations), imported M1 business/core models, deterministic M1 business records and relational fixtures, seed importer, validation scripts and regression tests.

**M3 update (2026-10-29):** 240 synthetic tickets and 440 messages have been generated and validated **offline** (10/10 Python tests PASS), with 60 VI + 60 EN per tenant and 216 distinct business references. The development-only Rails importer and tenant-scoped ticket filter UI are present in source, but **PostgreSQL import and Rails M3 UI tests remain NOT_RUN after Colab reboot**. See `docs/M3_SYNTHETIC_TICKETS_AND_RAILS_DEMO_EN.md`. **Still pending:** full 100-article editorial coverage, independent semantic evaluation, the separate 120-case evaluation set, production authentication/proxy authorization and outbound communications. The measured 12-case M2 pilot achieved Top1=12/12 and MRR@5=1.0 (small curated set only); the current naive lexical baseline was 0/12 Recall@8.

## Run with existing Ruby 3.3+ and PostgreSQL

```bash
cd Rails-8-AI-Customer-Support-Desk
bundle install
# Configure a disposable local PostgreSQL demo role/database through PGHOST/PGUSER/PGPASSWORD/PGDATABASE.
export RAILS_ENV=development M1_SYNTHETIC_DEMO=YES
bin/rails db:create db:migrate
bin/rails runner db/seeds/m1_full_business_records.rb
bin/rails runner script/verify_m1_database.rb
bin/rails server -b 127.0.0.1 -p 3000
```

Visit `http://127.0.0.1:3000/demo/sign_in`, select a synthetic TeamFlow/NovaMart agent, and inspect the workflows. Sessions and records are separated by tenant. **Do not use the demo login or synthetic database on a public production site.**

## Full acceptance on Kaggle/Colab

With notebook Internet enabled, extract the app and run as the notebook root user:

```bash
bash script/notebook_setup.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bin/rails server -b 127.0.0.1 -p 3000
```

The notebook setup installs runtime dependencies, uses mise to install Ruby 3.3 and creates a locally stored `.env.notebook` for a disposable PostgreSQL account. The full acceptance script collects commands, UTC timestamps, stdout/stderr, exit codes and SHA256 in `evidence-run/`. It contains no `db:drop` or `db:reset` and refuses non-development mode. **Do not expose the passwordless demo through a public Quick Tunnel.** Only consider public exposure after proper authentication/authorization hardening.

Alternative local Docker setup (not run in this workspace): `docker compose up --build`. The fixed Compose database password is for isolated localhost development only.

## Provenance and limitations

- Canonical M0-approved policy is `docs/RAILS8_AI_SUPPORT_DESK_CANONICAL_BLUEPRINT_2026-10-28.json`, version `1.0.0`.
- The synthetic M1 dataset lives in `data/m1_business_records.json`; seed `20261028`, reference time `2026-10-28T00:00:00+07:00`.
- Evidence-backed read-only lookups and database-level composite FKs are intended to prevent tenant leakage, pending runtime tests.
- Public replies are stored after an explicit human approval action. There is **no actual external email or Modal AI endpoint**.
- Original M0 documents, policy approval logs and immutable source snapshot are available under `docs/`.

**`PASS_SOURCE_ONLY` and `PASS_OFFLINE_ONLY` must never be represented as PostgreSQL or AI acceptance.**

- New Modal proxy auth and local Rails AI Search: `docs/M2_MODAL_PROXY_AND_RAILS_SEARCH_EN.md`

- **Live Rails AI Search via private Colab preview**: `docs/M2_RAILS_AI_SEARCH_LIVE_UI_EN.md`

- **Colab iframe browser access fix:** `docs/M2_COLAB_IFRAME_ACCESS_FIX_EN.md`

- **Cloudflare Quick Tunnel: password-gated read-only preview:** `docs/M2_CLOUDFLARE_PRIVATE_PREVIEW_EN.md`

## M2 — Bilingual Knowledge Base (added 2026-10-28)

The historical M2 baseline contained 100 bilingual articles / 200 v1 drafts / 1,400 chunks. As of October 29, 2026, **12 reviewed v2 versions have been approved by delegated synthetic demo owners**, producing **212 versions and 1,484 chunks** overall; exactly **84 chunks are approved/active**. PostgreSQL pgvector is installed with native `vector(2560)` storage and security regression tests PASS. Both Modal A10G services are deployed under environment `rails-8-ai-customer-support-desk`; 84 real embeddings have been ingested, and actual reranking achieved Top1=12/12 on a limited curated VI/EN pilot. This is not complete M2 or M3 acceptance.

- Current **live** 4B/4B acceptance, provenance and security: `docs/M2_DUAL_QWEN3_4B_LIVE_ACCEPTANCE_EN.md`
- Earlier preparation guide: `docs/M2_DUAL_QWEN3_4B_IMPLEMENTATION_EN.md`
- M2 implementation and acceptance: `docs/M2_IMPLEMENTATION_GUIDE_EN.md`
- Standalone editorial preview: `preview/m2_knowledge/index.html`
- Deterministic full-text data: `data/m2/knowledge_drafts.json`
- Kaggle/Colab after M1: `bash script/run_full_m2.sh`

Previous offline evidence does not constitute AI acceptance. Runtime PostgreSQL acceptance is recorded separately; do not rerun M1/M2 importers unnecessarily on the currently approved database.

### PostgreSQL authentication repair on Kaggle/Colab

If setup reports `FATAL: password authentication failed for user "support_desk"`, the old setup inherited application PostgreSQL variables while running admin commands. Do not reset or drop the database, and do not reinstall Ruby/gems. From the application root run:

```bash
bash script/repair_notebook_postgres.sh
source script/use_notebook_env.sh
bash script/run_full_m1.sh
bash script/run_full_m2.sh
```

The repair uses a clean Unix-socket `postgres` admin connection, sets the local demo role password without logging it, then verifies TCP authentication as `support_desk`. Intended only for disposable synthetic Kaggle/Colab notebooks; never for production or real databases.
