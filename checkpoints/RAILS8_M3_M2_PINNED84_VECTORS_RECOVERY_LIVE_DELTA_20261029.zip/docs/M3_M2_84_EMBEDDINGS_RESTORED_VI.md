# M3 / M2 — Khôi phục 84 embeddings vào database Rails hiện tại

**Ngày:** 2026-10-29. **Phạm vi:** synthetic development, TeamFlow Cloud và NovaMart Store.

## Trạng thái chốt

- **PASS — PostgreSQL restore:** 84 embeddings thực từ checkpoint M2 gốc, đúng model/revision, 2.560 chiều; 28 TeamFlow + 56 NovaMart.
- **PASS — Import lần đầu:** 84 vector tạo mới; transaction, ánh xạ dựa trên tenant slug, article key, locale, KB v2, chunk index và SHA256; **không restore numeric IDs cũ**.
- **PASS — Import lặp lại:** 0 vector mới, 84 vector khớp. Sau khi làm importer độc lập với /tmp, chạy lần nữa vẫn 0 mới / 84 khớp.
- **PASS — Independent read-only checks:** 84 vectors thuộc đúng KB approved, trạng thái hiệu lực, checksum chunk, audience/tenant/locale filtering; 84 Rails tests / 4.480 assertions, 0 failures/errors/skips.
- **PASS — pgvector structural smoke:** 12/12 KB v2 phiên bản được tìm lại Top-1 khi dùng chính vector tài liệu đã lưu (cosine distance 0). Đây là kiểm thử cấu trúc self-retrieval, **không phải** kiểm tra chất lượng semantic query hoặc model runtime.
- **PASS — Modal Evidence Volume backup roundtrip:** database backup sau phục hồi tải ngược byte-identical và được `pg_restore --list` đọc thành công.
- **NOT_RUN — M2 Modal HTTP end-to-end hôm nay:** hai app Modal còn deployed nhưng Rails chưa có lại 6 biến URL/token/proxy cần thiết trong môi trường Colab mới. Không tạo/rotate secret hoặc cho model chạy GPU hôm nay. Kết quả 12-query M2 GPU pilot là **bằng chứng lịch sử**, không phải live rerun trong phiên này.
- **BLOCKED — sealed80 answerability:** không mở khóa; AI assist-only; không tự gửi câu trả lời hoặc ghi nghiệp vụ.

## Nguồn và provenance

- Colab hostname `d912002e2a9f`, device ID `d2536713-6975-49cb-8955-969067f3726f`.
- Frozen M2 source: `checkpoints/M2_DUAL_QWEN3_4B_REAL_EMBEDDINGS_DB_20261029.dump`.
- Original dump SHA256: `9b6a218943b81d35ba61e60c92bfea6d171ca9c49517371e6ddedd18e6d0c4ae`.
- Embedding model: `Qwen/Qwen3-Embedding-4B`, revision `5cf2132abc99cad020ac570b19d031efec650f2b`, 2.560 dimensions.
- Source tenant IDs 3/4 **không** tương ứng current tenant IDs 1/2. Importer xác minh danh tính qua dữ liệu và hashes, không qua primary key lịch sử.
- M3 accepted dataset SHA256: `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd`, không sửa.
- 100 customers, 80 TeamFlow invoices, 120 NovaMart orders, 240 M3 tickets, 440 messages, 240 audit seed events, 100 KB articles, 212 KB versions, 1.484 chunks, 12 KB v2 approved.
- 64/64 claims phê duyệt **chỉ cho synthetic demo** vẫn giữ nguyên. Không biến chúng thành semantic gold hoặc tạo reviewer giả.

## Thực thi và xác minh

File mới: `script/restore_m2_pinned_embeddings_live.rb`. Script tự đọc bản `pg_restore` được khóa SHA256 (không dùng file tạm), kiểm tra source-to-current từng chunk, transaction và kiểm tra trạng thái M3 không bị sửa. Mặc định chỉ dry-run; muốn import vào **development database được xác minh trước**, cần `M2_PINNED_EMBEDDING_RESTORE=YES`.

```bash
source script/use_notebook_env.sh
bin/rails runner script/restore_m2_pinned_embeddings_live.rb
M2_PINNED_EMBEDDING_RESTORE=YES bin/rails runner script/restore_m2_pinned_embeddings_live.rb
bin/rails runner script/verify_m3_post_embedding_restore.rb
bin/rails runner script/verify_m2_dual_4b_live.rb
RAILS_ENV=test bin/rails test
```

Không chạy importer trên DB chưa rõ trạng thái hoặc production. Bộ `verify_m2_dual_4b_live.rb` là kiểm tra **DB/filtered retrieval read-only hiện tại**, có tham chiếu pilot model M2 đã thực hiện trước đó, không tự gọi GPU.

## Backup và rollback

- Pre-restore private dump: `/tmp/RAILS8_PRE_M2_84_VECTOR_RESTORE_20261029.dump`, SHA256 `52c8336af7e405ef7e09334d569d1b74c4dc773a4514f5ed0317f5c2c801b9cf`.
- Post-restore dump: `/tmp/RAILS8_M3_POST_M2_84_VECTORS_20261029.dump`, 1.245.445 bytes, SHA256 `391f8bb7970493fe75a7db9253213bef1e801cdd62d837213e25e803544704dc`.
- Modal profile `bsmith888`; environment `rails-8-ai-customer-support-desk`; volume `rails8-support-desk-evidence`; path `20261029/m3-post-m2-84-vectors/`. Dump và private SHA file được upload thêm, tải ngược và so sánh từng byte PASS.
- Không xóa, reset hoặc ghi đè database/backup cũ. Tuyệt đối không restore dump trực tiếp vào một DB chưa kiểm tra danh tính/trạng thái.

## Chưa hoàn thành

- Khôi phục credential Rails ↔ Modal bằng quy trình bảo mật riêng, rồi chạy ít nhất 1 VI + 1 EN synthetic relevance-only query qua cả Embedding và Reranker; thu thập timestamp, latency, source SHA và no-business-write evidence. Không đưa secret vào Git hoặc log.
- Bộ 120 câu evaluation hiện chỉ là **candidate, không phải gold**; cần chấm độc lập và phân biệt retrieval relevance với answerability.
- 240 ticket M3 vẫn chỉ có 22 template intake sau mask; cải thiện corpus theo proposal riêng, không thay đổi dữ liệu đã PASS.
- Không commit hoặc push trong lượt khôi phục này.

Tài liệu tương ứng: `docs/M3_M2_84_EMBEDDINGS_RESTORED_EN.md`.
