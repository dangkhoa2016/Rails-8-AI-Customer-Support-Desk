# M3 / M2 — Restored 84 Historical Embeddings to the Current Rails Database

**Date:** 2026-10-29. **Scope:** synthetic development only, TeamFlow Cloud and NovaMart Store.

## Acceptance status

- **PASS — PostgreSQL restore:** 84 real historical M2 vectors, pinned model and revision, 2,560 dimensions, split 28 TeamFlow / 56 NovaMart.
- **PASS — First import:** 84 vectors inserted atomically. Identity matched by tenant slug, article key, locale, approved KB v2, chunk index, and content SHA256. Historical numeric IDs were **not** reused.
- **PASS — Idempotence:** second import inserted zero and matched 84. A subsequent run using the self-contained importer (no /tmp input dependency) also inserted zero and matched 84.
- **PASS — Independent read-only verification:** all 84 vectors point to the intended approved KB chunks and honor tenant, audience and locale filters. Rails suite: 84 tests / 4,480 assertions / zero failures/errors/skips.
- **PASS — Structural pgvector smoke:** all 12 approved KB v2 document vectors returned their own chunk at Top-1 (cosine distance 0). This is a structural self-retrieval check, **not** a fresh semantic query or model runtime benchmark.
- **PASS — Private Modal evidence backup:** downloaded bytes exactly match the post-restoration database dump; `pg_restore --list` can read the archive.
- **NOT_RUN — Fresh Modal HTTP end-to-end inference:** both original Modal apps remain deployed, but the new Colab environment does not have the six required Rails endpoint/token/proxy variables. No token was rotated, no new GPU call was made. The older 12-query GPU pilot is **historical evidence**, not a fresh live test.
- **BLOCKED — sealed80 answerability gate:** AI remains assist-only; no autonomous replies or business writes.

## Provenance and data invariants

- Colab host `d912002e2a9f`, Desktop Commander device `d2536713-6975-49cb-8955-969067f3726f`.
- Frozen backup `checkpoints/M2_DUAL_QWEN3_4B_REAL_EMBEDDINGS_DB_20261029.dump`, SHA256 `9b6a218943b81d35ba61e60c92bfea6d171ca9c49517371e6ddedd18e6d0c4ae`.
- Model `Qwen/Qwen3-Embedding-4B`, revision `5cf2132abc99cad020ac570b19d031efec650f2b`, 2,560 dimensions.
- Historical source tenant IDs 3/4 are different from current DB IDs 1/2. The importer validates full source and target identity, never restoring historical primary keys.
- Accepted M3 dataset SHA256 `398e3de1fe231eaa6baabded10183502ed8551f33869c188d534e16bfe2c81fd` was unchanged.
- Database after recovery: 100 customers, 80 TeamFlow invoices, 120 NovaMart orders, 240 tickets, 440 messages, 240 ticket-seed audits, 100 KB articles, 212 versions, 1,484 chunks, and 12 approved KB v2 versions.
- The earlier 64/64 claims remain approved **only for synthetic demonstration**, never independent semantic ground truth.

## Implementation and independent testing

New guarded importer: `script/restore_m2_pinned_embeddings_live.rb`. It reads the verified frozen `pg_restore` archive in memory without /tmp dependencies, checks source-to-current content and tenant identities, inserts within a DB transaction and checks M3 invariants. By default, it performs a read-only dry-run. Restoring to the verified development database requires `M2_PINNED_EMBEDDING_RESTORE=YES`.

```bash
source script/use_notebook_env.sh
bin/rails runner script/restore_m2_pinned_embeddings_live.rb
M2_PINNED_EMBEDDING_RESTORE=YES bin/rails runner script/restore_m2_pinned_embeddings_live.rb
bin/rails runner script/verify_m3_post_embedding_restore.rb
bin/rails runner script/verify_m2_dual_4b_live.rb
RAILS_ENV=test bin/rails test
```

Do not run this import against any unknown or production DB. `verify_m2_dual_4b_live.rb` checks the **current database and filtered retrieval locally**, while referencing already-executed historical GPU pilot evidence. It does not perform a new Modal call.

## Backups

- Private pre-restore archive: `/tmp/RAILS8_PRE_M2_84_VECTOR_RESTORE_20261029.dump`, SHA256 `52c8336af7e405ef7e09334d569d1b74c4dc773a4514f5ed0317f5c2c801b9cf`.
- Private post-restore archive: `/tmp/RAILS8_M3_POST_M2_84_VECTORS_20261029.dump`, 1,245,445 bytes, SHA256 `391f8bb7970493fe75a7db9253213bef1e801cdd62d837213e25e803544704dc`.
- Modal profile `bsmith888`, environment `rails-8-ai-customer-support-desk`, volume `rails8-support-desk-evidence`, path `20261029/m3-post-m2-84-vectors/`. Dump and checksum were uploaded additively, downloaded, byte-compared and `pg_restore --list` checked PASS.
- No old DB or checkpoint was reset, dropped, or overwritten.

## Remaining

Restore Rails↔Modal credentials privately and run at least one Vietnamese and one English *synthetic relevance-only* end-to-end Embedding+Reranker search, preserving timestamps, latency, source hashes and no-business-write proof. Do not publish tokens or enable the answerability gate.

The 120-question evaluation corpus is *candidates only*, not adjudicated ground truth or benchmark scores. M3 tickets currently have only 22 masked intake templates; create a separate versioned linguistic enrichment proposal rather than changing the approved baseline. No Git commit or push was performed in this stage.

Vietnamese companion: `docs/M3_M2_84_EMBEDDINGS_RESTORED_VI.md`.
