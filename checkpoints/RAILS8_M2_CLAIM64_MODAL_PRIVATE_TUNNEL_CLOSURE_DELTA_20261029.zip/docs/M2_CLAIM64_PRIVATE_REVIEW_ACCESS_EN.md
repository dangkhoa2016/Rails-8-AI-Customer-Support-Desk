# M2 Claim64 — Private Cloudflare workbook access (EN)

**October 29, 2026 status:** Two read-only synthetic reviewer workbooks are served by a loopback-only HTTP server behind Cloudflare Quick Tunnel HTTPS with Basic Authentication. This is not an AI API or a business write endpoint.

## Restart instructions

The repository root is `/content/Rails-8-AI-Customer-Support-Desk`. After a Colab restart, when workbook files are still available, use:

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
bash script/restart_m2_claim64_private_review.sh
```

The startup script checks the two approved local HTML documents, validates or installs a **SHA256-pinned cloudflared binary**, generates a new strong access password if needed (without printing it), and starts a read-only listener on `127.0.0.1:3176` plus a temporary Cloudflare Quick Tunnel. The only pages available are `/index.vi.html` and `/index.en.html`.

Open the temporary HTTPS `trycloudflare.com` origin shown by the script and append the appropriate path. Quick Tunnel URLs are not permanent and should not be hard-coded into README, Git or long-lived documentation.

The Basic Auth username is `review`. The password is stored in a root-only Colab file at `/root/.config/rails8-support-desk-private-review/preview-password.txt` (permission mode 0600). The environment owner may view it privately on Colab:

```bash
cat /root/.config/rails8-support-desk-private-review/preview-password.txt
```

Do not print credentials in publicly shared notebook outputs, include them in evidence ZIP files, or send them into Git or a chat. Restrict both URL and password to authorized human reviewers.

## Verified HTTP behavior

An unauthenticated request receives **401**. Authorized GET requests for the two allowed workbooks receive **200** with byte-identical content to the local HTML and all 64 claims / 12 approved KB articles. Other paths such as credential files, code and checkpoints receive **404**. POST and PUT receive **405**, preventing server-side business writes or reviewer upload.

Headers include `Cache-Control: private, no-store`, a restrictive `Content-Security-Policy` with `connect-src 'none'`, `X-Frame-Options: DENY`, and `Referrer-Policy: no-referrer`. The user interface is client-side only; each reviewer exports draft/final JSON locally. **There is no autosave or server-side review storage.** Reviewers should export drafts often.

HTTP Basic Auth here has no built-in rate limit. The long random password and HTTPS-only tunnel are meant for a *temporary private review*, not a general production-grade identity management solution.

## Backup and acceptance boundaries

The restored workbook checkpoint and SHA256 text file are stored on Modal Evidence Volume `rails8-support-desk-evidence` under `20261029/claim64-review-v2-post-reboot/`. Both were downloaded after upload and byte-verified, including all per-file hashes. The password and tunnel runtime are **excluded**.

A functioning review form does not imply human signoff. Both independent 64-claim JSON review files are still **NOT_RECEIVED**. Do not lift the blocked sealed80 scope gate, send autonomous AI customer replies, permit AI business writes, or declare M2 claim-level production release.
