# M2 Claim64 — Truy cập riêng qua Cloudflare (VI)

**Trạng thái ngày 29/10/2026:** Workbook VI/EN phục vụ qua một localhost HTTP server read-only trên Colab, được bảo vệ bằng HTTP Basic Auth qua HTTPS Cloudflare Quick Tunnel. Đây là công cụ **kiểm duyệt dữ liệu synthetic**, không phải một endpoint AI và không thể thực hiện nghiệp vụ.

## Địa điểm và cách mở

Repository: `/content/Rails-8-AI-Customer-Support-Desk`.

Sau mỗi lần Colab restart, khi các file workbook vẫn còn, chạy:

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
bash script/restart_m2_claim64_private_review.sh
```

Script kiểm tra đúng hai trang `index.vi.html` và `index.en.html` dưới `evidence-m2-claim64-independent-review-v2-20261029/`, sử dụng địa chỉ localhost `127.0.0.1:3176`, cài `cloudflared` phiên bản đã pin với SHA256 trước khi dùng, tạo mật khẩu ngẫu nhiên khi chưa có và khởi chạy Cloudflare Quick Tunnel. **Không đăng tải file .env, token hoặc mật khẩu lên Modal Volume**.

Khi nhìn thấy đường dẫn `https://...trycloudflare.com` trong terminal, mở `/index.vi.html` hoặc `/index.en.html`. URL Quick Tunnel chỉ là tạm thời, có thể đổi sau reboot và không được xem là địa chỉ vĩnh viễn.

Username: `review`. Mật khẩu nằm riêng trong file Colab `/root/.config/rails8-support-desk-private-review/preview-password.txt` (mode `0600`). Chủ môi trường xem bằng terminal tại Colab:

```bash
cat /root/.config/rails8-support-desk-private-review/preview-password.txt
```

Không nhập mật khẩu vào chat, Git, notebook output công khai hoặc HTML. Người kiểm duyệt chỉ nhận quyền truy cập cần thiết, làm việc độc lập; kiểm duyệt chưa được xem là hoàn tất chỉ vì mở được trang.

## Điều kiện an toàn được kiểm tra

- HTTP GET không có Authorization: **401**.
- GET sau xác thực trên từng workbook: **200**, dữ liệu tải về khớp SHA256 nguyên bản. Mỗi trang có 64 claim và 12 bài KB approved.
- Truy cập đường dẫn ngoài whitelist, kể cả .env, script, checkpoint: **404** sau xác thực.
- POST và PUT: **405**. Không có API upload/export dữ liệu review từ phía server.
- Header bảo mật: `Cache-Control: private, no-store`, CSP giới hạn mọi `connect-src`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`.

Client-side form xuất JSON về **máy của reviewer**, server không lưu nhận định; không autosave. Reviewer phải chủ động tải JSON nháp thường xuyên. Không có Basic Auth rate limit trong server này, do đó cần mật khẩu đủ mạnh và chỉ chia sẻ URL + mật khẩu với người có quyền. Đây là **private temporary preview**, không phải giải pháp xác thực production.

## Backup và giới hạn nghiệm thu

Checkpoint phục hồi review đã được đưa lên Modal Evidence Volume `rails8-support-desk-evidence`, thư mục `20261029/claim64-review-v2-post-reboot/`; đã tải ngược và xác minh trùng byte từng file. Mật khẩu riêng và tunnel runtime **không** nằm trong ZIP.

64 claim độc lập vẫn **chưa có reviewer JSON thật**, chưa có human semantic gold, chưa có owner signoff. Policy-answerability và claim-level release tiếp tục **NOT_RELEASE**, không được bật autonomous answer/business writes hay thay đổi gate sealed80.
