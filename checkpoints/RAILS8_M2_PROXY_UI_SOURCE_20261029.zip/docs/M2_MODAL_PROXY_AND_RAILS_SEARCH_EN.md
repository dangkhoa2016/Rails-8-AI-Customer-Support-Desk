# M2 — Modal Proxy Authentication and Rails AI Search (EN)

Verified on **2026-10-29**, Modal profile `bsmith888`, environment `rails-8-ai-customer-support-desk`. No M0/M1 reseeding or reimporting 84 embeddings. The previous 12 approved KB v2 versions and 84 real pgvector vectors are untouched.

## Completed changes

- Both Modal A10G Web Functions were redeployed with `@modal.asgi_app(requires_proxy_auth=True)`.
- Unauthenticated POST to `/embed` and `/rerank` returned **HTTP 401** with `modal-http: missing credentials for proxy authorization`, enforced at the Modal proxy before GPU startup.
- Defense in depth: (1) Modal Proxy Token via `Modal-Key` and `Modal-Secret` headers, then (2) separate bearer app tokens within FastAPI. Both Rails clients fail closed when proxy credentials are absent.
- A bilingual `/kb/ai-search` GET/POST screen for signed-in tenant owner/admin/agent only; viewers are forbidden. POST, CSRF, no-store, filtered query logging, synthetic-only attestation, local demo budget of 20 queries/session with an 8-second cooldown. This **is not a production distributed rate limiter**.
- Live path when enabled: Qwen3-Embedding-4B → approved/tenant/ACL/locale/date-scoped exact cosine pgvector candidates → Qwen3-Reranker-4B → Top-5 evidence with raw logits, distance, citation and SHA256. No AI business writes.
- GPU UI is **off by default**, requiring both proxy credentials and `M2_SEMANTIC_UI_ENABLE=YES`. Rails integration tests mock the model, never incur GPU usage. The earlier 12-case live pilot achieved 12/12 Top-1; do not infer new UI accuracy measurements from mocked tests.

## Operator-only local setup (still required)

A new Proxy Token has **not yet been generated/configured for Rails**. The operator may create it on the Colab terminal directly (avoid pasting secrets in chat):

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
mkdir -p ~/.config/rails8-support-desk-modal
umask 077
modal workspace proxy-tokens create --name rails8-support-desk-ui --json > ~/.config/rails8-support-desk-modal/proxy-token.json
chmod 600 ~/.config/rails8-support-desk-modal/proxy-token.json
python3 script/configure_modal_proxy_credentials.py \
  --token-file ~/.config/rails8-support-desk-modal/proxy-token.json
```

The helper reads the JSON and updates protected `~/.config/rails8-support-desk-modal/rails-client.env` **outside this repository**. Securely remove the temporary JSON file after confirming setup; do not include secrets in Git, archives, public logs or evidence.

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
set -a
source .env.notebook
source ~/.config/rails8-support-desk-modal/rails-client.env
set +a
M2_SEMANTIC_UI_ENABLE=YES bin/rails server -b 127.0.0.1 -p 3068
```

Open `http://127.0.0.1:3068/kb/ai-search` only where loopback access is available. Sign in as a synthetic tenant agent, use synthetic test prompts only, and **do not put the passwordless Rails development app through Cloudflare Quick Tunnel**.

## Outstanding production controls

- Replace passwordless demo sign-in with real user authentication before public hosting.
- Add distributed per-user/IP cost-aware rate limits and an auditable budget; session caps can be bypassed by cookie reset.
- Regex-based PII blocking is not production DLP; do not send customer tickets or sensitive data to Modal.
- The authenticated proxy path still needs a positive real-request test after operator token setup; only negative HTTP 401 tests have been completed so far.
- Modal A10G usage incurs charges even for accepted synthetic queries. Scaling remains configured to zero with one container max for each model.
