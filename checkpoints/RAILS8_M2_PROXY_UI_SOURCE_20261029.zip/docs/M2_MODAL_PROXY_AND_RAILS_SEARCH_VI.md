# M2 — Modal Proxy Authentication và giao diện Rails AI Search (VI)

Ngày kiểm chứng: **2026-10-29**. Modal profile `bsmith888`, environment `rails-8-ai-customer-support-desk`. Không chạy lại M0/M1, không import lại 84 embeddings. 12 KB v2 approved và 84 pgvector vectors giữ nguyên.

## Đã thực hiện

- Hai Modal Web Functions sử dụng `@modal.asgi_app(requires_proxy_auth=True)`, deployment thành công trong environment trên.
- POST `/embed` và `/rerank` không có Modal Proxy Token đều trả **HTTP 401** với `modal-http: missing credentials for proxy authorization`. Đây là kiểm thử tầng Modal proxy, request bị chặn trước GPU container.
- Bảo vệ 2 tầng: (1) Modal Proxy Token (headers `Modal-Key` + `Modal-Secret`) và (2) bearer token riêng trong FastAPI. Rails clients yêu cầu cả hai bộ credentials, fail-closed.
- Rails có `/kb/ai-search` GET/POST, UI VI/EN, cho phép owner/admin/agent của tenant đang đăng nhập, cấm viewer. Form POST, CSRF, no-store, query lọc khỏi Rails logs, thử nghiệm synthetic-only có attestation, giới hạn 20 request/session và ít nhất 8 giây giữa các request. Đây là **hạn mức phiên demo**, không phải distributed production rate limiting.
- Search dùng model thật khi bật: Qwen3-Embedding-4B → PostgreSQL cosine exact có tenant/ACL/locale/approved/date filters → Qwen3-Reranker-4B → Top-5, logit, cosine, citation, SHA256. Không cập nhật business records.
- Giao diện mặc định **khóa GPU**; không chạy khi chưa có Proxy Token hoặc `M2_SEMANTIC_UI_ENABLE=YES`.
- Security tests chỉ mock model calls, không tốn GPU; thử nghiệm thực trên Modal ở checkpoint trước đã đạt 12/12 Top-1 trong tập 12 câu synthetic. Không suy diễn kết quả benchmark mới cho phiên UI.

## Hoàn thành bước cuối để bật UI local

Modal hiện có Web Function proxy authorization, nhưng **chưa tạo/cấu hình Proxy Token mới cho Rails**. Lệnh sau dành cho người vận hành thực hiện trực tiếp ở terminal Colab (có thể in secret, tuyệt đối không copy output vào chat):

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
mkdir -p ~/.config/rails8-support-desk-modal
umask 077
modal workspace proxy-tokens create --name rails8-support-desk-ui --json > ~/.config/rails8-support-desk-modal/proxy-token.json
chmod 600 ~/.config/rails8-support-desk-modal/proxy-token.json
python3 script/configure_modal_proxy_credentials.py \
  --token-file ~/.config/rails8-support-desk-modal/proxy-token.json
```

Lệnh chuẩn hóa chỉ đọc JSON token và bổ sung credentials vào file `~/.config/rails8-support-desk-modal/rails-client.env` **ngoài repository**. Xóa bản JSON token gốc sau khi xác minh cấu hình và backup bí mật theo chính sách riêng. Không lưu credentials trong ZIP, Git hoặc evidence.

```bash
cd /content/Rails-8-AI-Customer-Support-Desk
set -a
source .env.notebook
source ~/.config/rails8-support-desk-modal/rails-client.env
set +a
M2_SEMANTIC_UI_ENABLE=YES bin/rails server -b 127.0.0.1 -p 3068
```

Mở `http://127.0.0.1:3068/kb/ai-search` **trên thiết bị có truy cập được loopback đó**, đăng nhập synthetic demo agent và chỉ dùng prompt giả lập. Không mở Rails passwordless login ra Quick Tunnel. Đường dẫn URL chỉ có thể truy cập từ chính runtime hoặc qua công cụ local port forwarding được tin cậy.

## Giới hạn trước production

- Synthetic passwordless sign-in chỉ hợp lệ development/test; cần authentication thật trước public deployment.
- Giới hạn session hiện có thể bị bypass bằng cách xóa cookie; cần distributed rate limiter theo user/IP, quota chi phí và toàn bộ audit before production.
- Kiểm tra PII/regex không thay thế DLP thật. Không đưa ticket, nội dung khách hoặc dữ liệu mật lên Modal ở giai đoạn này.
- Khi có credentials, chạy kiểm thử POST có cả Proxy Token + app bearer (2 tầng), warm/cold costs, và test nội bộ Rails live; hiện không tuyên bố test authenticated request qua proxy đã PASS.
- Modal GPU A10G vẫn là tài nguyên có tính phí; scale to zero, max một container mỗi service.
