#!/usr/bin/env python3
"""Read a user-created Modal Proxy Token JSON and configure LOCAL Rails client only.
Never prints credentials, uploads them, or commits them to source control.
"""
import argparse
import json
import os
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument('--token-file', type=Path, required=True)
args = parser.parse_args()
source = args.token_file.expanduser().resolve()
client_dir = (Path.home() / '.config' / 'rails8-support-desk-modal').resolve()
client_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
client_dir.chmod(0o700)
if not source.is_file() or source.stat().st_mode & 0o077:
    raise SystemExit('Proxy token JSON missing or accessible by group/other. Refusing.')
obj = json.loads(source.read_text())
key = obj.get('token_id') or obj.get('tokenId') or obj.get('id')
secret = obj.get('token_secret') or obj.get('tokenSecret') or obj.get('secret')
if not isinstance(key, str) or not re.fullmatch(r'wk-[A-Za-z0-9_-]+', key):
    raise SystemExit('Unexpected Proxy Token ID format; no file changed.')
if not isinstance(secret, str) or not re.fullmatch(r'ws-[A-Za-z0-9_-]+', secret):
    raise SystemExit('Unexpected Proxy Token Secret format; no file changed.')
target = client_dir / 'rails-client.env'
if not target.is_file() or target.stat().st_mode & 0o077:
    raise SystemExit('Rails client configuration missing/insecure; refusing.')
raw = target.read_text()
existing = [line for line in raw.splitlines() if not line.startswith(('MODAL_PROXY_KEY=', 'MODAL_PROXY_SECRET='))]
existing.extend(('MODAL_PROXY_KEY=' + key, 'MODAL_PROXY_SECRET=' + secret))
temp = client_dir / 'rails-client.env.new'
fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w') as handle:
    handle.write('\n'.join(existing) + '\n')
os.replace(temp, target)
print('LOCAL_PROXY_CONFIG_READY; credentials hidden; GPU UI remains disabled until explicitly enabled.')
