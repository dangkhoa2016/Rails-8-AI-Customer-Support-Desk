# M2 — Claim-level evidence sufficiency research pilot (EN)

**Date:** October 29, 2026 (Asia/Ho_Chi_Minh)  
**Status:** `EXPERIMENTAL_COMPLETED_NOT_RELEASE` — offline research only.  
**Decision:** Do NOT enable the claim-level pilot or the failed scope checker on the Cloudflare preview. M2 `BLOCK_PREVIEW_FLAG` remains active.

## 1. Scope and what the models actually do

Prior sealed80 evaluation exposed three unsupported multi-intent acceptances even with the scope-contrast gate and six false abstentions. This experiment explores breaking questions into discrete claims and showing evidence candidates or explicit abstentions **per claim**, instead of interpreting one related article as support for a whole question.

Only the existing, pinned Modal models are used:
- `Qwen/Qwen3-Embedding-4B` revision `5cf2132abc99cad020ac570b19d031efec650f2b`.
- `Qwen/Qwen3-Reranker-4B` revision `22e683669bc0f0bd69640a1354a6d0aebcfeede5`.

These models perform retrieval and reranking; they **do not reliably decompose questions, prove logical entailment or generate a grounded answer**. Every atomic claim in this evaluation was **manually authored**, and its pre-inference developer label was not independently adjudicated. No additional generator/NLI model was deployed.

## 2. Implemented Rails service

`KnowledgeClaimEvidencePilot.evaluate` accepts a limited array of human-specified `Claim.new(id:, text:)` values and requires `privacy_reviewed: true`. Validations enforce agent/admin/owner, allowed synthetic tenant, vi/en, at most three claims, bounded length/IDs, pinned model revisions and corpus-policy integrity **before outbound GPU inference**. Rejects email/URL/phone-like strings and invalid inputs; the manual privacy review remains compulsory.

For each claim: existing authorized `KnowledgeRerankedRetrieval` obtains 12 tenant/ACL/locale/approved-version/digest/date-checked candidates → previous relevance gate 7.421875 → conditional scope contrast on the same top article using the fixed 5.05078125 margin. Returns only:
- `evidence_candidate_human_review_required`: citations with version identifiers, SHA256 and raw score, **not proof of semantic entailment**;
- `abstain_no_qualified_evidence`: conservative refusal to suggest evidence, **not proof the request is untrue**.

An overall `all_have_candidates` / `partial_candidates` / `no_candidates` value describes retrieval coverage, **never approval or answerability**. The explicit decision remains `NO_AUTONOMOUS_ANSWER_HUMAN_REVIEW_REQUIRED`. No controller integration, business writes, KB approval, subscription/return/refund/plan changes, automatic replies or preview exposure.

## 3. Frozen evaluation: 32 parent questions / 64 atomic claims

Developer-authored before inference: 8 parent questions each for TeamFlow VI, TeamFlow EN, NovaMart VI, NovaMart EN; each parent contains exactly two manual atomic claims. Gold distribution **32 supported-policy and 32 unsupported-policy claims**, plus a separate 8 fully supported / 24 partially or entirely unsupported parent-question distribution.

The same 32 whole questions were first evaluated with the existing combined gate. Their 64 atomic claims were then evaluated via the new claim-level pilot, for a total of 96 retrieval queries. The model thresholds remained frozen.

| Classification | Whole question (32) | Atomic claim (64) |
|---|---:|---:|
| Positive gold | 8 | 32 |
| Negative gold | 24 | 32 |
| TP | 8 | 15 |
| FP | 2 | 0 |
| FN | 0 | 17 |
| TN | 22 | 32 |
| Precision on accepted cases | 80.0% | 100.0% in this small set |
| Recall on supported cases | 100.0% | **46.9%** |

**These are different units of assessment, not directly comparable accuracy measurements.** The zero atomic false positives are confined to 32 hand-written negative claims and cannot establish future safety. The combined strict gates fail to recover 17 of 32 positive claims.

- Only **4/8** fully supported parent questions had evidence candidates for both claims.
- Only **6/16** mixed-intent parents produced exactly one candidate and one abstention; this cannot justify autonomous intent decomposition.
- Correct supported claim candidates / 8 by stratum: TeamFlow VI **1/8**; TeamFlow EN **3/8**; NovaMart VI **4/8**; NovaMart EN **7/8**.
- Many false abstentions occur at relevance gating or scope contrast when a short atomic clause receives different raw logits than the longer question. We did **not** lower any threshold after seeing these results.

**Measured Modal invocation costs and latency, not actual billed USD:**
- 96 Embedding-4B requests and 126 Reranker-4B calls, involving **1,392 query/document pairs**.
- Wall-clock **197.384 seconds**, including cold start, sequential single-instance execution.
- Combined 32 whole-question run time **92.753 seconds**, the 64 claim-level phase **104.427 seconds**; the combined two-phase experiment was ~**2.13×** the whole-question phase in this specific run. Human decomposition/annotation time is excluded.
- Measured client embedding wait/inference **74.387 seconds**, reranker wait/inference **117.454 seconds**.
- PostgreSQL before/after unchanged: **100 articles, 212 versions, 12 approved versions, 84 embeddings**.

## 4. Source, audit and independent human validation

- `review/m2_claim_level_manual32x2_lockbox_20261029.json`: frozen developer-authored manifest, SHA256 `3658b220b04b0cf10ea15ada29a7f734eea16b368574a17a5217c105548bf17f`.
- `evidence-m2-claim32x2-20261029/claim32x2-live.jsonl`: per-parent and per-claim results, SHA256 `7193ce8d7afb3464045eb868fdff60a7736b1bf70dd0593d4e8cb7c72a490375`.
- `evidence-m2-claim32x2-20261029/claim32x2-report.json`: confusion metrics, model invocation counts, latency, DB before/after; SHA256 `434a073d388070d394e5282ad35f9ec73859debddaa374e4fc96f0dea0557d00`.
- `evidence-m2-claim32x2-20261029/claim-level-review.html`: standalone static per-claim review dashboard, tenant/language filters, citations and developer-gold comparisons; SHA256 `21a4f8dee67eb22d9ffeae6e1b148da9ea0ecddd0511b1398e8007bcc4b12993`.
- `evidence-m2-claim32x2-20261029/claim-level-blind-human-validation.json`: **64 PENDING human tasks without the original gold labels**, designed for independent manual inspection; SHA256 `5562d8a92fbd436b1c1485c820a0615f696c69f8505668b8b71d00fed975219d`.
- `script/verify_m2_claim_level_manual32x2_live.rb`, `script/render_m2_claim_level_review.py`, `script/build_m2_claim_blind_human_queue.py`.
- `app/services/knowledge_claim_evidence_pilot.rb` and `test/services/knowledge_claim_evidence_pilot_test.rb`.

**Rails full regression:** **78 tests / 4,424 assertions / zero failures, errors or skips**.

## 5. Limitations and continuation

1. Keep the existing password-gated Cloudflare preview on **relevance-only**, with previous sealed80 scope gate blocked. Do not expose claim-level research results to customer-facing services.
2. The pilot shows how to **present evidence coverage and gaps** for human support staff, not that a policy claim is logically entailed. Recall is inadequate, especially for TeamFlow Vietnamese.
3. A future, separately approved feasibility study may select a decomposition-capable and grounded entailment/NLI model on Modal. It must test license, GPU costs, cold start, latency, privacy, prompt injection, bounded JSON output, multilingual coverage, tenant/role isolation and failure modes **before deploying**. None was deployed here.
4. Have independent humans evaluate the gold-label-free queue against the exact approved KB versions, then create **new** development/calibration examples and an untouched holdout. Never tune on the opened lockboxes and claim a fresh test.
5. Preserve M0 policy v1.0.0, approved M1/M2 baselines, read-only synthetic environment, provenance, and backup/rollback. No Git commit/push or business writes in this research stage.

**Exact next step:** independent manual assessment + design review for grounded claim extraction/entailment; still **NOT_RELEASE**.
