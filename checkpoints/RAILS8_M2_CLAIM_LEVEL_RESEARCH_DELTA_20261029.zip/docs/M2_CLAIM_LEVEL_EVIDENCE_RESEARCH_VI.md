# M2 — Claim-level evidence sufficiency research pilot (VI)

**Ngày:** 2026-10-29 (Asia/Ho_Chi_Minh)  
**Trạng thái:** `EXPERIMENTAL_COMPLETED_NOT_RELEASE`.  
**Quyết định:** Không bật trên Cloudflare preview; M2 scope gate vẫn `BLOCK_PREVIEW_FLAG`; chưa chứng minh entailment, chưa có model tách ý tự động.

## 1. Bối cảnh và nguyên tắc

Bộ sealed 80 câu trước cho thấy relevance-only có 6 false positives, scope contrast vẫn còn 3 false positives, 6 false abstentions. Hướng thử nghiệm mới **tách từng yêu cầu để yêu cầu người phụ trách xác minh riêng**. Chỉ hai model pinned trước đây được dùng:
- `Qwen/Qwen3-Embedding-4B`, revision `5cf2132abc99cad020ac570b19d031efec650f2b`
- `Qwen/Qwen3-Reranker-4B`, revision `22e683669bc0f0bd69640a1354a6d0aebcfeede5`

**Không có model decomposition hay LLM inference mới.** Trong thử nghiệm, 32 câu hỏi synthetic (8 cho mỗi tổ hợp TeamFlow/NovaMart × VI/EN) được biên soạn từ đầu, mỗi câu có **hai yêu cầu nguyên tử được viết thủ công**. Các nhãn trong manifest đã chốt trước GPU: 32 supported policy claims và 32 unsupported in approved KB. Bộ nhãn do bên triển khai tạo, **chưa được human assessment độc lập**.

## 2. Phần đã triển khai

`KnowledgeClaimEvidencePilot.evaluate` là service Ruby độc lập, **không nối vào controller/Cloudflare**. Input là `KnowledgeClaimEvidencePilot::Claim.new(id:, text:)` từ người phụ trách đã xác nhận là synthetic. Bắt buộc `privacy_reviewed: true`, agent/admin/owner, tenant cho phép, ngôn ngữ vi/en, 1–3 claim, kích thước và ID hợp lệ, model revision đúng. Chặn mẫu email/URL/số giống dữ liệu riêng tư; kiểm tra corpus/policy trước GPU.

Với mỗi claim: dùng `KnowledgeRerankedRetrieval` có sẵn để lấy candidate trong **đúng tenant, audience, phiên bản approved, locale, hiệu lực chính sách và SHA256** → áp dụng relevance logit 7.421875 → thử scope margin 5.05078125 trên chính bài KB Top-1 khi đã qua relevance. Chỉ trả:
- `evidence_candidate_human_review_required` + các citation/sha256 đã qua lọc; **không được hiểu là khẳng định chính sách hoàn toàn hỗ trợ claim**.
- `abstain_no_qualified_evidence` khi thiếu bằng chứng đạt ngưỡng; **không kết luận thông tin đó là sai**.

Kết quả tổng chỉ là `all_have_candidates`, `partial_candidates`, `no_candidates`; trường `decision=NO_AUTONOMOUS_ANSWER_HUMAN_REVIEW_REQUIRED` luôn được ghi. Không tạo/sửa ticket, order, subscription, refund, approval, KB hoặc embeddings. Fail-closed khi security/corpus/model/Modal bất thường. Không thay đổi UI, routes hay feature flag đã nghiệm thu.

## 3. Benchmark thực trên Modal (96 retrieval queries)

Chạy **32 câu hỏi nguyên vẹn** bằng combined gate cũ để so sánh, sau đó **64 atomic claims** qua service mới (tổng 96 retrieval queries). Chạy tuần tự 1 instance, không random sampling; có SHA256 manifest và mỗi claim, hash output, citation và logit. Ngưỡng khóa trước inference, không tối ưu hậu nghiệm.

| Đo lường | Nguyên câu hỏi (32) | Từng claim (64) |
|---|---:|---:|
| Gold supported | 8 | 32 |
| Gold unsupported | 24 | 32 |
| True positive | 8 | 15 |
| False positive | 2 | 0 |
| False negative | 0 | 17 |
| True negative | 22 | 32 |
| Precision đề xuất có bằng chứng | 80,0% | 100,0% (mẫu nhỏ) |
| Recall các trường hợp supported | 100,0% | **46,9%** |

**Không so trực tiếp precision/recall giữa hai cột như cùng một bài toán:** cột một chấm đủ bằng chứng cho toàn câu, cột hai chấm từng phần, nhãn và đơn vị khác nhau. Claim-level không có false positive *trong 32 negative developer-authored này*, không bảo đảm FPR=0 trên dữ liệu khác.

- Chỉ **4/8** câu được hỗ trợ hoàn toàn có đủ candidate đúng cho cả hai claim.
- **6/16** câu mixed-intent xuất hiện đúng dạng có một candidate và một claim bị từ chối; không đủ để công bố phân tích tự động đáng tin cậy.
- Theo tenant/ngôn ngữ, số policy claim đúng / 8: TeamFlow VI **1/8**, TeamFlow EN **3/8**, NovaMart VI **4/8**, NovaMart EN **7/8**. Có chênh lệch đáng kể.
- Phần lớn false abstention thuộc relevance cutoff hoặc scope contrast vốn hiệu chỉnh theo query nguyên vẹn, không phù hợp với dạng atomic ngắn. **Không được hạ ngưỡng dựa trên lockbox đã lộ**.

**Chi phí quan sát được (không phải hóa đơn Modal USD):**
- **96 lượt Embedding-4B**, **126 lượt Reranker-4B**, **1.392 document–query pairs**.
- Tổng wall **197,384 giây** gồm cold start (1 instance), trong đó lượt đánh giá 32 full questions cộng lại **92,753 giây**, 64 atomic claims **104,427 giây**. Tổng pipeline hai pha ~**2,13 lần** chỉ chạy full questions với cùng 32 đầu vào trong benchmark này (không bao gồm thời gian con người tách ý/gán nhãn).
- Thời gian request theo client: Embedding **74,387 giây**, reranker **117,454 giây** (tổng thời gian mạng/inference quan sát; không phải GPU billable time).
- DB trước/sau không đổi: **100 KnowledgeArticle / 212 versions / 12 approved / 84 embeddings**.

## 4. Bằng chứng và công cụ xem xét

- `review/m2_claim_level_manual32x2_lockbox_20261029.json` — manifest đã đóng băng, SHA256 `3658b220b04b0cf10ea15ada29a7f734eea16b368574a17a5217c105548bf17f`
- `evidence-m2-claim32x2-20261029/claim32x2-live.jsonl` — từng case + từng claim, SHA256 `7193ce8d7afb3464045eb868fdff60a7736b1bf70dd0593d4e8cb7c72a490375`
- `evidence-m2-claim32x2-20261029/claim32x2-report.json` — metrics, actual inference calls, model pin, thời gian, DB before/after, SHA256 `434a073d388070d394e5282ad35f9ec73859debddaa374e4fc96f0dea0557d00`
- `evidence-m2-claim32x2-20261029/claim-level-review.html` — trang HTML tĩnh tổng hợp 32 câu, lọc tenant/ngôn ngữ, hiển thị candidate, citations và lỗi; SHA256 `21a4f8dee67eb22d9ffeae6e1b148da9ea0ecddd0511b1398e8007bcc4b12993`
- `evidence-m2-claim32x2-20261029/claim-level-blind-human-validation.json` — **64 tác vụ human validation** (để trạng thái PENDING, cố ý **không chứa gold labels** để có thể kiểm tra độc lập), SHA256 `5562d8a92fbd436b1c1485c820a0615f696c69f8505668b8b71d00fed975219d`
- `script/verify_m2_claim_level_manual32x2_live.rb`, `script/render_m2_claim_level_review.py`, `script/build_m2_claim_blind_human_queue.py`.
- `app/services/knowledge_claim_evidence_pilot.rb`, `test/services/knowledge_claim_evidence_pilot_test.rb`.

**Rails regression:** **78 tests, 4.424 assertions, 0 failures / 0 errors / 0 skips**.

## 5. Kết luận, hạn chế và điều kiện trước khi triển khai tiếp

1. Giữ nguyên Rails preview **relevance-only**, khóa `M2_ANSWERABILITY_SCOPE_ENABLE` do bộ sealed80 FAIL. **Không tích hợp service claim-level vào public preview**.
2. Claim-level chỉ cải thiện khả năng trình bày **vùng thiếu bằng chứng để nhân viên duyệt**. Không đủ dữ liệu chứng minh semantic entailment; precision 100% trên 32 negative nhỏ không khắc phục recall thấp.
3. Có thể đánh giá một model chuyên dụng cho **decomposition và grounded NLI/entailment** trên Modal, nhưng trước khi chọn/deploy cần nghiệm thu model license, phí GPU, cold start, độ trễ, chính sách PII, prompt injection, nhãn EN/VI, bounded claims và chuẩn JSON. **Chưa deploy thêm model**.
4. Cần nhân viên đọc từng approved article v2 và đánh giá độc lập `claim-level-blind-human-validation.json`, sau đó tạo tập dev/calibration mới và một holdout *chưa từng được dùng* để đo claim recall/FP thay vì tối ưu theo 32 câu đã mở.
5. Không tự động áp dụng hành động doanh nghiệp hoặc chấp thuận kết quả model. Bảo toàn phiên bản policy, provenance, dữ liệu cloud và Git. Không tạo commit/push trong pilot này.

**Mốc tiếp tục:** human blind adjudication + thiết kế model decomposition/NLI nếu được phê duyệt riêng; hiện M2 claim-level là nghiên cứu offline, **NOT_RELEASE**.
