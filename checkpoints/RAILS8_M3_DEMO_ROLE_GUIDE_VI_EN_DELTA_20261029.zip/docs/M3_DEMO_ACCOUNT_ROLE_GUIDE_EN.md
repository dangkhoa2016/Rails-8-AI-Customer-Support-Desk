# M3 — Choosing a demo account and testing Viewer / Agent / Owner

**Scope:** Rails 8 AI Customer Support Desk with synthetic TeamFlow Cloud and NovaMart Store records; 2026-10-29.

## Getting started

1. Open the private Cloudflare demo and enter the private preview password. The password is stored on Colab and is intentionally absent from this document.
2. At `/demo/sign_in`, the **Account** dropdown is grouped by **TeamFlow Cloud** (SaaS) and **NovaMart Store** (e-commerce).
3. Each business has a sample **Viewer**, **Agent**, and **Owner** account. Pick the desired role and VI/EN language, then open the dashboard.
4. Use **Switch account** in navigation to compare roles within one business and then switch tenants.

## Effective Rails permissions

| Feature | Viewer | Agent | Owner |
| --- | --- | --- | --- |
| Tenant-scoped dashboard, customers, support tickets | Yes | Yes | Yes |
| Approved public KB articles | Yes | Yes | Yes |
| Staff-only approved KB and authorized invoice/order lookup | No | Yes | Yes |
| Create/status-update ticket, notes, manually confirmed replies | No | Local development only | Local development only |
| Staff-only manual AI KB Search, when Modal configured | No | Yes | Yes |
| Editorial KB drafts, bilingual comparison and approval UI | No | No | Yes |
| Human-confirmed KB publication | No | No | Local development only |

**Private Cloudflare tunnel:** Read-only for business state mutations. Users may see Agent/Owner controls based on role, but cannot create or update tickets, save replies, or approve KB over the public tunnel. Explore read access, role-based interfaces, and tenant separation without changing synthetic records.

**AI boundaries:** AI search requires a privately configured Modal runtime and never automatically sends customer replies. Sealed80 answerability remains BLOCKED. Public reply storage in Rails requires explicit manual confirmation and does not send external email.

## Suggested walkthrough

- **Viewer:** Open Tickets and Knowledge Base; check the absence of New ticket, AI Search, and KB compare controls.
- **Agent:** Inspect a ticket's note/reply/status controls, and authorized read-only invoice/order links; check that KB editorial approval is unavailable.
- **Owner:** Open Knowledge Base, compare VI/EN draft/published versions, and inspect the approval interface. Do not approve content just to explore the demo.

## Acceptance evidence

- UI and translations: `app/views/demo_sessions/new.html.erb`, `app/views/layouts/application.html.erb`, `config/locales/en.yml`, and `config/locales/vi.yml`.
- Integration tests: `test/integration/demo_account_role_guide_test.rb`, **3 tests / 58 assertions PASS**.
- Entire Rails regression: **87 tests / 4,538 assertions / 0 failures / 0 errors / 0 skips**.
- Local and Cloudflare HTTPS smoke: `test/smoke_demo_account_role_guide.py`; **2 languages / 2 businesses / 6 accounts PASS**, zero business writes.
- Original M3 tickets, M2 vectors and owner-approved 64 synthetic claims are unchanged.
- No Git commit or push in this step.

Vietnamese companion: `docs/M3_DEMO_ACCOUNT_ROLE_GUIDE_VI.md`.
