# M3 — Hướng dẫn chọn tài khoản và thử quyền Viewer / Agent / Owner

**Phạm vi:** Rails 8 AI Customer Support Desk, TeamFlow Cloud và NovaMart Store (dữ liệu giả lập), ngày 2026-10-29.

## Truy cập

1. Mở Cloudflare Private Demo và nhập mật khẩu của cổng preview (được lưu riêng trên Colab, không công bố trong tài liệu).
2. Ở trang `/demo/sign_in`, dropdown **Tài khoản** được chia thành hai nhóm: TeamFlow Cloud (SaaS) và NovaMart Store (thương mại điện tử).
3. Mỗi doanh nghiệp có ba role: Viewer, Agent, Owner. Chọn một role và ngôn ngữ VI/EN, sau đó bấm **Vào dashboard**.
4. Dùng **Đổi tài khoản** trong thanh điều hướng để thử các role và tenant khác.

## Quyền thực tế theo source Rails

| Hành động | Viewer | Agent | Owner |
| --- | --- | --- | --- |
| Xem dashboard, khách hàng và tickets trong tenant hiện tại | Có | Có | Có |
| Xem KB công khai đã approved | Có | Có | Có |
| Xem KB agent đã approved, tra invoice/order dành cho nhân viên | Không | Có | Có |
| Tạo ticket / đổi trạng thái / ghi chú / phản hồi đã xác nhận | Không | Có trên development local | Có trên development local |
| Mở giao diện AI KB Search thủ công (nếu Modal đủ cấu hình) | Không | Có | Có |
| Xem KB nháp, đối chiếu VI/EN và giao diện duyệt KB | Không | Không | Có |
| Duyệt KB theo quy trình xác nhận | Không | Không | Có trên development local |

**Giới hạn của Cloudflare:** cổng private demo đang ở chế độ read-only đối với thay đổi nghiệp vụ. Viewer, Agent và Owner đều không thể ghi ticket, phản hồi hoặc duyệt KB qua tunnel, ngay cả khi các điều khiển xuất hiện cho Agent/Owner. Chỉ kiểm tra giao diện, quyền đọc và cách ly tenant trên URL công khai; không chạy mutation từ Internet.

**Giới hạn AI:** AI Search chỉ hoạt động khi kết nối Modal được cấu hình; nó không gửi phản hồi cho khách. Sealed80 answerability vẫn BLOCKED. Phản hồi công khai lưu trong Rails yêu cầu nhân viên xác nhận thủ công, không có email gửi ra bên ngoài.

## Ba lượt thử đề xuất

- **Viewer:** mở Tickets và Knowledge Base, xác nhận không có nút New ticket, AI Search hoặc KB compare.
- **Agent:** xem chi tiết ticket, điều khiển ghi chú/trả lời/đổi trạng thái và link invoice/order read-only; xác nhận không có giao diện duyệt KB.
- **Owner:** mở Knowledge Base và giao diện so sánh KB VI/EN/draft; kiểm tra nút duyệt chỉ trong giao diện, không tự duyệt nội dung mẫu khi xem demo.

## Nghiệm thu

- HTML/CSS và bản dịch được đặt trong `app/views/demo_sessions/new.html.erb`, `app/views/layouts/application.html.erb`, `config/locales/vi.yml` và `config/locales/en.yml`.
- `test/integration/demo_account_role_guide_test.rb`: **3 tests / 58 assertions PASS**.
- Toàn bộ Rails suite: **87 tests / 4.538 assertions / 0 failures / 0 errors / 0 skips**.
- `test/smoke_demo_account_role_guide.py`: localhost và Cloudflare HTTPS **PASS**, 2 ngôn ngữ, 2 doanh nghiệp, 6 accounts, 0 business mutations.
- Dữ liệu M3 240 tickets, M2 84 embeddings và quyết định chấp thuận 64 claims vẫn giữ nguyên.
- Không commit hoặc push Git trong lượt này.

Tài liệu tiếng Anh: `docs/M3_DEMO_ACCOUNT_ROLE_GUIDE_EN.md`.
