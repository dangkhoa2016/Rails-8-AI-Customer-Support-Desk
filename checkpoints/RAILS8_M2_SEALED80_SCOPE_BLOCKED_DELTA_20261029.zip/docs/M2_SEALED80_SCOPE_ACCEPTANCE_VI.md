# M2 — Đánh giá sealed 80 câu hỏi và chốt an toàn preview (VI)

**Thời điểm:** 2026-10-29 (Asia/Ho_Chi_Minh).  
**Trạng thái:** Hoàn tất thử nghiệm, **BLOCK_PREVIEW_FLAG**. Không nghiệm thu M2 answerability cho Cloudflare preview.  
**Phạm vi:** Hai doanh nghiệp *synthetic* TeamFlow Cloud và NovaMart Store; nhân viên dùng AI để tra bằng chứng, không cho AI quyết định nghiệp vụ hoặc gửi lời đáp tự động.  
**Giữ nguyên:** M0 policy v1.0.0, M1 DB, M2 live 4B/4B đã nghiệm thu trước. Không tái chạy, sửa hoặc mất hiệu lực các kết quả PASS cũ.

## 1. Câu hỏi cần kiểm chứng

Kết quả Top-1 có thể đúng chủ đề nhưng vẫn không đủ bằng chứng để thực hiện toàn bộ yêu cầu, đặc biệt các lời hứa **thời hạn chính xác**, **bồi thường tự động**, **đổi hãng giao**, **sử dụng điểm thưởng**. Chỉ số similarity/rerank logit không phải xác suất hoặc chứng minh suy luận entailment.

Hai phương án được so sánh trên cùng một lượt retrieval GPU cho mỗi câu:

1. **Baseline:** embedding Qwen3-Embedding-4B → pgvector candidate retrieval → Qwen3-Reranker-4B → relevance cutoff logit **7.421875**.
2. **Combined:** giữ baseline, sau đó thêm **một** lượt rerank cho bộ 8 câu synthetic cùng bài KB/cùng ngôn ngữ (4 câu được hỗ trợ + 4 câu không được hỗ trợ), lấy margin lớn nhất giữa nhóm được hỗ trợ và không được hỗ trợ; cutoff **5.05078125**. Ngưỡng đã chốt từ thí nghiệm trước; không hiệu chỉnh theo sealed 80.

Cả hai phương án giữ tenant/role/locale/approval/digest/date isolation, pinned model revisions và privacy review trước khi gọi Modal. Không có LLM viết câu trả lời.

## 2. Thiết kế lockbox, kiểm soát leakage

- **80 câu mới do nhóm triển khai biên soạn**, có nhãn cố định **trước** inference. Không có người gán nhãn độc lập; do đó đây là challenge set synthetic chứ không phải dataset đánh giá khách quan toàn ngành.
- Mỗi tổ hợp TeamFlow VI, TeamFlow EN, NovaMart VI, NovaMart EN có **5 supported**, **9 mixed-intent unsupported** và **6 unsupported_close**. Tổng cộng 20 supported, 60 unsupported.
- Nhãn *supported* nghĩa là bài KB approved đủ thông tin để hướng dẫn phần chính sách của **toàn bộ** câu hỏi; câu hỏi nhiều ý mà chỉ một phần có bằng chứng được đánh dấu unsupported. Đây là quy ước chấm điểm nghiêm ngặt, không phủ nhận khả năng nhân viên trả lời một phần kèm từ chối phần còn lại.
- Điều kiện bật scope gate trên preview đã được khóa trước: **0 false positive và ít nhất 80% recall ở nhóm supported**; không thay đổi threshold dựa trên câu trả lời.
- Manifest SHA256 cố định: `13ab3412404239a6bc3232ca1598cb12b00db1bf29f5d6226ae3a4d9f88ed20a`.
- Pipeline serial, 1 instance, không random sampling; 80/80 truy vấn qua model thật. Không có dữ liệu khách hàng.

## 3. Kết quả thật

| Loại kết quả | Relevance only | Relevance + Scope |
|---|---:|---:|
| Supported đúng, chấp nhận đúng (TP) | 14 | 14 |
| Unsupported nhưng vẫn chấp nhận (FP) | 6 | 3 |
| Supported bị từ chối (FN) | 6 | 6 |
| Unsupported bị từ chối đúng (TN) | 54 | 57 |
| Precision trên đề xuất được chấp nhận | 70,0% | 82,35% |
| Recall trên supported | 70,0% | 70,0% |
| Specificity trên unsupported | 90,0% | 95,0% |

**Theo tenant/ngôn ngữ (combined):**

| Nhóm | TP / supported | FP / unsupported |
|---|---|---|
| TeamFlow VI | 3/5 | 0/15 |
| TeamFlow EN | 3/5 | 1/15 |
| NovaMart VI | 3/5 | 1/15 |
| NovaMart EN | 5/5 | 1/15 |

**Ba false positives còn lại:**
- `M3S-TF-EN-08` — Invoice paid/activation chưa succeeded nhưng yêu cầu *guaranteed resolution deadline* và *auto-issue service credits*. TF-KB-012 không hỗ trợ hai lời hứa đó; raw logit **7.53125**.
- `M3S-NM-VI-10` — Có ước lượng 2–5 ngày sau handoff nhưng yêu cầu cam kết hàng đến trước 09:00 sáng hôm sau. NM-KB-020 không cho phép cam kết giờ; raw logit **7.875**.
- `M3S-NM-EN-10` — Cùng kiểu yêu cầu cam kết trước buổi trưa ngày mai. NM-KB-020 không hỗ trợ; raw logit **8.78125**.

**Sáu false abstentions:** `M3S-TF-VI-03`, `-05`, `M3S-TF-EN-03`, `-05`, `M3S-NM-VI-03`, `-05`. Tất cả có đúng bài KB là raw Top-1 nhưng logit chỉ **5.2734375–7.0**, dưới relevance cutoff 7.421875. Do đó lỗi nằm ở giai đoạn relevance gate, **chưa hề gọi scope verifier**.

Scope gate đã chặn **3 false positives** so với baseline (`M3S-NM-VI-11`, `-13`, `M3S-NM-EN-09`), nhưng chưa đạt yêu cầu tổng thể. Không được biến các câu này thành heuristic hard-coded.

## 4. GPU và bất biến dữ liệu

- Qwen3-Embedding-4B revision `5cf2132abc99cad020ac570b19d031efec650f2b`.
- Qwen3-Reranker-4B revision `22e683669bc0f0bd69640a1354a6d0aebcfeede5`.
- Tổng thời gian đánh giá ~**219.65 giây**; lượt đầu cold **103.581 giây**. Thời gian trung bình cả cold+warm **2.744 giây/lượt**; không dùng các giá trị này làm SLA.
- DB trước/sau **100 articles, 212 versions, 12 approved versions, 84 embeddings**. Không thay đổi dữ liệu, không approve KB, không seed/reset, không deploy lại model.
- Full Rails regression sau thay đổi: **75 tests, 4.411 assertions, 0 failures, 0 errors, 0 skips**.

## 5. Interlock trên Rails

Có thêm `KnowledgeScopePreviewGate.eligible?` đọc manifest/evidence và kiểm tra model pin, policy fingerprint, hash, confusion metrics và integrity các case. Khi `M2_ANSWERABILITY_SCOPE_ENABLE=YES` mà sealed gate chưa đạt, `KnowledgeAISearchController` trả **503** cho search thay vì gọi GPU hoặc âm thầm bỏ scope verifier. UI hiển thị thông báo VI/EN.

Cờ này **OFF** trong Cloudflare preview đang chạy; các tính năng relevance-only hiện hữu giữ nguyên nhưng chỉ dùng làm **gợi ý bằng chứng cần nhân viên xem xét**, không thể công bố khả năng trả lời an toàn mọi câu hỏi. Không đánh đồng test local với test HTTP qua Cloudflare. Không có browser end-to-end mới đối với scope flag ON vì acceptance đã FAIL.

## 6. Nguồn bằng chứng và SHA256

- `review/m2_scope_sealed_challenge80_20261029.json` SHA256 `13ab3412404239a6bc3232ca1598cb12b00db1bf29f5d6226ae3a4d9f88ed20a`
- `evidence-m2-sealed80-20261029/sealed80-live-results.jsonl` SHA256 `df5cd6f88b2b917f675cb26323ac1f1cb39e7126817c63d0c60a6347f6cba8ab`
- `evidence-m2-sealed80-20261029/sealed80-acceptance.json` SHA256 `d1e3513d8b90f2899efe18dfd6eee59cf86b74043bf22c3786501e23feeaa9a1`
- `evidence-m2-sealed80-20261029/failure-analysis.json` SHA256 `9fcd7914331d89499535443dd416bbdbb9116b61764e7b992061b1638a41a03e`
- `evidence-m2-sealed80-20261029/full-rails-tests.log`
- `script/verify_m2_scope_sealed80_live.rb`
- `app/services/knowledge_scope_preview_gate.rb`

Không rerun vào chính đường dẫn evidence cũ; runner từ chối overwrite. Khi cần thử phương án mới, tạo manifest/calibration/holdout **mới** và tên output mới để không huấn luyện trực tiếp trên lockbox đã mở.

## 7. Việc còn mở / quyết định tiếp theo

1. Không bật scope verification trên Cloudflare preview. Giữ nguyên ngưỡng và baseline có ghi chú *AI assist only*.
2. Thiết kế query decomposition / claim-level evidence sufficiency: kiểm tra từng yêu cầu của câu hỏi riêng biệt, trả *partial-support / unsupported*, không sinh cam kết sai. Việc gọi thêm model hoặc triển khai model mới cần định lượng chi phí, an toàn, latency và review riêng.
3. Giảm false abstention bằng calibration trên **tập phát triển mới**, rồi kiểm chứng trên **sealed holdout chưa từng sử dụng**, thay vì giảm threshold dựa vào 6 câu của test này.
4. Cần đánh giá độc lập từ con người về nhãn supported/unsupported, mẫu thật được khử PII với sự cho phép, multi-tenant ACL và reliability trước production.
5. Chỉ xem xét lại preview scope gate sau khi có chứng cứ độc lập mới; tuyệt đối không chỉnh nội dung kết quả hiện có để vượt gate.

**Không Git commit/push; không production-ready.**

## 8. Khôi phục Cloudflare Quick Tunnel (preview relevance-only, không bật scope)

Trong bước kiểm tra cuối, hostname Quick Tunnel cũ hết hạn/không phân giải DNS. Đã tạo **Quick Tunnel mới**, giữ nguyên server Rails cũ cổng 3068 và mở **một server riêng cổng 3069** với middleware mật khẩu mạnh và exact-host allowlist. Biến môi trường private được sao lưu và cập nhật quyền file 0600; không đưa mật khẩu/token vào repository hoặc evidence.

**Kiểm thử HTTPS thật trên tunnel mới (2026-10-29):**
- Trang đăng nhập private: HTTP **200**.
- Truy cập AI Search chưa xác thực: **303** về private sign-in.
- Sai mật khẩu: trang 200 có cảnh báo; mật khẩu hợp lệ: **303**.
- Đăng nhập synthetic TeamFlow agent: **302**.
- Mở AI Search: **200**, form hoạt động.
- POST approve bài KB và POST tạo ticket: **405**, nghiệp vụ không được ghi.
- Prompt chứa email: **422**, bị từ chối trước GPU.
- Một câu synthetic TeamFlow qua HTTPS/Modal thật: **PASS_REAL_4B_4B**, Top-1 `TF-KB-012`, 5 citations, ~**41.179 giây** (cold start). Đây là acceptance của **relevance-only baseline**, KHÔNG phải acceptance của scope flag.

File bằng chứng: `evidence-m2-sealed80-cloudflare-preview-20261029/tunnel-access-only-sealed80.json` và `tunnel-positive-ai-sealed80.json`. URL Quick Tunnel là **tạm thời**, xem trong evidence/runtime; không đóng đinh vào docs/repo. Flag `M2_ANSWERABILITY_SCOPE_ENABLE` của server preview mới là `NO`; nếu ai bật `YES` trong trạng thái sealed 80 hiện tại, Rails interlock từ chối trước GPU.

Lưu ý: việc khôi phục đường preview **không thay đổi quyết định BLOCK_PREVIEW_FLAG**. Preview chỉ là công cụ quan sát bằng chứng synthetic dành cho người có mật khẩu, không đủ điều kiện production.
