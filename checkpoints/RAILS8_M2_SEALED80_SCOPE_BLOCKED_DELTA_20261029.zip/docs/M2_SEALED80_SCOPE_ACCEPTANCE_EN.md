# M2 — Sealed 80-Question Scope Evaluation and Preview Interlock (EN)

**Date:** October 29, 2026 (Asia/Ho_Chi_Minh).  
**Status:** Evaluation complete, **BLOCK_PREVIEW_FLAG**. Experimental answerability scope checking is NOT approved for the Cloudflare preview.  
**Applies to:** Synthetic TeamFlow Cloud and NovaMart Store, human-assisted KB evidence suggestions only. No autonomous answers or business writes.  
**Preservation:** Prior approved M0 policy v1.0.0, M1 database, existing M2 model/runtime acceptance and prior passing tests remain intact.

## 1. What was evaluated

A top-ranked KB excerpt can be topically relevant without supporting every part of a multi-intent question, especially requests for guaranteed resolution or delivery times, automatic compensation, courier changes, loyalty redemption, or refunds.

Two strategies were evaluated using a *single* real retrieval roundtrip per question:

1. **Baseline:** pinned Qwen3-Embedding-4B → pgvector retrieval → pinned Qwen3-Reranker-4B → raw reranker logit cutoff **7.421875**.
2. **Combined:** baseline plus one additional reranker call comparing 4 human-written in-scope versus 4 near-topic out-of-scope synthetic probe questions belonging to the same approved article and locale. The fixed best-score margin cutoff was **5.05078125**. No cutoff was re-fitted after inspecting the sealed challenge.

Retrieval still enforces tenant, role, locale, approved-version, content digest, policy-date and Modal proxy boundaries. This is **not** claim-level entailment verification.

## 2. Frozen challenge and safeguards

- **80 newly authored synthetic questions** with fixed labels *before* GPU inference. Labels were not independently adjudicated, so this is a developer-authored challenge set, not an unbiased real-world benchmark.
- Each tenant/locale stratum (TeamFlow VI, TeamFlow EN, NovaMart VI, NovaMart EN) contains **5 fully supported**, **9 mixed-intent unsupported**, and **6 near-domain unsupported** cases: 20 positives and 60 negatives total.
- Strict full-question criterion: a multi-intent query is unsupported if any requested outcome lacks KB evidence, even when a safe **partial answer** might be possible with a human agent.
- Pre-registered scope-preview release rule: **zero false positives** AND **at least 80% supported recall**, with no post-hoc threshold changes.
- Sealed manifest SHA256: `13ab3412404239a6bc3232ca1598cb12b00db1bf29f5d6226ae3a4d9f88ed20a`.
- 80 real sequential GPU queries; one execution instance; no random query sampling and no real customer data.

## 3. Results

| Measure | Relevance baseline | Combined gates |
|---|---:|---:|
| Supported correctly accepted (TP) | 14 | 14 |
| Unsupported incorrectly accepted (FP) | 6 | 3 |
| Supported wrongly withheld (FN) | 6 | 6 |
| Unsupported correctly rejected (TN) | 54 | 57 |
| Precision of accepted suggestions | 70.0% | 82.35% |
| Recall among supported requests | 70.0% | 70.0% |
| Specificity among unsupported requests | 90.0% | 95.0% |

**Combined performance by tenant/locale:**

| Stratum | TP / supported | FP / unsupported |
|---|---|---|
| TeamFlow VI | 3/5 | 0/15 |
| TeamFlow EN | 3/5 | 1/15 |
| NovaMart VI | 3/5 | 1/15 |
| NovaMart EN | 5/5 | 1/15 |

**Three remaining false positives:**
- `M3S-TF-EN-08`: paid invoice and incomplete plan activation plus a request for a **guaranteed resolution deadline and automatic service credits**. TF-KB-012 supports neither guarantee; raw rerank logit **7.53125**.
- `M3S-NM-VI-10`: estimated two-to-five-business-day delivery plus a request to **guarantee receipt before 09:00 the next morning**. NM-KB-020 does not support exact delivery guarantees; raw logit **7.875**.
- `M3S-NM-EN-10`: a similar delivery question seeking guaranteed arrival by the next day's noon. NM-KB-020 lacks that commitment; raw logit **8.78125**.

**Six false abstentions:** `M3S-TF-VI-03`, `-05`, `M3S-TF-EN-03`, `-05`, `M3S-NM-VI-03`, `-05`. Every one had the **correct approved KB article at raw Top-1**, but reranker logits of **5.2734375–7.0** were below the frozen 7.421875 relevance cutoff. The later scope verifier was not called in these cases.

Scope contrast independently blocked three baseline false positives (`M3S-NM-VI-11`, `-13`, `M3S-NM-EN-09`). The strategy improves rejection, but does not satisfy the release criterion. These specific cases MUST NOT be hard-coded as heuristic rules.

## 4. Runtime, regression, and database integrity

- Qwen3-Embedding-4B pinned revision `5cf2132abc99cad020ac570b19d031efec650f2b`.
- Qwen3-Reranker-4B pinned revision `22e683669bc0f0bd69640a1354a6d0aebcfeede5`.
- Total elapsed ~**219.65 s**; first cold request **103.581 s**. Mean over all 80 requests (including cold): **2.744 s**; not a latency SLA.
- Database before/after: **100 articles, 212 versions, 12 approved versions, 84 embeddings**; no data mutation, reseeding, re-embedding, policy approval, model redeployment or business writes.
- After the preview safety interlock: **75 tests, 4,411 assertions, zero failures/errors/skips**.

## 5. Fail-closed Rails preview interlock

`KnowledgeScopePreviewGate.eligible?` reads the frozen manifest, evidence, per-case result file and pinned model/policy identifiers, rechecks their hashes and performance criteria. If `M2_ANSWERABILITY_SCOPE_ENABLE=YES` but the sealed assessment does not pass, `KnowledgeAISearchController` returns **503** without a GPU request, rather than silently bypassing the scope check. The UI presents an EN/VI explanation.

The live Cloudflare preview continues with the scope flag **OFF** and the existing relevance-only, human-review search. This does not establish comprehensive answerability, and the preview must remain clearly experimental. There was **no** new Cloudflare browser end-to-end test with the scope flag ON because the release criterion failed. Local Rails regression validates the interlock.

## 6. Evidence and provenance

- `review/m2_scope_sealed_challenge80_20261029.json` SHA256 `13ab3412404239a6bc3232ca1598cb12b00db1bf29f5d6226ae3a4d9f88ed20a`
- `evidence-m2-sealed80-20261029/sealed80-live-results.jsonl` SHA256 `df5cd6f88b2b917f675cb26323ac1f1cb39e7126817c63d0c60a6347f6cba8ab`
- `evidence-m2-sealed80-20261029/sealed80-acceptance.json` SHA256 `d1e3513d8b90f2899efe18dfd6eee59cf86b74043bf22c3786501e23feeaa9a1`
- `evidence-m2-sealed80-20261029/failure-analysis.json` SHA256 `9fcd7914331d89499535443dd416bbdbb9116b61764e7b992061b1638a41a03e`
- `evidence-m2-sealed80-20261029/full-rails-tests.log`
- `script/verify_m2_scope_sealed80_live.rb`
- `app/services/knowledge_scope_preview_gate.rb`

The sealed runner refuses to overwrite existing result files. Future changes need an independently authored development/calibration set and a genuinely new sealed holdout, not optimization on this disclosed lockbox.

## 7. Continuation priorities

1. **Do not enable** the experimental scope checker on Cloudflare preview; preserve the relevance-only human-assist baseline with clear evidence-not-answer warnings.
2. Evaluate **query decomposition and claim-level evidence sufficiency**, including explicit partial-support/unsupported labels. Any new inference model or call requires new cost, latency, privacy and safety evaluation.
3. Reduce false abstentions on a NEW development dataset, and measure on a NEW untouched test set. Do not simply lower the cutoff based on these six exposed cases.
4. Obtain independent human labeling, broader multilingual and multi-intent samples, robust tenant isolation/privacy tests and production operational controls.
5. Consider preview activation only after a new frozen acceptance gate and an explicit review of its evidence.

**No Git commits/push. Not production-ready.**

## 8. Cloudflare Quick Tunnel restoration (relevance-only; scope disabled)

Final checks found the old ephemeral Quick Tunnel hostname no longer resolved. A **new Quick Tunnel** was created while preserving the original Rails process on port 3068; a **separate Rails preview on port 3069** uses strong-password middleware, an exact-host allowlist, and write-route blocking. Private environment configuration was backed up with 0600 permissions; no password or proxy credential appears in the repository or evidence.

**Actual HTTPS acceptance (October 29, 2026):**
- Private password page: HTTP **200**.
- Unauthenticated AI Search: **303** redirected to password sign-in.
- Invalid password: warning page; valid password: **303**.
- Synthetic TeamFlow agent login: **302**.
- AI Search page: **200** with an enabled search form.
- KB-approval POST and ticket-creation POST: both **405**; no business writes.
- Query with an email address: **422**, rejected before GPU.
- One authorized synthetic TeamFlow query through HTTPS/real Modal: **PASS_REAL_4B_4B**, Top-1 `TF-KB-012`, 5 citations, ~**41.179 seconds** (cold start). This validates only the **relevance-only baseline**, NOT the failed scope gate.

Evidence: `evidence-m2-sealed80-cloudflare-preview-20261029/tunnel-access-only-sealed80.json` and `tunnel-positive-ai-sealed80.json`. Quick Tunnel hostnames are **ephemeral** and recorded in runtime evidence rather than hard-coded in public documentation. The new preview explicitly uses `M2_ANSWERABILITY_SCOPE_ENABLE=NO`; enabling it with the present failed sealed results causes Rails to deny the request before GPU inference.

Restored preview availability **does not change BLOCK_PREVIEW_FLAG**. This remains a password-gated synthetic evidence demonstration, not a production-safe customer support system.
