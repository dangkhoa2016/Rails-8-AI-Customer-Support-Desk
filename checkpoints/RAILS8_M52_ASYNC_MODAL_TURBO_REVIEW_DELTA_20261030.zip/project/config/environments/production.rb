Rails.application.configure do
  config.enable_reloading = false
  config.eager_load = true
  config.consider_all_requests_local = false
  config.force_ssl = true
  config.log_level = :info
  config.active_support.report_deprecations = false
  config.require_master_key = false
  # No production AI pilot/worker until production authentication is implemented.
  # Production login intentionally unavailable: synthetic-only local demo.
end
