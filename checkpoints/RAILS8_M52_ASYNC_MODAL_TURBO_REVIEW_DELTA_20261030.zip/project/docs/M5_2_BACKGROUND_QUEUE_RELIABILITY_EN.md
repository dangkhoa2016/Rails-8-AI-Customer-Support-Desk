# M5.2 — Reliability & AI Quality (2026-10-30)

## Scope

- Rails 8 AI Customer Support Desk, with synthetic TeamFlow Cloud and NovaMart Store tenants.
- Existing 240 tickets, 440 messages, 84 embeddings and 12 approved KB versions are not modified.
- AI only suggests evidence; never sends customer replies or writes business records.
- The sealed80 answerability gate stays BLOCKED; the 120 candidate cases have no independent human gold labels.
- Modal Qwen3-Embedding-4B and Qwen3-Reranker-4B retain their pinned model revisions.

## Delivered architecture

1. Active Job + Solid Queue 1.7.0: PostgreSQL-backed persistent queue with 13 additive queue tables. Dedicated m5_ai worker, independent of Puma, handles long Modal calls.
2. AISearchRun: membership/tenant/role/locale-scoped metadata, unpredictable public ID, query SHA256, 24-hour TTL. Approved KB provenance and tenant are rechecked before storing any returned citations; no credentials are persisted.
3. Async POST: with M5_ASYNC_SEARCH_ENABLE=YES, POST /kb/ai-search returns HTTP 303 as soon as a job is enqueued. GET /kb/ai-search/runs/:id exposes status only to the exact originating membership.
4. Turbo Frames + Stimulus: checks status approximately every three seconds and stops at succeeded/failed. No SPA or JavaScript bundler required.
5. Bounded retry: only HTTP 429/500/502/503/504 and selected timeout/network errors are retryable, with at most two total attempts and an eight-second delay. Authorization, model provenance and corpus validation failures fail closed.
6. Maintenance: development-only Solid Queue recurring task every five minutes. It requeues a stale running request after 12 minutes, within the attempt limit, and deletes expired requests. Requires a running worker.
7. Opt-in: the previous synchronous flow is preserved when M5.2 is off. Cloudflare Quick Tunnel still requires a private password and rejects business writes with HTTP 405.

## Live acceptance

- HTTPS POST returned 303 in 495.8 ms.
- The Solid Queue worker completed inference in 38,748 ms with one attempt.
- Thirteen HTTP status polls completed the request after 41,176.4 ms end-to-end. Top-1 was TF-KB-012 with three citations. No business writes.
- Historical Cloudflare HTTP 524 and Modal preemption evidence remain separate and unmodified.
- Full Rails and security test output is preserved in M5.2 evidence logs.

## Colab recovery

Restore the full backup and credentials separately (private files mode 0600). Use the runtime bootstrap, install the bundle, and apply the additive development/test migrations. Launch a private Puma process with M5_ASYNC_SEARCH_ENABLE=YES, M2_SEMANTIC_UI_ENABLE=YES and M2_ANSWERABILITY_SCOPE_ENABLE=NO, retaining the existing password and read-only tunnel gates. Launch bin/jobs start as a separate process with the same Modal credentials. Verify the full test suite and a bounded synthetic HTTPS smoke test. Do not put credentials in Git or evidence archives.

## Independent 120-case review workflow

Approved reference: review/m5_independent_120_20261030/APPROVED_KB_REFERENCE_ONLY.json.
Worksheet: review/m5_independent_120_20261030/BLINDED_REVIEW_WORKSHEET_NOT_GOLD.csv.

A human independently classifies claims as SUPPORTED, PARTIAL, NEEDS_CASE_EVIDENCE or UNSUPPORTED and records approved KB evidence and SHA256, missing case details, unsupported action rationale, reviewer identity and a safe support response. The read-only script script/m52_review_intake.py checks a completed worksheet. It neither invents gold labels nor changes canonical sources or the sealed80 gate. Currently zero of 120 cases are independently reviewed.

## Remaining production work

Real authentication and user lifecycle, separate production queue database, monitoring and worker supervision, distributed limits, circuit breaker/recovery, and quality acceptance on independently assessed cases. This pilot verifies one asynchronous retrieval workflow, not full production availability.

## Final Colab acceptance

- Full Rails regression: 114 tests / 4,907 assertions / no failures, errors or skips.
- M5.2 async security: 7 tests / 83 assertions PASS; maintenance: 4 tests / 10 assertions PASS.
- Real Chromium over Cloudflare: PASS with 3 citations, executable Turbo/Stimulus and zero JavaScript errors. This browser test made no new GPU calls.
- Public preview: password gate HTTP 200; business mutation routes still return HTTP 405.
- Review intake: 120 valid blinded candidates, zero human-approved cases, sealed80 BLOCKED. No invented gold labels.
