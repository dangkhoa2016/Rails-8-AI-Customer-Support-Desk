# M5.2 — Reliability & AI Quality (2026-10-30)

## Phạm vi

- Rails 8 AI Customer Support Desk; hai tenant tổng hợp TeamFlow Cloud và NovaMart Store.
- Không thay đổi 240 tickets, 440 messages, 84 embeddings hoặc 12 KB approved.
- AI chỉ đề xuất bằng chứng, không tự gửi phản hồi và không ghi dữ liệu nghiệp vụ.
- Answerability sealed80 tiếp tục BLOCKED; bộ 120 câu hỏi chưa có human gold labels.
- Hai model Modal Qwen3-Embedding-4B và Qwen3-Reranker-4B giữ nguyên revision đã pin.

## Kiến trúc được triển khai

1. Active Job + Solid Queue 1.7.0: PostgreSQL-backed queue, 13 bảng queue bổ sung qua migration. Worker m5_ai riêng, không gọi Modal từ Puma.
2. AISearchRun: bản ghi tenant/member/role/locale + public ID ngẫu nhiên + SHA256 query + TTL 24 giờ. Mọi kết quả đều được kiểm tra lại thuộc KB approved cùng tenant; không lưu token.
3. Async POST: khi M5_ASYNC_SEARCH_ENABLE=YES, POST /kb/ai-search trả HTTP 303 ngay sau enqueue. GET status qua /kb/ai-search/runs/:id được phân quyền theo chính xác membership.
4. Turbo Frames và Stimulus polling: kiểm tra trạng thái khoảng 3 giây/lần, dừng sau succeeded/failed, không cần SPA hoặc JS bundler.
5. Retry có giới hạn: chỉ HTTP 429/500/502/503/504 và một số lỗi timeout/network mới được thử lại; tối đa hai attempts tổng, nghỉ 8 giây. Lỗi authorization, provenance và corpus không retry.
6. Maintenance: cấu hình Solid Queue recurring chạy 5 phút/lần trong development, phục hồi running job bị kẹt hơn 12 phút với giới hạn và dọn các yêu cầu đã hết hạn. Worker cần thực sự chạy để tiến hành maintenance.
7. Flag opt-in: luồng synchronous trước đây giữ nguyên khi chưa bật M5.2. Preview Cloudflare vẫn có password gate và HTTP 405 chặn business writes.

## Evidence thực tế

- HTTPS POST trả HTTP 303 trong 495,8 ms.
- Job được worker xử lý và succeeded sau 38.748 ms (1 attempt).
- HTTP polling 13 lần, hoàn thành end-to-end sau 41.176,4 ms; Top-1 TF-KB-012, 3 citations; không có business writes.
- Lỗi Cloudflare 524 và Modal preemption của giai đoạn M5.0 trước đó vẫn được lưu lại, không sửa hoặc ghi đè.
- Regression Rails và job security cần được kiểm tra trong log M5.2 final.

## Khôi phục Colab

Sau khi restore full backup và credentials riêng (mode 0600): source /content/rails8_restore_env_20261030.sh, bundle install, bin/rails db:migrate, RAILS_ENV=test bin/rails db:migrate. Chạy một Puma process có M5_ASYNC_SEARCH_ENABLE=YES, M2_SEMANTIC_UI_ENABLE=YES, M2_ANSWERABILITY_SCOPE_ENABLE=NO và private preview gate. Khởi động worker độc lập bằng bin/jobs start cùng credentials Modal. Chạy RAILS_ENV=test bin/rails test và smoke test chỉ với synthetic inputs. Không bao giờ đưa token vào Git hoặc evidence.

## Quy trình review độc lập 120 câu hỏi

Nguồn: review/m5_independent_120_20261030/APPROVED_KB_REFERENCE_ONLY.json.
Worksheet: review/m5_independent_120_20261030/BLINDED_REVIEW_WORKSHEET_NOT_GOLD.csv.

Người đánh giá ghi SUPPORTED, PARTIAL, NEEDS_CASE_EVIDENCE hoặc UNSUPPORTED, nguồn KB và body SHA256, thiếu evidence theo case, lý do từ chối, reviewer ID và câu trả lời hỗ trợ an toàn. Sau đó chạy python3 script/m52_review_intake.py <worksheet_đã_chấm>. Validator không tự tạo gold labels, không sửa nguồn, không tự mở gate sealed80. Hiện vẫn 0/120 human reviewed.

## Còn dang dở

Để production: real authentication, tách riêng queue DB, supervision/monitoring, distributed rate limiting, circuit breaker và acceptance trên tập câu hỏi độc lập. Kết quả này mới xác nhận reliability của một pilot background workflow.

## Nghiệm thu cuối trên Colab

- Rails regression: 114 tests / 4.907 assertions / 0 failures / 0 errors / 0 skips.
- M5.2 async security tests: 7 tests / 83 assertions PASS. Bảo trì: 4 tests / 10 assertions PASS.
- Chromium thực qua Cloudflare: PASS, 3 citations, Turbo và Stimulus được thực thi, 0 JavaScript errors. Không gọi thêm GPU trong phép thử này.
- Public preview: HTTP 200 tại trang password gate, các tuyến business writes vẫn 405.
- Review intake: 120 câu hỏi hợp lệ, 0 người duyệt, sealed80 BLOCKED; không tự tạo human gold.
